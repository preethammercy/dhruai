#!/usr/bin/env node
// DHRU.AI - Admin Password Hash Generator
// Usage: node scripts/generate-admin-hash.js "YourPasswordHere"

import crypto from 'node:crypto';

const password = process.argv[2];

if (!password) {
  console.log('\n❌ Usage: node scripts/generate-admin-hash.js "YourPasswordHere"\n');
  process.exit(1);
}

const salt = crypto.randomBytes(16).toString('hex');
const iterations = 100000;
const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha256').toString('hex');
const fullHash = `pbkdf2$${iterations}$${salt}$${hash}`;

console.log('\n======================================================');
console.log('  🔐 DHRU.AI Cryptographic Admin Password Hash');
console.log('======================================================\n');
console.log(`Password: ${password}`);
console.log(`Generated Hash: ${fullHash}\n`);
console.log('Add this line to your .env file:');
console.log(`ADMIN_PASSWORD_HASH=${fullHash}\n`);
console.log('======================================================\n');
