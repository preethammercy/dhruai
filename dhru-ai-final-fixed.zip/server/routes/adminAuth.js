// DHRU.AI - Super Admin Authentication & Security Router
// Cryptographically verified credentials, rate limiting, and HMAC-SHA256 JWT tokens.

import express from 'express';
import crypto from 'node:crypto';

export const ADMIN_EMAIL_DEFAULT = 'dhruti@preetham.com';
const JWT_EXPIRY_SECONDS = 24 * 60 * 60; // 24 hours

// Rate limiter state: Map<ip, { attempts: number, lockUntil: number, firstAttempt: number }>
const loginAttempts = new Map();
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes lockout

// Clean up old rate limit entries every 30 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, entry] of loginAttempts.entries()) {
    if (now > entry.lockUntil && (now - entry.firstAttempt) > LOCKOUT_MS) {
      loginAttempts.delete(ip);
    }
  }
}, 30 * 60 * 1000).unref();

/**
 * Creates a cryptographically secure PBKDF2 hash of a password.
 * Format: pbkdf2$iterations$salt$hash
 */
export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const iterations = 100000;
  const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha256').toString('hex');
  return `pbkdf2$${iterations}$${salt}$${hash}`;
}

/**
 * Compares a plain password against an environment hash.
 * Supports:
 * 1. pbkdf2$iterations$salt$hash
 * 2. sha256$salt$hash
 * 3. Plaintext fallback ONLY if env variable is set to a raw fallback (with warning).
 */
export function verifyPassword(password, storedHash) {
  if (!storedHash || !password) return false;

  try {
    if (storedHash.startsWith('pbkdf2$')) {
      const [, iterStr, salt, expectedHash] = storedHash.split('$');
      const iterations = parseInt(iterStr, 10);
      const computedHash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha256').toString('hex');
      return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(expectedHash, 'hex'));
    }

    if (storedHash.startsWith('sha256$')) {
      const [, salt, expectedHash] = storedHash.split('$');
      const computedHash = crypto.createHmac('sha256', salt).update(password).digest('hex');
      return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(expectedHash, 'hex'));
    }

    // Direct constant-time string comparison for dev fallback
    const bufA = Buffer.from(password);
    const bufB = Buffer.from(storedHash);
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch (err) {
    console.error('[AdminAuth] Password verification error:', err.message);
    return false;
  }
}

/**
 * Creates an RFC 7519 HMAC-SHA256 JWT without external dependencies.
 */
export function signJwt(payload, secret) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url');
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${signature}`;
}

/**
 * Verifies an RFC 7519 HMAC-SHA256 JWT.
 */
export function verifyJwt(token, secret) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  const [encodedHeader, encodedPayload, signature] = parts;
  const data = `${encodedHeader}.${encodedPayload}`;
  const expectedSig = crypto.createHmac('sha256', secret).update(data).digest('base64url');

  if (signature.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) return null;

  try {
    const payload = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString('utf8'));
    if (payload.exp && Math.floor(Date.now() / 1000) > payload.exp) {
      return null; // Expired
    }
    return payload;
  } catch {
    return null;
  }
}

/**
 * Express middleware to protect /api/admin/* endpoints.
 */
export function requireAdminAuth(req, res, next) {
  // JWT Token validation from Authorization header, custom header, or query parameter
  const authHeader = req.headers.authorization || req.headers['x-admin-token'] || req.query.token;
  let token = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (typeof authHeader === 'string') {
    token = authHeader.trim();
  }

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized: Admin authentication token required' });
  }

  const jwtSecret = process.env.ADMIN_JWT_SECRET || 'dhru_secret_admin_jwt_key_2026';
  const decoded = verifyJwt(token, jwtSecret);

  if (!decoded || decoded.role !== 'SUPER_ADMIN') {
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired admin session' });
  }

  req.adminUser = decoded;
  next();
}

/**
 * Creates the Admin Auth Express Router.
 */
export function createAdminAuthRouter() {
  const router = express.Router();
  router.use(express.json());

  // POST /api/admin/login
  router.post('/login', (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown-ip';
    const now = Date.now();

    // Check rate limiting
    let attemptRecord = loginAttempts.get(clientIp);
    if (!attemptRecord) {
      attemptRecord = { attempts: 0, lockUntil: 0, firstAttempt: now };
      loginAttempts.set(clientIp, attemptRecord);
    }

    if (now < attemptRecord.lockUntil) {
      const remainingSeconds = Math.ceil((attemptRecord.lockUntil - now) / 1000);
      return res.status(429).json({
        error: `Too many failed attempts. Login locked. Please try again in ${remainingSeconds} seconds.`,
        retryAfter: remainingSeconds
      });
    }

    const { email, password } = req.body || {};
    const configuredAdminEmail = (process.env.ADMIN_EMAIL || ADMIN_EMAIL_DEFAULT).toLowerCase().trim();
    const cleanEmail = String(email || '').toLowerCase().trim();
    const cleanPassword = String(password || '');

    if (!cleanEmail || !cleanPassword) {
      return res.status(400).json({ error: 'Admin email and password are required' });
    }

    // Verify email
    if (cleanEmail !== configuredAdminEmail) {
      attemptRecord.attempts += 1;
      if (attemptRecord.attempts >= MAX_ATTEMPTS) {
        attemptRecord.lockUntil = now + LOCKOUT_MS;
      }
      return res.status(401).json({ error: 'Invalid admin credentials' });
    }

    // Verify password against environment hash or fallback
    const configuredHash = process.env.ADMIN_PASSWORD_HASH;
    let isValid = false;

    if (configuredHash) {
      isValid = verifyPassword(cleanPassword, configuredHash);
    } else {
      // Default fallback if ADMIN_PASSWORD_HASH is not yet set in .env
      // Generates and accepts default pre-set secure key
      const defaultHash = hashPassword('Dhruti@0416', 'dhru_fixed_salt');
      isValid = verifyPassword(cleanPassword, defaultHash);
    }

    if (!isValid) {
      attemptRecord.attempts += 1;
      if (attemptRecord.attempts >= MAX_ATTEMPTS) {
        attemptRecord.lockUntil = now + LOCKOUT_MS;
        return res.status(429).json({
          error: `Too many failed attempts. Locked out for 15 minutes.`,
          retryAfter: 900
        });
      }
      const remainingAttempts = MAX_ATTEMPTS - attemptRecord.attempts;
      return res.status(401).json({
        error: `Invalid credentials. ${remainingAttempts} attempts remaining before temporary lockout.`
      });
    }

    // Successful login: reset attempts
    loginAttempts.delete(clientIp);

    const jwtSecret = process.env.ADMIN_JWT_SECRET || 'dhru_secret_admin_jwt_key_2026';
    const nowEpoch = Math.floor(now / 1000);
    const token = signJwt(
      {
        sub: cleanEmail,
        role: 'SUPER_ADMIN',
        iat: nowEpoch,
        exp: nowEpoch + JWT_EXPIRY_SECONDS
      },
      jwtSecret
    );

    res.json({
      ok: true,
      token,
      email: cleanEmail,
      expiresIn: JWT_EXPIRY_SECONDS,
      message: 'Admin authorization successful'
    });
  });

  // GET /api/admin/verify-token
  router.get('/verify-token', requireAdminAuth, (req, res) => {
    res.json({ ok: true, admin: req.adminUser });
  });

  return router;
}
