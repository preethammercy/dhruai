import test from 'node:test';
import assert from 'node:assert/strict';
import { db } from '../server/db/database.js';
import { createUserRouter } from '../server/routes/users.js';
import { createPaymentsRouter } from '../server/routes/payments.js';
import { createAdminRouter } from '../server/routes/admin.js';

test('End-to-End User Payment & Admin Approval Verification', async (t) => {
  const testUid = `TEST-USER-${Date.now()}`;
  const testEmail = `trader_${Date.now()}@example.com`;
  const testPhone = `+9198${Math.floor(10000000 + Math.random() * 90000000)}`;
  const testUtr = `UTR${Date.now()}`;

  // 1. Simulate User Sync / Registration
  await t.test('1. User Sync writes to SQLite users and wallets tables', () => {
    const nowIso = new Date().toISOString();
    db.execute(`
      INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt)
      VALUES (?, 'Test Trader', ?, ?, 1, 'verified', 'active', ?, ?)
    `, testUid, testEmail, testPhone, nowIso, nowIso);

    db.execute(`
      INSERT INTO wallets (uid, demoCredits, realCredits)
      VALUES (?, 100, 0)
    `, testUid);

    const user = db.queryOne('SELECT * FROM users WHERE uid = ?', testUid);
    assert.equal(user.uid, testUid);
    assert.equal(user.phone, testPhone);
    assert.equal(user.email, testEmail);

    const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
    assert.equal(wallet.demoCredits, 100);
    assert.equal(wallet.realCredits, 0);
  });

  // 2. Simulate User Payment Submission
  let createdPaymentId = '';
  await t.test('2. User Submits UPI Deposit with UTR into payments table', () => {
    createdPaymentId = `DHRU-PAY-TEST-${Date.now()}`;
    const nowIso = new Date().toISOString();

    db.execute(`
      INSERT INTO payments (id, uid, amount, method, utr, status, createdAt)
      VALUES (?, ?, 1000, 'UPI', ?, 'pending', ?)
    `, createdPaymentId, testUid, testUtr, nowIso);

    const payment = db.queryOne('SELECT * FROM payments WHERE id = ?', createdPaymentId);
    assert.ok(payment);
    assert.equal(payment.status, 'pending');
    assert.equal(payment.amount, 1000);
    assert.equal(payment.utr, testUtr);
  });

  // 3. Admin Panel Queries
  await t.test('3. Admin Panel queries fetch the registered user with full details', () => {
    const sql = `
      SELECT u.uid, u.name, u.email, u.phone, u.phoneVerified, u.kycStatus, u.status, u.createdAt,
             COALESCE(w.realCredits, 0) as realCredits,
             COALESCE(w.demoCredits, 0) as demoCredits
      FROM users u
      LEFT JOIN wallets w ON u.uid = w.uid
      WHERE u.uid = ?
    `;
    const userInAdmin = db.queryOne(sql, testUid);
    assert.ok(userInAdmin, 'User should be found in Admin Users list');
    assert.equal(userInAdmin.email, testEmail);
    assert.equal(userInAdmin.phone, testPhone);
    assert.equal(userInAdmin.demoCredits, 100);
    assert.equal(userInAdmin.realCredits, 0);
  });

  await t.test('4. Admin Panel queries fetch the pending payment with user dossier', () => {
    const sql = `
      SELECT p.*,
             COALESCE(u.name, 'Trader') as userName,
             COALESCE(u.email, '') as userEmail,
             COALESCE(u.phone, '') as userPhone
      FROM payments p
      LEFT JOIN users u ON p.uid = u.uid
      WHERE p.id = ?
    `;
    const paymentInAdmin = db.queryOne(sql, createdPaymentId);
    assert.ok(paymentInAdmin, 'Payment should be in Admin Queue');
    assert.equal(paymentInAdmin.status, 'pending');
    assert.equal(paymentInAdmin.userName, 'Test Trader');
    assert.equal(paymentInAdmin.userEmail, testEmail);
    assert.equal(paymentInAdmin.userPhone, testPhone);
  });

  // 4. Admin Approves Payment
  await t.test('5. Admin approves payment: credits realCredits and writes ledger', () => {
    const nowIso = new Date().toISOString();
    const adminEmail = 'dhruti@preetham.com';

    db.runTransaction(() => {
      db.execute(`
        UPDATE payments
        SET status = 'approved', reviewedAt = ?, reviewedBy = ?, adminNote = 'Verified by Admin'
        WHERE id = ?
      `, nowIso, adminEmail, createdPaymentId);

      db.execute(`
        UPDATE wallets SET realCredits = realCredits + 1000 WHERE uid = ?
      `, testUid);

      const wallet = db.queryOne('SELECT realCredits FROM wallets WHERE uid = ?', testUid);

      db.execute(`
        INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
        VALUES (?, 'real', 'deposit', 1000, ?, ?, 'Approved UPI Deposit', ?)
      `, testUid, wallet.realCredits, createdPaymentId, nowIso);
    });

    const payment = db.queryOne('SELECT * FROM payments WHERE id = ?', createdPaymentId);
    assert.equal(payment.status, 'approved');
    assert.equal(payment.reviewedBy, adminEmail);

    const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
    assert.equal(wallet.realCredits, 1000);

    const ledger = db.queryOne('SELECT * FROM wallet_ledger WHERE refId = ?', createdPaymentId);
    assert.ok(ledger);
    assert.equal(ledger.amount, 1000);
    assert.equal(ledger.balanceAfter, 1000);
  });

  // 5. Duplicate UTR check
  await t.test('6. Duplicate UTR check detects existing UTR', () => {
    const duplicate = db.queryOne('SELECT id, status FROM payments WHERE utr = ?', testUtr);
    assert.ok(duplicate);
    assert.equal(duplicate.status, 'approved');
  });

  // Cleanup test fixtures
  await t.test('7. Cleanup test fixtures', () => {
    db.execute('DELETE FROM payments WHERE id = ?', createdPaymentId);
    db.execute('DELETE FROM wallet_ledger WHERE uid = ?', testUid);
    db.execute('DELETE FROM wallets WHERE uid = ?', testUid);
    db.execute('DELETE FROM users WHERE uid = ?', testUid);
  });
});
