-- DHRU.AI Migration 003
-- Trading funds (UPI fund deposits) were previously being added to realCredits in SQLite,
-- mixing AI credits and rupee funds. Give funds their own column.
ALTER TABLE wallets ADD COLUMN tradingBalance REAL NOT NULL DEFAULT 0;
