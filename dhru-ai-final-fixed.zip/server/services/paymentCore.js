// DHRU.AI - Payment Core (single source of truth for approving / rejecting payments)
//
// Every approve/reject endpoint (/api/admin/payments/:id/approve, /api/payments/admin/:id/approve,
// /api/wallet/admin/approve-order, ...) now delegates to the functions in this file, so a payment
// is credited exactly once no matter which route (or how many routes) the admin panel calls.
//
// Writes to BOTH stores the app reads from:
//   * SQLite (payments, wallets, wallet_ledger, notifications, audit_logs)
//   * server/data/wallet-store.json (what /api/wallet/state returns to the user wallet UI)

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin } from './realtimeStream.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.WALLET_DATA_DIR
  ? path.resolve(process.env.WALLET_DATA_DIR)
  : path.resolve(__dirname, '../data');
export const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');

export function loadWalletStore() {
  try {
    if (fs.existsSync(WALLET_FILE)) {
      const s = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
      if (!s.users) s.users = {};
      if (!s.orders) s.orders = {};
      return s;
    }
  } catch (err) {
    console.warn('[PaymentCore] wallet-store read failed:', err.message);
  }
  return { users: {}, orders: {} };
}

export function saveWalletStore(store) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  // write-then-rename so a crash can never leave a half written JSON file
  const tmp = `${WALLET_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmp, WALLET_FILE);
}

const uid8 = () => crypto.randomUUID().slice(0, 8);

export function defaultCreditsForAmount(amount) {
  const a = Number(amount);
  return a === 99 ? 200 : a === 199 ? 500 : a === 499 ? 1200 : a === 899 ? 2000 : a;
}

const isApprovedStatus = (s) => ['approved', 'verified'].includes(String(s || '').toLowerCase());

function blankStoreUser(uid, info = {}) {
  return {
    uid,
    displayName: info.userName || info.name || 'Trader',
    email: info.userEmail || info.email || '',
    phone: info.userPhone || info.phone || '',
    credits: 0,
    realCredits: 0,
    demoCredits: 100,
    tradingBalance: 0,
    totalCreditsPurchased: 0,
    premiumUnlocked: false,
    joinedAt: new Date().toISOString(),
    lastActive: new Date().toISOString(),
    history: []
  };
}

function ensureSqlUserAndWallet(uid, info, nowIso) {
  if (!db.queryOne('SELECT uid FROM users WHERE uid = ?', uid)) {
    db.execute(
      `INSERT OR IGNORE INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt)
       VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?)`,
      uid, info.userName || 'Trader', info.userEmail || null, info.userPhone || null,
      info.userPhone ? 1 : 0, nowIso, nowIso
    );
  }
  db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits, tradingBalance) VALUES (?, 100, 0, 0)', uid);
}

function findOrder(store, id, utr) {
  if (store.orders[id]) return { key: id, order: store.orders[id] };
  if (utr) {
    for (const [k, o] of Object.entries(store.orders)) {
      if (o?.utr && String(o.utr).toUpperCase() === String(utr).toUpperCase()) return { key: k, order: o };
    }
  }
  return { key: id, order: null };
}

/** Wallet snapshot in the exact shape the user UI (WalletContext) understands. */
export function walletSnapshot(uid) {
  const store = loadWalletStore();
  const u = store.users[uid] || {};
  const sql = db.queryOne('SELECT demoCredits, realCredits, tradingBalance FROM wallets WHERE uid = ?', uid) || {};
  const realCredits = Number(u.realCredits ?? u.credits ?? sql.realCredits ?? 0);
  return {
    demoCredits: Number(u.demoCredits ?? sql.demoCredits ?? 100),
    realCredits,
    credits: realCredits,
    tradingBalance: Number(u.tradingBalance ?? sql.tradingBalance ?? 0),
    premiumUnlocked: Boolean(u.premiumUnlocked || realCredits >= 1000)
  };
}

/**
 * Approve a payment exactly once. Idempotent: calling it again (from a second route, a retry,
 * a double click) returns { already: true } and never credits twice.
 */
export function approvePayment({ id, adminEmail = 'dhruti@preetham.com', adminNote, customAmount, customCredits }) {
  const nowIso = new Date().toISOString();
  adminNote = adminNote || 'Approved by administrator';

  const payment = db.queryOne('SELECT * FROM payments WHERE id = ? OR utr = ?', id, id);
  const store = loadWalletStore();
  const { key: orderKey, order } = findOrder(store, payment?.id || id, payment?.utr);

  if (!payment && !order) {
    return { status: 404, error: `Payment record ${id} not found.` };
  }

  const paymentId = payment?.id || orderKey;
  const uid = payment?.uid || order?.userId || order?.uid;
  if (!uid) return { status: 400, error: 'Payment has no user (uid) attached.' };

  const info = {
    userName: order?.userName, userEmail: order?.userEmail, userPhone: order?.userPhone
  };

  // ---- Idempotency guard (checks BOTH stores, case-insensitive) ----
  if (isApprovedStatus(payment?.status) || isApprovedStatus(order?.status)) {
    // heal half-approved state (one store says approved, the other still pending) WITHOUT crediting again
    if (payment && !isApprovedStatus(payment.status)) {
      db.execute("UPDATE payments SET status='approved', reviewedAt=?, reviewedBy=? WHERE id=?", nowIso, adminEmail, payment.id);
    }
    if (order && !isApprovedStatus(order.status)) {
      order.status = 'VERIFIED';
      saveWalletStore(store);
    }
    return { status: 200, ok: true, already: true, message: 'This payment has already been approved.', wallet: walletSnapshot(uid) };
  }

  const type = payment?.type || order?.type || 'funds';
  const paymentAmount = Number(customAmount) > 0 ? Number(customAmount) : Number(payment?.amount ?? order?.amount ?? 0);
  const isCredits = type === 'credits' || Number(customCredits) > 0;

  if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
    return { status: 400, error: 'Payment amount must be greater than zero.' };
  }

  const creditsToAdd = isCredits
    ? (Number(customCredits) > 0 ? Number(customCredits)
      : Number(payment?.credits) > 0 ? Number(payment.credits)
      : Number(order?.credits) > 0 ? Number(order.credits)
      : defaultCreditsForAmount(paymentAmount))
    : 0;
  const fundsToAdd = isCredits ? 0 : paymentAmount;
  const orderUtr = payment?.utr || order?.utr || `ADMIN-${uid8()}`;

  // ---- 1. SQLite: one atomic transaction ----
  const tx = db.transaction(() => {
    ensureSqlUserAndWallet(uid, info, nowIso);

    if (payment) {
      db.execute(
        `UPDATE payments SET status='approved', amount=?, type=?, credits=?, reviewedAt=?, reviewedBy=?, adminNote=? WHERE id=?`,
        paymentAmount, isCredits ? 'credits' : 'funds', creditsToAdd, nowIso, adminEmail, adminNote, payment.id
      );
    } else {
      db.execute(
        `INSERT INTO payments (id, uid, amount, method, utr, status, type, credits, createdAt, reviewedAt, reviewedBy, adminNote)
         VALUES (?, ?, ?, 'UPI', ?, 'approved', ?, ?, ?, ?, ?, ?)`,
        paymentId, uid, paymentAmount, orderUtr, isCredits ? 'credits' : 'funds', creditsToAdd,
        order?.createdAt ? new Date(order.createdAt).toISOString() : nowIso, nowIso, adminEmail, adminNote
      );
    }

    if (isCredits) {
      db.execute('UPDATE wallets SET realCredits = realCredits + ? WHERE uid = ?', creditsToAdd, uid);
    } else {
      db.execute('UPDATE wallets SET tradingBalance = tradingBalance + ? WHERE uid = ?', fundsToAdd, uid);
    }
    const w = db.queryOne('SELECT realCredits, tradingBalance FROM wallets WHERE uid = ?', uid);

    db.execute(
      `INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
       VALUES (?, 'real', 'deposit', ?, ?, ?, ?, ?)`,
      uid,
      Math.round(isCredits ? creditsToAdd : fundsToAdd),
      Math.round(isCredits ? w.realCredits : w.tradingBalance),
      paymentId,
      isCredits ? `Approved AI Credits (${creditsToAdd} Cr)` : `Approved UPI Trading Funds (UTR: ${orderUtr})`,
      nowIso
    );

    db.execute(
      `INSERT INTO notifications (id, uid, title, body, createdAt) VALUES (?, ?, 'Payment Approved & Credited!', ?, ?)`,
      `notif-${uid8()}-${Date.now()}`, uid,
      isCredits
        ? `Your payment of ₹${paymentAmount} was approved. Added ${creditsToAdd} AI Credits to your account.`
        : `Your payment of ₹${paymentAmount} was approved. Added ₹${fundsToAdd} Trading Funds to your account.`,
      nowIso
    );

    db.execute(
      `INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, createdAt)
       VALUES (?, 'admin', ?, 'PAYMENT_APPROVED', 'payments', ?, ?, ?, ?)`,
      `audit-${uid8()}-${Date.now()}`, adminEmail, paymentId,
      JSON.stringify({ status: payment?.status || 'pending' }),
      JSON.stringify({ status: 'approved', amount: paymentAmount, credits: creditsToAdd, funds: fundsToAdd }),
      nowIso
    );
  });
  tx();

  // ---- 2. wallet-store.json (what /api/wallet/state serves to the user) ----
  if (!store.users[uid]) store.users[uid] = blankStoreUser(uid, info);
  const su = store.users[uid];
  if (!Array.isArray(su.history)) su.history = [];
  if (su.demoCredits === undefined) su.demoCredits = 100;

  if (isCredits) {
    su.credits = (Number(su.credits) || 0) + creditsToAdd;
    su.realCredits = (Number(su.realCredits) || 0) + creditsToAdd;
    su.totalCreditsPurchased = (Number(su.totalCreditsPurchased) || 0) + creditsToAdd;
    if (su.credits >= 1000 || su.totalCreditsPurchased >= 1000) su.premiumUnlocked = true;
    su.history.unshift({
      id: `tx-credit-${Date.now()}`, type: 'CREDIT_PURCHASE', amount: paymentAmount, credits: creditsToAdd,
      utr: orderUtr, orderId: paymentId, note: adminNote, at: nowIso, status: 'VERIFIED'
    });
  } else {
    su.tradingBalance = (Number(su.tradingBalance) || 0) + fundsToAdd;
    su.history.unshift({
      id: `tx-fund-${Date.now()}`, type: 'FUND_DEPOSIT', amount: fundsToAdd,
      utr: orderUtr, orderId: paymentId, note: adminNote, at: nowIso, status: 'VERIFIED'
    });
  }

  const target = order || (store.orders[paymentId] = {
    orderId: paymentId, id: paymentId, userId: uid, uid, amount: paymentAmount, utr: orderUtr,
    type: isCredits ? 'credits' : 'funds', credits: creditsToAdd, createdAt: Date.now()
  });
  target.status = 'VERIFIED';
  target.verifiedAt = Date.now();
  target.verifiedBy = adminEmail;
  target.adminNote = adminNote;
  saveWalletStore(store);

  // ---- 3. Real-time push to the user + admin panel ----
  const wallet = walletSnapshot(uid);
  sendToUser(uid, 'payment_approved', {
    paymentId, amount: paymentAmount, credits: creditsToAdd, wallet, note: adminNote
  });
  sendToUser(uid, 'wallet_update', wallet);
  broadcastToAdmin('payment_updated', {
    paymentId, status: 'approved', amount: paymentAmount, credits: creditsToAdd, reviewedBy: adminEmail
  });

  return {
    status: 200, ok: true, already: false, uid, wallet,
    message: isCredits
      ? `Successfully approved! Credited ${creditsToAdd} AI Credits to UID ${uid}.`
      : `Successfully approved! Credited ₹${fundsToAdd} Trading Funds to UID ${uid}.`,
    payment: { id: paymentId, status: 'approved', amount: paymentAmount, credits: creditsToAdd, type: isCredits ? 'credits' : 'funds' }
  };
}

export function rejectPayment({ id, adminEmail = 'dhruti@preetham.com', reason }) {
  const nowIso = new Date().toISOString();
  reason = String(reason || '').trim();
  if (!reason) {
    return { status: 400, error: 'A rejection reason is strictly required so the user knows why the payment was rejected.' };
  }

  const payment = db.queryOne('SELECT * FROM payments WHERE id = ? OR utr = ?', id, id);
  const store = loadWalletStore();
  const { key: orderKey, order } = findOrder(store, payment?.id || id, payment?.utr);
  if (!payment && !order) return { status: 404, error: `Payment record ${id} not found.` };

  if (isApprovedStatus(payment?.status) || isApprovedStatus(order?.status)) {
    return { status: 400, error: 'Cannot reject an already approved payment.' };
  }

  const paymentId = payment?.id || orderKey;
  const uid = payment?.uid || order?.userId || order?.uid;

  const tx = db.transaction(() => {
    if (payment) {
      db.execute(
        `UPDATE payments SET status='rejected', reviewedAt=?, reviewedBy=?, adminNote=? WHERE id=?`,
        nowIso, adminEmail, reason, payment.id
      );
    }
    if (uid) {
      db.execute(
        `INSERT INTO notifications (id, uid, title, body, createdAt) VALUES (?, ?, 'Payment Rejected', ?, ?)`,
        `notif-${uid8()}-${Date.now()}`, uid, `Your payment ${payment?.utr || ''} was rejected: ${reason}`, nowIso
      );
    }
    db.execute(
      `INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, createdAt)
       VALUES (?, 'admin', ?, 'PAYMENT_REJECTED', 'payments', ?, ?, ?, ?)`,
      `audit-${uid8()}-${Date.now()}`, adminEmail, paymentId,
      JSON.stringify({ status: payment?.status || 'pending' }), JSON.stringify({ status: 'rejected', reason }), nowIso
    );
  });
  tx();

  if (order) {
    order.status = 'REJECTED';
    order.rejectionReason = reason;
    order.rejectedAt = Date.now();
    saveWalletStore(store);
  }

  if (uid) sendToUser(uid, 'payment_rejected', { paymentId, reason });
  broadcastToAdmin('payment_updated', { paymentId, status: 'rejected', reason, reviewedBy: adminEmail });

  return { status: 200, ok: true, message: 'Payment rejected. Reason notified to user.', payment: { id: paymentId, status: 'rejected' } };
}

/**
 * Manual admin balance adjustment (funds and/or AI credits, positive or negative).
 * The admin dashboard calls POST /api/admin/users/:uid/adjust-balance with { deltaAmount, deltaCredits, note }.
 */
export function adjustBalance({ uid, deltaAmount = 0, deltaCredits = 0, note = '', adminEmail = 'dhruti@preetham.com' }) {
  const nowIso = new Date().toISOString();
  const dFunds = Number(deltaAmount) || 0;
  const dCredits = Math.round(Number(deltaCredits) || 0);
  if (!uid) return { status: 400, error: 'UID is required.' };
  if (!dFunds && !dCredits) return { status: 400, error: 'Adjustment amount cannot be zero.' };

  const store = loadWalletStore();
  const info = {
    userName: store.users[uid]?.displayName, userEmail: store.users[uid]?.email, userPhone: store.users[uid]?.phone
  };

  const tx = db.transaction(() => {
    ensureSqlUserAndWallet(uid, info, nowIso);
    const w = db.queryOne('SELECT realCredits, tradingBalance FROM wallets WHERE uid = ?', uid);
    const su = store.users[uid] || (store.users[uid] = blankStoreUser(uid, info));
    const curFunds = Number(su.tradingBalance ?? w.tradingBalance ?? 0);
    const curCredits = Number(su.realCredits ?? su.credits ?? w.realCredits ?? 0);
    if (curFunds + dFunds < 0) throw Object.assign(new Error('Adjustment would make trading balance negative.'), { http: 400 });
    if (curCredits + dCredits < 0) throw Object.assign(new Error('Adjustment would make credits negative.'), { http: 400 });

    if (dFunds) {
      db.execute('UPDATE wallets SET tradingBalance = tradingBalance + ? WHERE uid = ?', dFunds, uid);
      su.tradingBalance = curFunds + dFunds;
      db.execute(
        `INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
         VALUES (?, 'real', 'admin_adjust', ?, ?, NULL, ?, ?)`,
        uid, Math.round(dFunds), Math.round(su.tradingBalance), `Admin funds adjustment: ${note || 'manual'}`, nowIso
      );
    }
    if (dCredits) {
      db.execute('UPDATE wallets SET realCredits = MAX(0, realCredits + ?) WHERE uid = ?', dCredits, uid);
      su.realCredits = curCredits + dCredits;
      su.credits = su.realCredits;
      if (su.credits >= 1000) su.premiumUnlocked = true;
      db.execute(
        `INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
         VALUES (?, 'real', 'admin_adjust', ?, ?, NULL, ?, ?)`,
        uid, dCredits, su.realCredits, `Admin credit adjustment: ${note || 'manual'}`, nowIso
      );
    }
    if (!Array.isArray(su.history)) su.history = [];
    su.history.unshift({
      id: `tx-adjust-${Date.now()}`, type: 'ADMIN_ADJUST', amount: dFunds, credits: dCredits,
      note: note || 'Manual adjustment by Admin', at: nowIso, status: 'VERIFIED'
    });
    db.execute(
      `INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, createdAt)
       VALUES (?, 'admin', ?, 'BALANCE_ADJUSTED', 'wallets', ?, NULL, ?, ?)`,
      `audit-${uid8()}-${Date.now()}`, adminEmail, uid, JSON.stringify({ dFunds, dCredits, note }), nowIso
    );
  });

  try {
    tx();
  } catch (err) {
    return { status: err.http || 500, error: err.message };
  }
  saveWalletStore(store);

  const wallet = walletSnapshot(uid);
  sendToUser(uid, 'wallet_update', wallet);
  return { status: 200, ok: true, message: 'Balance adjusted.', wallet };
}
