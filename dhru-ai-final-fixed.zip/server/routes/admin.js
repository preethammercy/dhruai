// DHRU.AI - Dhruti Super Admin Operations Router
// Controls Analytics, User Management Dossiers, Credit Adjustments, KYC, Funds, Live Trades, and Audit Logs.

import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin, getOnlineUserCount } from '../services/realtimeStream.js';
import { requireAdminAuth } from './adminAuth.js';
import { approvePayment, rejectPayment, adjustBalance } from '../services/paymentCore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');

function loadWalletStoreSafe() {
  try {
    if (fs.existsSync(WALLET_FILE)) {
      return JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    }
  } catch {}
  return { users: {}, orders: {} };
}

function syncWalletStoreToDb() {
  try {
    const store = loadWalletStoreSafe();
    const nowIso = new Date().toISOString();

    // 1. Sync users from wallet-store.json
    for (const [uid, u] of Object.entries(store.users || {})) {
      const existing = db.queryOne('SELECT uid FROM users WHERE uid = ?', uid);
      if (!existing) {
        db.execute(`
          INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt)
          VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?)
        `, uid, u.displayName || u.name || uid, u.email || null, u.phone || null, u.phone ? 1 : 0, u.joinedAt || nowIso, u.lastActive || nowIso);
        
        db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, ?, ?)', uid, u.credits ?? 100, u.tradingBalance ?? 0);
      }
    }

    // 2. Sync orders from wallet-store.json
    for (const [orderId, o] of Object.entries(store.orders || {})) {
      if (!o.utr) continue;
      const existingPay = db.queryOne('SELECT id FROM payments WHERE utr = ? OR id = ?', o.utr, orderId);
      if (!existingPay) {
        const orderUid = o.userId || o.uid || 'trader';
        // Ensure user exists
        const userExists = db.queryOne('SELECT uid FROM users WHERE uid = ?', orderUid);
        if (!userExists) {
          db.execute(`
            INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt)
            VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?)
          `, orderUid, o.userName || 'Trader', o.userEmail || null, o.userPhone || null, o.userPhone ? 1 : 0, nowIso, nowIso);
          db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', orderUid);
        }

        const statusLower = (o.status || 'pending').toLowerCase();
        const validStatus = (statusLower === 'verified' || statusLower === 'approved') ? 'approved' : (statusLower === 'rejected' ? 'rejected' : 'pending');

        db.execute(`
          INSERT OR IGNORE INTO payments (id, uid, amount, method, utr, status, type, credits, createdAt, reviewedAt, reviewedBy, adminNote)
          VALUES (?, ?, ?, 'UPI', ?, ?, ?, ?, ?, ?, ?, ?)
        `, orderId, orderUid, Number(o.amount || 0), o.utr, validStatus, o.type === 'credits' ? 'credits' : 'funds', Number(o.credits || 0), o.createdAt ? (typeof o.createdAt === 'number' ? new Date(o.createdAt).toISOString() : o.createdAt) : nowIso, o.verifiedAt ? new Date(o.verifiedAt).toISOString() : null, o.verifiedBy || null, o.rejectionReason || o.adminNote || null);
      }
    }
  } catch (err) {
    console.warn('[AdminRouter] Sync wallet-store error:', err.message);
  }
}

export function createAdminRouter() {
  const router = express.Router();
  router.use(express.json());
  router.use(requireAdminAuth); // All routes strictly require admin JWT

  // ==========================================
  // 7.1 ANALYTICS DESK
  // ==========================================
  router.get('/analytics', (req, res) => {
    try {
      const onlineUsers = getOnlineUserCount();

      // Users stats
      const totalUsers = db.queryOne('SELECT COUNT(*) as count FROM users')?.count || 0;
      const activeUsers = db.queryOne("SELECT COUNT(*) as count FROM users WHERE status = 'active'")?.count || 0;
      const suspendedUsers = db.queryOne("SELECT COUNT(*) as count FROM users WHERE status != 'active'")?.count || 0;
      const phoneVerifiedUsers = db.queryOne('SELECT COUNT(*) as count FROM users WHERE phoneVerified = 1')?.count || 0;

      // Payments stats
      const totalPayments = db.queryOne('SELECT COUNT(*) as count FROM payments')?.count || 0;
      const pendingPayments = db.queryOne("SELECT COUNT(*) as count FROM payments WHERE status = 'pending'")?.count || 0;
      const approvedPayments = db.queryOne("SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as totalAmount FROM payments WHERE status = 'approved'") || { count: 0, totalAmount: 0 };
      const rejectedPayments = db.queryOne("SELECT COUNT(*) as count FROM payments WHERE status = 'rejected'")?.count || 0;

      // Wallet stats
      const walletTotals = db.queryOne(`
        SELECT
          COALESCE(SUM(realCredits), 0) as totalRealCredits,
          COALESCE(SUM(demoCredits), 0) as totalDemoCredits
        FROM wallets
      `) || { totalRealCredits: 0, totalDemoCredits: 0 };

      // Trades stats
      const tradeTotals = db.queryOne(`
        SELECT
          COUNT(*) as totalTrades,
          SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as openTrades,
          COALESCE(SUM(pnl), 0) as totalPnl
        FROM trades
      `) || { totalTrades: 0, openTrades: 0, totalPnl: 0 };

      // Support tickets stats
      const openTickets = db.queryOne("SELECT COUNT(*) as count FROM support_tickets WHERE status = 'open'")?.count || 0;

      // Promo stats
      const totalPromos = db.queryOne('SELECT COUNT(*) as count FROM promo_codes')?.count || 0;
      const totalRedemptions = db.queryOne('SELECT COUNT(*) as count, COALESCE(SUM(creditsGiven), 0) as totalGiven FROM promo_redemptions') || { count: 0, totalGiven: 0 };

      // Signups over time (last 7 days)
      const signupsByDay = db.queryAll(`
        SELECT substr(createdAt, 1, 10) as day, COUNT(*) as count
        FROM users
        GROUP BY substr(createdAt, 1, 10)
        ORDER BY day DESC
        LIMIT 7
      `).reverse();

      // Approved deposits over time (last 7 days)
      const depositsByDay = db.queryAll(`
        SELECT substr(createdAt, 1, 10) as day, SUM(amount) as amount, COUNT(*) as count
        FROM payments
        WHERE status = 'approved'
        GROUP BY substr(createdAt, 1, 10)
        ORDER BY day DESC
        LIMIT 7
      `).reverse();

      const analyticsPayload = {
        totalUsers,
        activeUsers,
        suspendedUsers,
        phoneVerifiedUsers,
        totalTradingFunds: walletTotals.totalRealCredits,
        totalCreditsOutstanding: walletTotals.totalDemoCredits,
        totalRevenueInr: approvedPayments.totalAmount,
        totalRevenue: approvedPayments.totalAmount,
        totalOrdersCount: totalPayments,
        pendingOrdersCount: pendingPayments,
        verifiedOrdersCount: approvedPayments.count,
        rejectedOrdersCount: rejectedPayments,
        pendingPayments,
        approvedPaymentsCount: approvedPayments.count,
        rejectedPaymentsCount: rejectedPayments,
        totalRealCredits: walletTotals.totalRealCredits,
        totalDemoCredits: walletTotals.totalDemoCredits,
        totalTrades: tradeTotals.totalTrades,
        openTrades: tradeTotals.openTrades,
        totalPnl: tradeTotals.totalPnl,
        openTickets,
        totalPromos,
        totalPromoGiven: totalRedemptions.totalGiven,
        targetVpa: 'preethamrishu@axl',
        payeeName: 'DHRU AI Quantitative Markets',
        systemStatus: 'OPERATIONAL',
        onlineUsers
      };

      return res.json({
        ok: true,
        analytics: analyticsPayload,
        metrics: analyticsPayload,
        charts: {
          signupsByDay,
          depositsByDay
        }
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to generate analytics', details: err.message });
    }
  });

  // ==========================================
  // 7.2 PAYMENT APPROVALS & UTR QUEUE
  // ==========================================
  router.get('/payments', (req, res) => {
    try {
      syncWalletStoreToDb();
      const { status, q, limit = 100, offset = 0 } = req.query;

      let sql = `
        SELECT p.*,
               COALESCE(u.name, 'Trader') as userName,
               COALESCE(u.email, '') as userEmail,
               COALESCE(u.phone, '') as userPhone
        FROM payments p
        LEFT JOIN users u ON p.uid = u.uid
        WHERE 1=1
      `;
      const params = [];

      if (status && status !== 'ALL') {
        sql += ' AND UPPER(p.status) = ?';
        params.push(status.toUpperCase());
      }

      if (q) {
        sql += ' AND (p.utr LIKE ? OR p.id LIKE ? OR u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR p.uid LIKE ?)';
        const wild = `%${q}%`;
        params.push(wild, wild, wild, wild, wild, wild);
      }

      sql += ' ORDER BY p.createdAt DESC LIMIT ? OFFSET ?';
      params.push(Number(limit), Number(offset));

      const payments = db.queryAll(sql, ...params);
      const totalCount = db.queryOne('SELECT COUNT(*) as count FROM payments')?.count || 0;
      const pendingCount = db.queryOne("SELECT COUNT(*) as count FROM payments WHERE status = 'pending'")?.count || 0;

      return res.json({ ok: true, payments, totalCount, pendingCount });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch payments', details: err.message });
    }
  });

  router.post('/payments/:id/approve', (req, res) => {
    try {
      const { adminNote, customAmount, customCredits } = req.body || {};
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const result = approvePayment({ id: req.params.id, adminEmail, adminNote, customAmount, customCredits });
      const { status, ...body } = result;
      return res.status(status).json(body);
    } catch (err) {
      console.error('[Admin approve error]:', err);
      return res.status(500).json({ error: 'Failed to approve payment', details: err.message });
    }
  });

  router.post('/payments/:id/reject', (req, res) => {
    try {
      const { reason } = req.body || {};
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const result = rejectPayment({ id: req.params.id, adminEmail, reason });
      const { status, ...body } = result;
      return res.status(status).json(body);
    } catch (err) {
      return res.status(500).json({ error: 'Failed to reject payment', details: err.message });
    }
  });

  // Dashboard "Adjust Balance" endpoint (was missing -> 404, so manual credits never reached the user)
  router.post('/users/:uid/adjust-balance', (req, res) => {
    try {
      const { deltaAmount, deltaCredits, note } = req.body || {};
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const result = adjustBalance({ uid: req.params.uid, deltaAmount, deltaCredits, note, adminEmail });
      const { status, ...body } = result;
      return res.status(status).json(body);
    } catch (err) {
      return res.status(500).json({ error: 'Failed to adjust balance', details: err.message });
    }
  });

  // ==========================================
  // 7.3 USER MANAGEMENT & DOSSIER
  // ==========================================
  router.get('/users', (req, res) => {
    try {
      syncWalletStoreToDb();
      const { q = '', status, kyc, limit = 100, offset = 0 } = req.query;

      let sql = `
        SELECT u.uid, u.name, u.email, u.phone, u.phoneVerified, u.kycStatus, u.status, u.createdAt, u.lastLoginAt, u.lastIp,
               COALESCE(w.realCredits, 0) as realCredits,
               COALESCE(w.demoCredits, 0) as demoCredits
        FROM users u
        LEFT JOIN wallets w ON u.uid = w.uid
        WHERE 1=1
      `;
      const params = [];

      // Exclude automated test-generated dummy emails
      sql += " AND (u.email IS NULL OR (u.email NOT LIKE '%@example.com' AND u.email NOT LIKE 'test_%@dhru.ai'))";

      if (q) {
        sql += ` AND (u.uid LIKE ? OR u.email LIKE ? OR u.name LIKE ? OR u.phone LIKE ?)`;
        const wildcard = `%${q}%`;
        params.push(wildcard, wildcard, wildcard, wildcard);
      }

      if (status && status !== 'all') {
        sql += ' AND u.status = ?';
        params.push(status);
      }

      if (kyc && kyc !== 'all') {
        sql += ' AND u.kycStatus = ?';
        params.push(kyc);
      }

      sql += ' ORDER BY u.createdAt DESC LIMIT ? OFFSET ?';
      params.push(Number(limit), Number(offset));

      const rawUsers = db.queryAll(sql, ...params);
      const store = loadWalletStoreSafe();

      const users = rawUsers.map(u => {
        const storeU = store.users?.[u.uid] || {};
        const isSuspended = u.status === 'suspended' || u.status === 'banned' || Boolean(storeU.suspended);
        const tradingBalance = Number(storeU.tradingBalance ?? 0);
        const realCredits = Number(storeU.realCredits ?? storeU.credits ?? u.realCredits ?? 0);
        const demoCredits = Number(storeU.demoCredits ?? u.demoCredits ?? 100);

        return {
          uid: u.uid,
          userId: u.uid,
          name: u.name || storeU.displayName || 'Trader',
          displayName: u.name || storeU.displayName || (u.email ? u.email.split('@')[0] : u.uid),
          email: u.email || storeU.email || '',
          phone: u.phone || storeU.phone || '',
          phoneVerified: Boolean(u.phoneVerified || (u.phone && u.phone.length >= 10)),
          kycStatus: u.kycStatus || 'unverified',
          status: isSuspended ? 'suspended' : 'active',
          suspended: isSuspended,
          tradingBalance,
          realCredits,
          credits: realCredits,
          demoCredits,
          joinedAt: u.createdAt || storeU.joinedAt || new Date().toISOString(),
          lastActive: u.lastLoginAt || storeU.lastActive || u.createdAt
        };
      });

      const totalCount = users.length;
      return res.json({ ok: true, users, totalCount });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to list users', details: err.message });
    }
  });

  // Get single user full dossier
  router.get('/users/:uid', (req, res) => {
    try {
      const { uid } = req.params;
      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) return res.status(404).json({ error: 'User not found' });

      const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid) || { demoCredits: 0, realCredits: 0 };
      const ledger = db.queryAll('SELECT * FROM wallet_ledger WHERE uid = ? ORDER BY createdAt DESC LIMIT 50', uid);
      const payments = db.queryAll('SELECT * FROM payments WHERE uid = ? ORDER BY createdAt DESC', uid);
      const trades = db.queryAll('SELECT * FROM trades WHERE uid = ? ORDER BY openedAt DESC LIMIT 50', uid);
      const tickets = db.queryAll('SELECT * FROM support_tickets WHERE uid = ? ORDER BY updatedAt DESC', uid);
      const promoRedemptions = db.queryAll(`
        SELECT pr.*, pc.code FROM promo_redemptions pr
        JOIN promo_codes pc ON pr.codeId = pc.id
        WHERE pr.uid = ? ORDER BY pr.createdAt DESC
      `, uid);

      return res.json({
        user,
        wallet,
        ledger,
        payments,
        trades,
        tickets,
        promoRedemptions
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to load user dossier', details: err.message });
    }
  });

  // Change user account status (active, suspended, banned)
  router.post('/users/:uid/status', (req, res) => {
    try {
      const { uid } = req.params;
      const { status, reason = '' } = req.body;
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';

      if (!['active', 'suspended', 'banned'].includes(status)) {
        return res.status(400).json({ error: 'Invalid status. Must be active, suspended, or banned.' });
      }

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) return res.status(404).json({ error: 'User not found' });

      const nowIso = new Date().toISOString();

      db.runTransaction(() => {
        db.execute('UPDATE users SET status = ? WHERE uid = ?', status, uid);

        // Audit log
        db.execute(`
          INSERT INTO audit_logs (actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES ('admin', ?, 'CHANGE_USER_STATUS', 'users', ?, ?, ?, ?, ?, ?)
        `, adminEmail, uid, JSON.stringify({ status: user.status }), JSON.stringify({ status, reason }), req.ip || '', req.headers['user-agent'] || '', nowIso);
      });

      sendToUser(uid, 'account_status', { status, reason });

      return res.json({ success: true, message: `User status changed to ${status}.` });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update user status', details: err.message });
    }
  });

  // Adjust User Credits (Atomic with ledger record)
  router.post('/users/:uid/adjust-credits', (req, res) => {
    try {
      const { uid } = req.params;
      const { account = 'real', amount, type = 'admin_adjust', reason } = req.body;
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';

      if (!reason?.trim()) {
        return res.status(400).json({ error: 'A mandatory reason is required for manual credit adjustments.' });
      }

      const numAmount = Number(amount);
      if (!Number.isFinite(numAmount) || numAmount === 0) {
        return res.status(400).json({ error: 'Amount must be a non-zero number.' });
      }

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) return res.status(404).json({ error: 'User not found' });

      let wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
      if (!wallet) {
        db.execute('INSERT INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', uid);
        wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
      }

      const currentBalance = account === 'demo' ? wallet.demoCredits : wallet.realCredits;
      const newBalance = Number((currentBalance + numAmount).toFixed(2));

      if (newBalance < 0) {
        return res.status(400).json({ error: `Insufficient credits. Cannot adjust below 0 (Current: ₹${currentBalance}).` });
      }

      const nowIso = new Date().toISOString();
      let updatedWallet = null;

      db.runTransaction(() => {
        if (account === 'demo') {
          db.execute('UPDATE wallets SET demoCredits = ? WHERE uid = ?', newBalance, uid);
          updatedWallet = { demoCredits: newBalance, realCredits: wallet.realCredits };
        } else {
          db.execute('UPDATE wallets SET realCredits = ? WHERE uid = ?', newBalance, uid);
          updatedWallet = { demoCredits: wallet.demoCredits, realCredits: newBalance };
        }

        // Ledger row
        db.execute(`
          INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, uid, account, type, numAmount, newBalance, `ADMIN-${Date.now()}`, reason.trim(), nowIso);

        // Notification
        db.execute(`
          INSERT INTO notifications (uid, title, body, readAt, createdAt)
          VALUES (?, 'Wallet Balance Adjusted', ?, NULL, ?)
        `, uid, `Admin adjusted your ${account} balance by ₹${numAmount > 0 ? '+' : ''}${numAmount}. Reason: ${reason.trim()}`, nowIso);

        // Audit log
        db.execute(`
          INSERT INTO audit_logs (actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES ('admin', ?, 'ADJUST_CREDITS', 'wallets', ?, ?, ?, ?, ?, ?)
        `, adminEmail, uid, JSON.stringify({ [account]: currentBalance }), JSON.stringify({ [account]: newBalance, reason }), req.ip || '', req.headers['user-agent'] || '', nowIso);
      });

      // Realtime push
      sendToUser(uid, 'wallet_update', updatedWallet);
      sendToUser(uid, 'notification', {
        title: 'Wallet Balance Adjusted',
        body: `Your ${account} balance was adjusted by ₹${numAmount > 0 ? '+' : ''}${numAmount}.`
      });

      return res.json({
        success: true,
        message: `Successfully adjusted ${account} credits by ₹${numAmount}.`,
        wallet: updatedWallet
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to adjust credits', details: err.message });
    }
  });

  // KYC Review (approve / reject)
  router.post('/users/:uid/kyc', (req, res) => {
    try {
      const { uid } = req.params;
      const { decision, reason = '' } = req.body;
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';

      if (!['verified', 'rejected'].includes(decision)) {
        return res.status(400).json({ error: 'Decision must be verified or rejected.' });
      }

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) return res.status(404).json({ error: 'User not found' });

      const nowIso = new Date().toISOString();

      db.runTransaction(() => {
        db.execute('UPDATE users SET kycStatus = ? WHERE uid = ?', decision, uid);

        // Audit log
        db.execute(`
          INSERT INTO audit_logs (actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES ('admin', ?, 'REVIEW_KYC', 'users', ?, ?, ?, ?, ?, ?)
        `, adminEmail, uid, JSON.stringify({ kycStatus: user.kycStatus }), JSON.stringify({ kycStatus: decision, reason }), req.ip || '', req.headers['user-agent'] || '', nowIso);

        // Notification
        db.execute(`
          INSERT INTO notifications (uid, title, body, readAt, createdAt)
          VALUES (?, ?, ?, NULL, ?)
        `, uid, decision === 'verified' ? 'KYC Verification Approved' : 'KYC Verification Update',
           decision === 'verified' ? 'Your identity verification has been approved!' : `KYC rejected: ${reason}`, nowIso);
      });

      sendToUser(uid, 'kyc_status', { kycStatus: decision, reason });

      return res.json({ success: true, kycStatus: decision });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update KYC status', details: err.message });
    }
  });

  // ==========================================
  // 7.4 LIVE FUNDS & WALLETS
  // ==========================================
  router.get('/funds', (req, res) => {
    try {
      const wallets = db.queryAll(`
        SELECT w.*, u.name, u.email, u.phone, u.status
        FROM wallets w
        JOIN users u ON w.uid = u.uid
        ORDER BY w.realCredits DESC
        LIMIT 100
      `);

      const summary = db.queryOne(`
        SELECT
          COUNT(*) as userCount,
          COALESCE(SUM(realCredits), 0) as totalReal,
          COALESCE(SUM(demoCredits), 0) as totalDemo
        FROM wallets
      `);

      return res.json({ wallets, summary });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch funds', details: err.message });
    }
  });

  // ==========================================
  // 7.5 LIVE TRADES MONITOR
  // ==========================================
  router.get('/trades', (req, res) => {
    try {
      const { status, account, limit = 100 } = req.query;
      let sql = `
        SELECT t.*, u.name, u.email
        FROM trades t
        LEFT JOIN users u ON t.uid = u.uid
        WHERE 1=1
      `;
      const params = [];

      if (status && status !== 'all') {
        sql += ' AND t.status = ?';
        params.push(status);
      }
      if (account && account !== 'all') {
        sql += ' AND t.account = ?';
        params.push(account);
      }

      sql += ' ORDER BY t.openedAt DESC LIMIT ?';
      params.push(Number(limit));

      const trades = db.queryAll(sql, ...params);
      return res.json({ trades });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch trades', details: err.message });
    }
  });

  // ==========================================
  // 7.10 AUDIT LOGS
  // ==========================================
  router.get('/audit-logs', (req, res) => {
    try {
      const { action, entity, limit = 100, offset = 0 } = req.query;
      let sql = 'SELECT * FROM audit_logs WHERE 1=1';
      const params = [];

      if (action) {
        sql += ' AND action = ?';
        params.push(action);
      }
      if (entity) {
        sql += ' AND entity = ?';
        params.push(entity);
      }

      sql += ' ORDER BY createdAt DESC LIMIT ? OFFSET ?';
      params.push(Number(limit), Number(offset));

      const logs = db.queryAll(sql, ...params);
      const totalCount = db.queryOne('SELECT COUNT(*) as count FROM audit_logs')?.count || 0;

      return res.json({ logs, totalCount });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch audit logs', details: err.message });
    }
  });

  // ==========================================
  // 7.11 SYSTEM SETTINGS
  // ==========================================
  router.get('/settings', (req, res) => {
    try {
      const rows = db.queryAll('SELECT * FROM settings');
      const settings = {};
      for (const r of rows) {
        settings[r.key] = r.value;
      }
      return res.json({ settings });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch settings', details: err.message });
    }
  });

  router.post('/settings', (req, res) => {
    try {
      const updates = req.body;
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';
      const nowIso = new Date().toISOString();

      db.runTransaction(() => {
        for (const [key, val] of Object.entries(updates)) {
          db.execute(`
            INSERT INTO settings (key, value, updatedAt)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updatedAt = excluded.updatedAt
          `, key, String(val), nowIso);
        }

        db.execute(`
          INSERT INTO audit_logs (actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES ('admin', ?, 'UPDATE_SETTINGS', 'settings', 'global', NULL, ?, ?, ?, ?)
        `, adminEmail, JSON.stringify(updates), req.ip || '', req.headers['user-agent'] || '', nowIso);
      });

      return res.json({ success: true, message: 'Settings updated successfully.' });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update settings', details: err.message });
    }
  });

  // ==========================================
  // 7.12 PROMO / REDEEM CODES DESK
  // ==========================================
  router.get('/promos', (req, res) => {
    try {
      const codes = db.queryAll(`
        SELECT pc.*,
          (SELECT COUNT(*) FROM promo_redemptions pr WHERE pr.codeId = pc.id) as totalRedemptions,
          (SELECT COALESCE(SUM(pr.creditsGiven), 0) FROM promo_redemptions pr WHERE pr.codeId = pc.id) as totalCreditsDistributed
        FROM promo_codes pc
        ORDER BY pc.createdAt DESC
      `);
      return res.json({ ok: true, promos: codes, codes });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch promo codes', details: err.message });
    }
  });

  router.post('/promos/create', (req, res) => {
    try {
      const {
        code,
        credits,
        maxUses = 10,
        perUserLimit = 1,
        expiresAt = null,
        note = ''
      } = req.body;

      const numCredits = Number(credits);
      if (!Number.isFinite(numCredits) || numCredits <= 0) {
        return res.status(400).json({ error: 'Credits must be a positive number' });
      }

      const cleanCode = String(code || '').trim().toUpperCase();
      if (!cleanCode) {
        return res.status(400).json({ error: 'Promo code cannot be empty' });
      }

      // Check if code exists
      const existing = db.queryOne('SELECT id FROM promo_codes WHERE UPPER(code) = ?', cleanCode);
      if (existing) {
        return res.status(400).json({ error: `Promo code ${cleanCode} already exists.` });
      }

      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';
      const nowIso = new Date().toISOString();
      const promoId = `pc-${Date.now()}`;

      db.execute(`
        INSERT INTO promo_codes (id, code, credits, maxUses, usedCount, perUserLimit, expiresAt, active, createdBy, createdAt, note)
        VALUES (?, ?, ?, ?, 0, ?, ?, 1, ?, ?, ?)
      `, promoId, cleanCode, numCredits, Number(maxUses), Number(perUserLimit), expiresAt || null, adminEmail, nowIso, note || 'Admin generated');

      db.execute(`
        INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, after, createdAt)
        VALUES (?, 'admin', ?, 'CREATE_PROMO', 'promo_codes', ?, ?, ?)
      `, `audit-${Date.now()}`, adminEmail, promoId, JSON.stringify({ code: cleanCode, credits: numCredits, maxUses }), nowIso);

      const created = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', promoId);
      return res.json({ ok: true, message: `Redeem code ${cleanCode} created successfully!`, promo: created });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to create promo code', details: err.message });
    }
  });

  router.post('/promos/:id/toggle', (req, res) => {
    try {
      const { id } = req.params;
      const promo = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!promo) return res.status(404).json({ error: 'Promo code not found' });

      const newActive = promo.active ? 0 : 1;
      db.execute('UPDATE promo_codes SET active = ? WHERE id = ?', newActive, id);

      return res.json({ ok: true, active: newActive, message: `Promo code ${promo.code} is now ${newActive ? 'active' : 'deactivated'}.` });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to toggle promo code', details: err.message });
    }
  });

  router.delete('/promos/:id', (req, res) => {
    try {
      const { id } = req.params;
      const promo = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!promo) return res.status(404).json({ error: 'Promo code not found' });

      db.execute('DELETE FROM promo_codes WHERE id = ?', id);
      return res.json({ ok: true, message: `Promo code ${promo.code} deleted successfully.` });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to delete promo code', details: err.message });
    }
  });

  return router;
}
