import fs from 'node:fs';
import path from 'node:path';

function walk(dir) {
  let files = [];
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      if (item !== 'node_modules' && item !== '.git' && item !== 'dist') {
        files = files.concat(walk(full));
      }
    } else if (full.endsWith('.tsx') || full.endsWith('.ts')) {
      files.push(full);
    }
  }
  return files;
}

const hooks = ['useMemo', 'useCallback', 'useState', 'useEffect', 'useRef', 'useContext'];
const files = walk('./src');
let totalIssues = 0;

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  for (const hook of hooks) {
    const regex = new RegExp(`\\b${hook}\\b`);
    if (regex.test(content)) {
      const hasImport = new RegExp(`import\\s+[^;]*\\b${hook}\\b[^;]*from\\s+['"][^'"]+['"]`).test(content);
      const hasReactDot = new RegExp(`React\\.${hook}`).test(content);
      const isDef = new RegExp(`(function|const|export function)\\s+${hook}\\b`).test(content);
      if (!hasImport && !hasReactDot && !isDef) {
        console.error(`❌ MISSING ${hook} import in: ${file}`);
        totalIssues++;
      }
    }
  }
}

if (totalIssues === 0) {
  console.log('✅ ALL React hook imports (useMemo, useCallback, useState, useEffect, useRef, useContext) verified 100% OK in all src files!');
} else {
  console.error(`Found ${totalIssues} issues!`);
  process.exit(1);
}
