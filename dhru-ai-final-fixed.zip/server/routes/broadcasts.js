// DHRU.AI - Broadcasts, Posters & Announcement Engine
// Delivers site-wide announcements, modal popups, floating banners, and promotional posters.

import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { broadcastToAll } from '../services/realtimeStream.js';
import { requireAdminAuth } from './adminAuth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const BROADCAST_FILE = path.join(__dirname, '..', 'data', 'system-broadcast.json');

function saveBroadcastJson(bc) {
  try {
    const dir = path.dirname(BROADCAST_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(BROADCAST_FILE, JSON.stringify(bc, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[Broadcasts] Failed to save JSON fallback:', err.message);
  }
}

function loadBroadcastJson() {
  try {
    if (fs.existsSync(BROADCAST_FILE)) {
      return JSON.parse(fs.readFileSync(BROADCAST_FILE, 'utf-8'));
    }
  } catch {}
  return null;
}

export function createBroadcastsRouter() {
  const router = express.Router();
  router.use(express.json());

  // ==========================================
  // USER ENDPOINTS
  // ==========================================

  // Get active broadcasts for current user
  router.get('/active', (req, res) => {
    try {
      const { uid, accountType = 'all' } = req.query;
      const nowIso = new Date().toISOString();

      let sql = `
        SELECT b.*
        FROM broadcasts b
        WHERE (b.startsAt IS NULL OR b.startsAt <= ?)
          AND (b.expiresAt IS NULL OR b.expiresAt >= ?)
          AND (b.target = 'all' OR b.target = ? OR b.target LIKE ?)
      `;
      const params = [nowIso, nowIso, accountType, `%${uid}%`];

      // Exclude already seen if uid is provided
      if (uid) {
        sql += `
          AND b.id NOT IN (
            SELECT broadcastId FROM broadcast_receipts WHERE uid = ?
          )
        `;
        params.push(uid);
      }

      sql += ' ORDER BY b.createdAt DESC LIMIT 10';

      let items = [];
      try {
        items = db.queryAll(sql, ...params);
      } catch (e) {
        console.warn('[Broadcasts] DB query fallback:', e.message);
      }

      // If DB returned nothing, check file fallback
      if (items.length === 0) {
        const fileBc = loadBroadcastJson();
        if (fileBc && fileBc.active && fileBc.title) {
          items.push({
            id: fileBc.id || 'bc-active',
            type: fileBc.type || 'poster',
            title: fileBc.title,
            body: fileBc.message || fileBc.body || '',
            imageUrl: fileBc.imageUrl || '',
            target: fileBc.target || 'all',
            createdAt: fileBc.updatedAt || nowIso
          });
        }
      }

      const activeItem = items.length > 0 ? items[0] : null;

      return res.json({
        ok: true,
        broadcasts: items,
        active: activeItem,
        broadcast: activeItem ? {
          ...activeItem,
          active: true,
          message: activeItem.body || activeItem.message || ''
        } : null
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch broadcasts', details: err.message });
    }
  });

  // User dismisses / marks as seen
  router.post('/dismiss', (req, res) => {
    try {
      const { broadcastId, uid } = req.body;
      if (!broadcastId || !uid) {
        return res.status(400).json({ error: 'broadcastId and uid are required' });
      }

      const nowIso = new Date().toISOString();
      try {
        db.execute(`
          INSERT OR IGNORE INTO broadcast_receipts (broadcastId, uid, seenAt)
          VALUES (?, ?, ?)
        `, broadcastId, uid, nowIso);
      } catch {}

      return res.json({ success: true, ok: true });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to dismiss broadcast', details: err.message });
    }
  });

  // ==========================================
  // ADMIN ENDPOINTS (requireAdminAuth)
  // ==========================================

  // List all broadcasts with receipt counts
  router.get('/admin/list', requireAdminAuth, (req, res) => {
    try {
      let broadcasts = [];
      try {
        broadcasts = db.queryAll(`
          SELECT b.*,
            (SELECT COUNT(*) FROM broadcast_receipts r WHERE r.broadcastId = b.id) as seenCount
          FROM broadcasts b
          ORDER BY b.createdAt DESC
        `);
      } catch {}

      if (broadcasts.length === 0) {
        const fileBc = loadBroadcastJson();
        if (fileBc && fileBc.title) {
          broadcasts.push({
            id: fileBc.id || 'bc-active',
            type: fileBc.type || 'poster',
            title: fileBc.title,
            body: fileBc.message || fileBc.body || '',
            imageUrl: fileBc.imageUrl || '',
            target: fileBc.target || 'all',
            createdAt: fileBc.updatedAt || new Date().toISOString(),
            seenCount: 0
          });
        }
      }

      return res.json({ ok: true, broadcasts });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch broadcasts', details: err.message });
    }
  });

  // Create new broadcast / poster
  router.post('/admin/create', requireAdminAuth, (req, res) => {
    try {
      const {
        type = 'poster', // 'poster' | 'popup' | 'banner' | 'message'
        title,
        message,
        body = '',
        imageUrl = '',
        target = 'all', // 'all' | 'real' | 'demo'
        startsAt = null,
        expiresAt = null
      } = req.body;

      const finalTitle = String(title ?? '').trim();
      const finalBody = String(body || message || '').trim();

      if (!finalTitle) {
        return res.status(400).json({ error: 'Title is required for broadcasting.' });
      }

      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const nowIso = new Date().toISOString();
      const newId = `bc-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

      db.runTransaction(() => {
        db.execute(`
          INSERT INTO broadcasts (id, type, title, body, imageUrl, target, startsAt, expiresAt, createdBy, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, newId, type.toLowerCase(), finalTitle, finalBody, imageUrl.trim(), target, startsAt || nowIso, expiresAt || null, adminEmail, nowIso);

        // Audit log
        db.execute(`
          INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES (?, 'admin', ?, 'CREATE_BROADCAST', 'broadcasts', ?, NULL, ?, ?, ?, ?)
        `, `audit-${Date.now()}`, adminEmail, String(newId), JSON.stringify({ type, title: finalTitle, target }), req.ip || '', req.headers['user-agent'] || '', nowIso);
      });

      const fullBroadcast = db.queryOne('SELECT * FROM broadcasts WHERE id = ?', newId) || {
        id: newId,
        type,
        title: finalTitle,
        body: finalBody,
        message: finalBody,
        imageUrl: imageUrl.trim(),
        target,
        createdAt: nowIso
      };

      // Also persist to JSON file for fallback synchronization
      saveBroadcastJson({
        id: newId,
        active: true,
        title: finalTitle,
        message: finalBody,
        body: finalBody,
        type: type.toUpperCase(),
        imageUrl: imageUrl.trim(),
        target,
        updatedAt: nowIso,
        createdBy: adminEmail
      });

      // Dispatch real-time SSE to all connected users
      broadcastToAll('new_broadcast', {
        ...fullBroadcast,
        message: finalBody,
        active: true
      });

      return res.json({
        ok: true,
        success: true,
        message: 'Broadcast and poster published system-wide successfully.',
        broadcast: fullBroadcast
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to create broadcast', details: err.message });
    }
  });

  // Delete broadcast / poster
  router.delete('/admin/:id', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const nowIso = new Date().toISOString();

      try {
        db.runTransaction(() => {
          db.execute('DELETE FROM broadcast_receipts WHERE broadcastId = ?', id);
          db.execute('DELETE FROM broadcasts WHERE id = ?', id);

          db.execute(`
            INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
            VALUES (?, 'admin', ?, 'DELETE_BROADCAST', 'broadcasts', ?, NULL, NULL, ?, ?, ?)
          `, `audit-${Date.now()}`, adminEmail, String(id), req.ip || '', req.headers['user-agent'] || '', nowIso);
        });
      } catch {}

      // Clear JSON if active
      saveBroadcastJson({ active: false, title: '', message: '', type: 'INFO', updatedAt: nowIso });

      return res.json({ ok: true, success: true, message: 'Broadcast deleted' });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to delete broadcast', details: err.message });
    }
  });

  return router;
}
