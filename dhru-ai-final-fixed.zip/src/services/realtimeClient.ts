// DHRU.AI - Client-Side Real-Time Stream Engine
// Connects to /api/stream/user and /api/stream/admin via Server-Sent Events (SSE)
// Includes exponential backoff auto-reconnect and 10-second polling fallback.

export interface UserStreamHandlers {
  onSnapshot?: (data: any) => void;
  onWalletUpdate?: (data: { demoCredits: number; realCredits: number }) => void;
  onPaymentStatus?: (payment: any) => void;
  onNotification?: (notification: any) => void;
  onBroadcast?: (broadcast: any) => void;
  onSupportMessage?: (message: any) => void;
}

export interface AdminStreamHandlers {
  onAdminSnapshot?: (data: any) => void;
  onNewPayment?: (payment: any) => void;
  onPaymentApproved?: (payment: any) => void;
  onPaymentRejected?: (payment: any) => void;
  onNewTicket?: (ticket: any) => void;
  onNewMessage?: (message: any) => void;
  onOnlineCount?: (data: { count: number }) => void;
  onTradeEvent?: (trade: any) => void;
}

/**
 * Connect to User Real-Time Stream
 */
export function connectUserStream(uid: string, handlers: UserStreamHandlers): () => void {
  if (!uid || typeof window === 'undefined') return () => {};

  let eventSource: EventSource | null = null;
  let reconnectAttempts = 0;
  let isClosed = false;
  let pollInterval: ReturnType<typeof setInterval> | null = null;

  const startPollingFallback = () => {
    if (pollInterval || isClosed) return;
    pollInterval = setInterval(async () => {
      try {
        const res = await fetch(`/api/user/sync?uid=${encodeURIComponent(uid)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.wallet && handlers.onWalletUpdate) handlers.onWalletUpdate(data.wallet);
          if (data.notifications && handlers.onNotification) handlers.onNotification(data.notifications);
        }
      } catch {}
    }, 10000);
  };

  const stopPollingFallback = () => {
    if (pollInterval) {
      clearInterval(pollInterval);
      pollInterval = null;
    }
  };

  const connect = () => {
    if (isClosed) return;
    try {
      eventSource = new EventSource(`/api/stream/user?uid=${encodeURIComponent(uid)}`);

      eventSource.onopen = () => {
        reconnectAttempts = 0;
        stopPollingFallback();
      };

      eventSource.addEventListener('snapshot', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onSnapshot?.(data);
          if (data.wallet && handlers.onWalletUpdate) handlers.onWalletUpdate(data.wallet);
        } catch {}
      });

      eventSource.addEventListener('wallet_update', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onWalletUpdate?.(data);
        } catch {}
      });

      eventSource.addEventListener('payment_status', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onPaymentStatus?.(data);
        } catch {}
      });

      eventSource.addEventListener('notification', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onNotification?.(data);
        } catch {}
      });

      eventSource.addEventListener('broadcast', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onBroadcast?.(data);
        } catch {}
      });

      eventSource.addEventListener('support_message', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onSupportMessage?.(data);
        } catch {}
      });

      eventSource.onerror = () => {
        eventSource?.close();
        eventSource = null;
        startPollingFallback();

        if (!isClosed) {
          reconnectAttempts++;
          const delay = Math.min(15000, 1000 * Math.pow(2, reconnectAttempts));
          setTimeout(connect, delay);
        }
      };
    } catch {
      startPollingFallback();
    }
  };

  connect();

  return () => {
    isClosed = true;
    eventSource?.close();
    stopPollingFallback();
  };
}

/**
 * Connect to Admin Real-Time Stream
 */
export function connectAdminStream(token: string, handlers: AdminStreamHandlers): () => void {
  if (!token || typeof window === 'undefined') return () => {};

  let eventSource: EventSource | null = null;
  let reconnectAttempts = 0;
  let isClosed = false;
  let pollInterval: ReturnType<typeof setInterval> | null = null;

  const startPollingFallback = () => {
    if (pollInterval || isClosed) return;
    pollInterval = setInterval(async () => {
      try {
        const res = await fetch('/api/admin/overview', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          handlers.onAdminSnapshot?.(data);
        }
      } catch {}
    }, 10000);
  };

  const stopPollingFallback = () => {
    if (pollInterval) {
      clearInterval(pollInterval);
      pollInterval = null;
    }
  };

  const connect = () => {
    if (isClosed) return;
    try {
      // Pass token in authorization query parameter for EventSource
      eventSource = new EventSource(`/api/stream/admin?token=${encodeURIComponent(token)}`);

      eventSource.onopen = () => {
        reconnectAttempts = 0;
        stopPollingFallback();
      };

      eventSource.addEventListener('admin_snapshot', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onAdminSnapshot?.(data);
        } catch {}
      });

      eventSource.addEventListener('new_payment', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onNewPayment?.(data);
        } catch {}
      });

      eventSource.addEventListener('payment_approved', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onPaymentApproved?.(data);
        } catch {}
      });

      eventSource.addEventListener('payment_rejected', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onPaymentRejected?.(data);
        } catch {}
      });

      eventSource.addEventListener('new_ticket', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onNewTicket?.(data);
        } catch {}
      });

      eventSource.addEventListener('new_message', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onNewMessage?.(data);
        } catch {}
      });

      eventSource.addEventListener('online_users_count', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onOnlineCount?.(data);
        } catch {}
      });

      eventSource.addEventListener('trade_event', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          handlers.onTradeEvent?.(data);
        } catch {}
      });

      eventSource.onerror = () => {
        eventSource?.close();
        eventSource = null;
        startPollingFallback();

        if (!isClosed) {
          reconnectAttempts++;
          const delay = Math.min(15000, 1000 * Math.pow(2, reconnectAttempts));
          setTimeout(connect, delay);
        }
      };
    } catch {
      startPollingFallback();
    }
  };

  connect();

  return () => {
    isClosed = true;
    eventSource?.close();
    stopPollingFallback();
  };
}
