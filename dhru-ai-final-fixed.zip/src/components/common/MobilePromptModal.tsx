import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Phone, Shield, ArrowRight, AlertTriangle } from 'lucide-react';

export const MobilePromptModal: React.FC = () => {
  const { user, updateUserProfile } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  // Check if user has an existing valid phone number in state or local persistent store
  const storedPhone = typeof window !== 'undefined'
    ? ((user?.uid && localStorage.getItem(`dhru_user_phone_${user.uid}`)) || localStorage.getItem('dhru_saved_phone') || '')
    : '';

  const hasValidPhone = Boolean(
    (user?.phone && user.phone.replace(/\D/g, '').length >= 10) ||
    (storedPhone && storedPhone.replace(/\D/g, '').length >= 10)
  );

  // If phone is in localStorage but missing from active state, auto-restore once
  useEffect(() => {
    if (user && (!user.phone || user.phone.replace(/\D/g, '').length < 10) && storedPhone) {
      updateUserProfile({
        phone: storedPhone,
        phoneVerified: true,
        kycStatus: 'verified'
      });
    }
  }, [user, storedPhone, updateUserProfile]);

  // Strictly open if user is logged in but has no valid phone number
  const isOpen = Boolean(user && !hasValidPhone);

  useEffect(() => {
    if (user?.phone) {
      setPhoneNumber(user.phone.replace(/^\+91\s*/, ''));
    } else if (storedPhone) {
      setPhoneNumber(storedPhone.replace(/^\+91\s*/, ''));
    }
  }, [user?.phone, storedPhone]);

  if (!isOpen || !user) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const clean = phoneNumber.trim().replace(/\s+/g, '');
    const digitsOnly = clean.replace(/\D/g, '');

    if (digitsOnly.length < 10) {
      setError('Mobile number is required. Please enter a valid 10-digit mobile number.');
      return;
    }

    setSaving(true);
    const formatted = clean.startsWith('+') ? clean : `+91 ${digitsOnly.slice(-10)}`;

    try {
      // 1. Immediately persist to localStorage so it is never requested again
      if (user.uid) {
        localStorage.setItem(`dhru_user_phone_${user.uid}`, formatted);
      }
      localStorage.setItem('dhru_saved_phone', formatted);

      // 2. Sync to backend verification endpoint
      await fetch('/api/user/verify-phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: user.uid,
          phone: formatted
        })
      }).catch(() => {});

      // 3. Update user profile state
      updateUserProfile({
        phone: formatted,
        phoneVerified: true,
        kycStatus: 'verified'
      });
    } catch {
      updateUserProfile({
        phone: formatted,
        phoneVerified: true,
        kycStatus: 'verified'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in pointer-events-auto">
      <div className="relative w-full max-w-md bg-surface border border-line rounded-3xl shadow-2xl p-6 overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-48 h-48 bg-brand-fill/15 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center gap-3 pb-4 border-b border-line mb-4">
          <div className="w-10 h-10 rounded-2xl bg-brand/10 border border-brand/20 flex items-center justify-center text-brand shrink-0">
            <Phone className="w-5 h-5 text-amber-500" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-ink tracking-tight flex items-center gap-1.5">
              <span>Mandatory Mobile Verification</span>
            </h3>
            <p className="text-xs text-ink-2">Trader profile verification is required</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-3 rounded-2xl bg-surface-2 border border-line flex items-center gap-3">
            {user.photoURL ? (
              <img src={user.photoURL} alt={user.displayName} className="w-10 h-10 rounded-full object-cover ring-2 ring-brand shrink-0" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-brand-fill text-white font-black text-sm flex items-center justify-center shrink-0">
                {(user.displayName || 'T').charAt(0).toUpperCase()}
              </div>
            )}
            <div className="overflow-hidden">
              <div className="font-bold text-sm text-ink truncate">{user.displayName || 'Active Trader'}</div>
              <div className="text-xs text-ink-2 truncate">{user.email || user.uid}</div>
            </div>
          </div>

          <div className="rounded-xl p-3 bg-amber-500/10 border border-amber-500/20 text-xs text-amber-600 dark:text-amber-300 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              In compliance with trading risk and payment verification protocols, all traders must link a verified mobile number before entering the dashboard.
            </p>
          </div>

          <form onSubmit={handleSave} className="space-y-3 pt-1">
            <div>
              <label className="block text-xs font-bold text-ink mb-1.5">
                Enter Your Mobile Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-ink-3">🇮🇳 +91</span>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={e => {
                    setError('');
                    setPhoneNumber(e.target.value);
                  }}
                  placeholder="98765 43210"
                  className="w-full pl-16 pr-4 py-2.5 rounded-xl bg-surface border border-line focus:border-brand outline-none text-xs font-mono font-bold text-ink"
                  autoFocus
                  required
                />
              </div>
              {error && <p className="text-[11px] text-rose-500 mt-1 font-mono">{error}</p>}
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-ink-3">
              <Shield className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Used exclusively for trade alerts and instant UPI payment approvals.</span>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 rounded-xl bg-brand-fill hover:opacity-90 text-on-brand font-bold text-xs uppercase font-mono tracking-wider flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all cursor-pointer disabled:opacity-50"
              >
                <span>{saving ? 'Verifying & Saving...' : 'Save & Enter Dashboard'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
