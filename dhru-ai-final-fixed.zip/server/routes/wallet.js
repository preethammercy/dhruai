import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { broadcastToAdmin, sendToUser } from '../services/realtimeStream.js';
import { approvePayment, rejectPayment } from '../services/paymentCore.js';
import { requireAdminAuth } from './adminAuth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');

const UPI_TARGET_VPA = 'preethamrishu@axl';
const UPI_PAYEE_NAME = 'DHRU AI Quantitative Markets';
const ORDER_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes exact expiry

function loadWalletStore() {
  try {
    if (fs.existsSync(WALLET_FILE)) {
      return JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    }
  } catch (err) {
    console.warn('[WalletStore] Failed to load wallet store:', err.message);
  }
  return { users: {}, orders: {} };
}

function saveWalletStore(store) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(WALLET_FILE, JSON.stringify(store, null, 2), 'utf8');
  } catch (err) {
    console.error('[WalletStore] Failed to persist wallet store:', err.message);
  }
}

export function createWalletRouter() {
  const router = express.Router();
  router.use(express.json());

  // 1. Get Wallet State
  router.get('/state', (req, res) => {
    const userId = req.query.userId || 'default-user';
    const store = loadWalletStore();
    const sqlW = store.users[userId] ? null : db.queryOne('SELECT demoCredits, realCredits, tradingBalance FROM wallets WHERE uid = ?', userId);
    const user = store.users[userId] || {
      credits: Number(sqlW?.realCredits || 0),
      realCredits: Number(sqlW?.realCredits || 0),
      demoCredits: Number(sqlW?.demoCredits ?? 100), // Only Demo account starts with 100 free credits
      tradingBalance: Number(sqlW?.tradingBalance || 0),
      totalCreditsPurchased: 0,
      premiumUnlocked: false,
      history: []
    };
    res.json({ ok: true, wallet: user, targetVpa: UPI_TARGET_VPA });
  });

  // 1b. Sync User on Login / Registration
  router.post('/sync-user', (req, res) => {
    try {
      const { uid, email = '', displayName = '', phone = '' } = req.body;
      if (!uid) {
        return res.status(400).json({ error: 'UID is required' });
      }
      const store = loadWalletStore();
      if (!store.users[uid]) {
        store.users[uid] = {
          uid,
          displayName: displayName || (email ? email.split('@')[0] : uid),
          email: email || '',
          phone: phone || '',
          credits: 0, // Real account starts at 0 credits
          realCredits: 0,
          demoCredits: 100, // Only demo account gets 100 free credits
          tradingBalance: 0,
          totalCreditsPurchased: 0,
          premiumUnlocked: false,
          joinedAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
          history: []
        };
      } else {
        if (displayName) store.users[uid].displayName = displayName;
        if (email) store.users[uid].email = email;
        if (phone) store.users[uid].phone = phone;
        if (store.users[uid].demoCredits === undefined) store.users[uid].demoCredits = 100;
        store.users[uid].lastActive = new Date().toISOString();
      }
      saveWalletStore(store);

      // Dual-Sync to SQLite database
      try {
        const clientIp = req.ip || req.socket.remoteAddress || '';
        const nowIso = new Date().toISOString();
        const existing = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
        if (!existing) {
          db.execute(`
            INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt, lastIp)
            VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?, ?)
          `, uid, displayName || (email ? email.split('@')[0] : uid), email || null, phone || null, phone ? 1 : 0, nowIso, nowIso, clientIp);
          db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', uid);
          db.execute(`
            INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
            VALUES (?, 'demo', 'promo', 100, 100, 'Welcome 100 Demo Starting Credits', ?)
          `, uid, nowIso);
          broadcastToAdmin('new_signup', { uid, name: displayName || email || uid, email, phone });
        } else {
          db.execute('UPDATE users SET lastLoginAt = ?, lastIp = ? WHERE uid = ?', nowIso, clientIp, uid);
          if (displayName) db.execute('UPDATE users SET name = ? WHERE uid = ?', displayName, uid);
          if (email) db.execute('UPDATE users SET email = ? WHERE uid = ?', email, uid);
          if (phone) db.execute('UPDATE users SET phone = ?, phoneVerified = 1 WHERE uid = ?', phone, uid);
        }
      } catch (err) {
        console.warn('[WalletStore] Dual-sync SQLite warning:', err.message);
      }

      res.json({ ok: true, user: store.users[uid] });
    } catch (err) {
      res.status(500).json({ error: 'Failed to sync user', details: err.message });
    }
  });

  // 2. Create 10-Minute UPI Payment Order
  router.post('/create-upi-order', (req, res) => {
    try {
      const { type = 'credits', amount = 499, credits = 500, userId = 'default-user' } = req.body;
      const numAmount = Number(amount);
      if (!Number.isFinite(numAmount) || numAmount <= 0) {
        return res.status(400).json({ error: 'Valid payment amount is required' });
      }

      const orderId = `DHRU-UPI-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const expiresAt = Date.now() + ORDER_EXPIRY_MS;
      
      const transactionNote = type === 'credits'
        ? `DHRU AI ${credits} Credits (${orderId})`
        : `DHRU Trading Fund Deposit (${orderId})`;

      // Standard NPCI UPI URI Scheme
      const upiUri = `upi://pay?pa=${encodeURIComponent(UPI_TARGET_VPA)}&pn=${encodeURIComponent(UPI_PAYEE_NAME)}&am=${numAmount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(transactionNote)}`;

      const order = {
        orderId,
        userId,
        type,
        amount: numAmount,
        credits: type === 'credits' ? Number(credits || 0) : 0,
        funds: type === 'funds' ? numAmount : 0,
        targetVpa: UPI_TARGET_VPA,
        payeeName: UPI_PAYEE_NAME,
        upiUri,
        createdAt: Date.now(),
        expiresAt,
        status: 'PENDING',
        transactionNote
      };

      const store = loadWalletStore();
      store.orders[orderId] = order;
      saveWalletStore(store);

      res.json({
        ok: true,
        orderId,
        targetVpa: UPI_TARGET_VPA,
        payeeName: UPI_PAYEE_NAME,
        amount: numAmount,
        credits: order.credits,
        funds: order.funds,
        upiUri,
        createdAt: order.createdAt,
        expiresAt: order.expiresAt,
        expiresInSeconds: Math.floor(ORDER_EXPIRY_MS / 1000)
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to create UPI order', details: err.message });
    }
  });

  // Check duplicate UTR
  router.get('/check-utr', (req, res) => {
    const rawUtr = String(req.query.utr || '').trim().replace(/[^a-zA-Z0-9]/g, '');
    if (!rawUtr) return res.json({ exists: false });
    const store = loadWalletStore();
    const exists = Object.values(store.orders || {}).some(
      o => o.utr && o.utr.toUpperCase() === rawUtr.toUpperCase()
    );
    res.json({ exists });
  });

  // Get user order history with live status
  router.get('/user-orders', (req, res) => {
    const userId = req.query.userId;
    if (!userId) return res.json({ ok: true, orders: [] });
    const store = loadWalletStore();
    const userOrders = Object.values(store.orders || {})
      .filter(o => o.userId === userId || o.uid === userId)
      .map(o => ({
        id: o.orderId || o.id,
        uid: o.userId || o.uid,
        userEmail: o.userEmail || '',
        userName: o.userName || '',
        userPhone: o.userPhone || '',
        amount: Number(o.amount) || 0,
        utr: o.utr || '',
        type: o.type || 'funds',
        credits: Number(o.credits) || 0,
        status: (o.status || 'pending').toLowerCase(),
        createdAt: o.createdAt ? (typeof o.createdAt === 'number' ? new Date(o.createdAt).toISOString() : o.createdAt) : new Date().toISOString(),
        reviewedAt: o.verifiedAt ? new Date(o.verifiedAt).toISOString() : (o.reviewedAt || null),
        reviewedBy: o.verifiedBy || o.reviewedBy || null,
        adminNote: o.rejectionReason || o.adminNote || ''
      }))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({ ok: true, orders: userOrders });
  });

  // 2b. User Submits UTR for Admin Approval
  router.post('/submit-utr', (req, res) => {
    try {
      const {
        orderId,
        utr,
        userId = 'trader',
        userEmail = '',
        userName = '',
        userPhone = '',
        amount = 100,
        type = 'funds',
        credits = 0
      } = req.body;

      const cleanUtr = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
      if (cleanUtr.length < 6) {
        return res.status(400).json({ error: 'Please enter a valid 12-digit UPI UTR or Transaction Reference number.' });
      }

      const store = loadWalletStore();

      // Duplicate UTR check: reject if another order already has this UTR
      const duplicateExists = Object.values(store.orders || {}).some(
        o => o.utr && o.utr.toUpperCase() === cleanUtr.toUpperCase() && o.orderId !== orderId
      );
      if (duplicateExists) {
        return res.status(400).json({
          error: 'This UTR / Transaction ID has already been submitted. Duplicate submissions are not allowed.'
        });
      }
      const numAmount = Number(amount) || 100;
      const targetOrderId = orderId || `DHRU-UPI-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

      let order = store.orders[targetOrderId];
      if (!order) {
        order = {
          orderId: targetOrderId,
          userId,
          userEmail,
          userName,
          userPhone,
          type,
          amount: numAmount,
          credits: type === 'credits' ? Number(credits || 0) : 0,
          funds: type === 'funds' ? numAmount : 0,
          targetVpa: UPI_TARGET_VPA,
          payeeName: UPI_PAYEE_NAME,
          createdAt: Date.now(),
          expiresAt: Date.now() + ORDER_EXPIRY_MS,
          status: 'PENDING',
          utr: cleanUtr,
          submittedAt: Date.now()
        };
      } else {
        order.utr = cleanUtr;
        order.userId = userId || order.userId;
        order.userEmail = userEmail || order.userEmail;
        order.userName = userName || order.userName;
        order.userPhone = userPhone || order.userPhone;
        order.status = 'PENDING';
        order.submittedAt = Date.now();
      }

      store.orders[targetOrderId] = order;

      // Ensure user profile is registered and updated with details
      if (!store.users[userId]) {
        store.users[userId] = {
          uid: userId,
          displayName: userName || userEmail?.split('@')[0] || userId,
          email: userEmail,
          phone: userPhone,
          credits: 0,
          realCredits: 0,
          demoCredits: 100,
          tradingBalance: 0,
          totalCreditsPurchased: 0,
          premiumUnlocked: false,
          joinedAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
          history: []
        };
      } else {
        if (userName) store.users[userId].displayName = userName;
        if (userEmail) store.users[userId].email = userEmail;
        if (userPhone) store.users[userId].phone = userPhone;
        if (store.users[userId].demoCredits === undefined) store.users[userId].demoCredits = 100;
        store.users[userId].lastActive = new Date().toISOString();
      }

      saveWalletStore(store);

      // Dual-Sync to SQLite payments table
      try {
        const dupInSqlite = db.queryOne('SELECT id FROM payments WHERE utr = ?', cleanUtr);
        if (!dupInSqlite) {
          const nowIso = new Date().toISOString();
          const clientIp = req.ip || req.socket.remoteAddress || '';
          let userRow = db.queryOne('SELECT * FROM users WHERE uid = ?', userId);
          if (!userRow) {
            db.execute(`
              INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt, lastIp)
              VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?, ?)
            `, userId, userName || (userEmail ? userEmail.split('@')[0] : 'Trader'), userEmail || null, userPhone || null, userPhone ? 1 : 0, nowIso, nowIso, clientIp);
            db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', userId);
          }
          const finalCreds = order.type === 'credits' ? (Number(order.credits) || (numAmount === 99 ? 200 : numAmount === 199 ? 500 : numAmount === 499 ? 1200 : numAmount === 899 ? 2000 : numAmount)) : 0;
          db.execute(`
            INSERT INTO payments (id, uid, amount, method, utr, type, credits, status, createdAt)
            VALUES (?, ?, ?, 'UPI', ?, ?, ?, 'pending', ?)
          `, targetOrderId, userId, numAmount, cleanUtr, order.type || 'funds', finalCreds, nowIso);
          db.execute(`
            INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, after, createdAt)
            VALUES (?, 'user', ?, 'PAYMENT_SUBMITTED', 'payments', ?, ?, ?)
          `, `audit-${Date.now()}`, userId, targetOrderId, JSON.stringify({ amount: numAmount, utr: cleanUtr }), nowIso);

          broadcastToAdmin('new_payment', {
            id: targetOrderId,
            uid: userId,
            amount: numAmount,
            method: 'UPI',
            utr: cleanUtr,
            status: 'pending',
            createdAt: nowIso,
            userName,
            userEmail,
            userPhone
          });
        }
      } catch (err) {
        console.warn('[WalletStore] Dual-sync SQLite payment warning:', err.message);
      }

      res.json({
        ok: true,
        message: `UTR ${cleanUtr} submitted successfully! Awaiting Admin verification.`,
        order
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to submit UTR', details: err.message });
    }
  });

  // 3. Verify UPI Payment & Add Credits / Funds
  router.post('/verify-upi', (req, res) => {
    try {
      const { orderId, utr, userId = 'default-user' } = req.body;
      if (!orderId) {
        return res.status(400).json({ error: 'Order ID is required' });
      }

      const store = loadWalletStore();
      const order = store.orders[orderId];
      if (!order) {
        return res.status(404).json({ error: 'Payment order not found' });
      }

      // 10-Minute Expiry Check
      if (Date.now() > order.expiresAt && order.status === 'PENDING') {
        order.status = 'EXPIRED';
        saveWalletStore(store);
        return res.status(400).json({ error: 'This payment order has expired (10 minutes limit). Please generate a new UPI payment.' });
      }

      if (order.status === 'VERIFIED') {
        return res.json({ ok: true, message: 'Payment already verified', order });
      }

      // UTR Validation (minimum 6-16 chars / UPI reference)
      const cleanUtr = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
      if (cleanUtr.length < 6) {
        return res.status(400).json({ error: 'Please enter a valid 12-digit UPI UTR or Transaction Reference number.' });
      }

      // Mark order verified
      order.status = 'VERIFIED';
      order.utr = cleanUtr;
      order.verifiedAt = Date.now();

      // Update user wallet
      const user = store.users[userId] || {
        credits: 100,
        tradingBalance: 0,
        totalCreditsPurchased: 0,
        premiumUnlocked: false,
        history: []
      };

      if (order.type === 'credits') {
        user.credits += order.credits;
        user.totalCreditsPurchased = (user.totalCreditsPurchased || 0) + order.credits;
        user.history.unshift({
          id: `tx-${Date.now()}`,
          type: 'CREDIT_PURCHASE',
          amount: order.amount,
          credits: order.credits,
          utr: cleanUtr,
          at: new Date().toISOString()
        });
      } else {
        user.tradingBalance += order.funds;
        user.history.unshift({
          id: `tx-${Date.now()}`,
          type: 'FUND_DEPOSIT',
          amount: order.amount,
          utr: cleanUtr,
          at: new Date().toISOString()
        });
      }

      // Auto-unlock premium indicators if user purchased/holds >= 1000 credits
      if (user.totalCreditsPurchased >= 1000 || user.credits >= 1000) {
        user.premiumUnlocked = true;
      }

      store.users[userId] = user;
      saveWalletStore(store);

      res.json({
        ok: true,
        message: order.type === 'credits'
          ? `₹${order.amount} verified! ${order.credits} Credits added successfully.`
          : `₹${order.amount} verified! Real trading funds deposited successfully.`,
        wallet: user,
        order
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to verify payment', details: err.message });
    }
  });

  // 4. Consume Credits for Intelligence Report or Auto-Trade
  router.post('/consume', (req, res) => {
    try {
      const { type = 'report', cost = 5, userId = 'default-user', symbol = '' } = req.body;
      const numCost = Number(cost) || 5;

      const store = loadWalletStore();
      const user = store.users[userId] || {
        credits: 100, // 100 free starting credits
        tradingBalance: 0,
        totalCreditsPurchased: 0,
        premiumUnlocked: false,
        history: []
      };

      if (user.credits < numCost) {
        return res.status(402).json({
          ok: false,
          error: 'Insufficient DHRU credits',
          required: numCost,
          available: user.credits,
          needBuy: numCost - user.credits
        });
      }

      user.credits -= numCost;
      user.history.unshift({
        id: `tx-${Date.now()}`,
        type: type === 'autotrade' ? 'AUTOTRADE_CONSUME' : 'REPORT_CONSUME',
        credits: -numCost,
        symbol,
        at: new Date().toISOString()
      });

      store.users[userId] = user;
      saveWalletStore(store);

      res.json({
        ok: true,
        remainingCredits: user.credits,
        consumed: numCost,
        wallet: user
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to consume credits', details: err.message });
    }
  });

  // 4b. Withdraw Real Funds via Indian Bank Account or UPI
  router.post('/withdraw', (req, res) => {
    try {
      const {
        userId = 'default-user',
        amount = 0,
        method = 'UPI', // 'BANK' or 'UPI'
        bankDetails = null,
        upiDetails = null
      } = req.body;

      const numAmount = Number(amount);
      if (!Number.isFinite(numAmount) || numAmount < 100) {
        return res.status(400).json({ ok: false, error: 'Minimum withdrawal amount is ₹100' });
      }

      const store = loadWalletStore();
      if (!store.withdrawals) store.withdrawals = {};
      const user = store.users[userId] || {
        credits: 100,
        tradingBalance: 0,
        totalCreditsPurchased: 0,
        premiumUnlocked: false,
        history: []
      };

      if (user.tradingBalance < numAmount) {
        return res.status(400).json({
          ok: false,
          error: `Insufficient trading funds. Available: ₹${user.tradingBalance.toFixed(2)}, Requested: ₹${numAmount.toFixed(2)}`
        });
      }

      // Deduct balance
      user.tradingBalance = Number((user.tradingBalance - numAmount).toFixed(2));
      const withdrawalId = `WDR-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

      const withdrawal = {
        id: withdrawalId,
        userId,
        amount: numAmount,
        method,
        bankDetails: method === 'BANK' ? bankDetails : null,
        upiDetails: method === 'UPI' ? upiDetails : null,
        status: 'PENDING',
        createdAt: Date.now()
      };

      store.withdrawals[withdrawalId] = withdrawal;
      user.history.unshift({
        id: `tx-${Date.now()}`,
        type: 'WITHDRAWAL_REQUEST',
        amount: -numAmount,
        note: `Withdrawal to ${method === 'UPI' ? (upiDetails?.upiId || 'UPI') : (bankDetails?.bankName || 'Bank')}`,
        at: new Date().toISOString()
      });

      store.users[userId] = user;
      saveWalletStore(store);

      res.json({
        ok: true,
        message: 'Withdrawal request submitted successfully',
        withdrawal,
        wallet: user
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to process withdrawal', details: err.message });
    }
  });

  // 4c. Get user withdrawals
  router.get('/withdrawals', (req, res) => {
    try {
      const userId = req.query.userId || 'default-user';
      const store = loadWalletStore();
      const all = Object.values(store.withdrawals || {});
      const userWithdrawals = all.filter(w => w.userId === userId).sort((a, b) => b.createdAt - a.createdAt);
      res.json({ ok: true, withdrawals: userWithdrawals });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch withdrawals', details: err.message });
    }
  });

  // 5. Convenient Demo / Localhost Login Bypass
  router.post('/demo-login', (req, res) => {
    const userId = 'local-demo-trader';
    const store = loadWalletStore();
    if (!store.users[userId]) {
      store.users[userId] = {
        credits: 100, // 100 free starting credits
        tradingBalance: 10000,
        totalCreditsPurchased: 0,
        premiumUnlocked: false,
        history: [
          {
            id: `tx-${Date.now()}`,
            type: 'WELCOME_BONUS',
            credits: 100,
            note: '100 Free Welcome Credits Granted',
            at: new Date().toISOString()
          }
        ]
      };
      saveWalletStore(store);
    }

    res.json({
      ok: true,
      user: {
        uid: userId,
        email: 'preetham@dhru.ai',
        displayName: 'Preetham (Localhost Trader)',
        isLocalBypass: true,
        photoURL: null
      },
      wallet: store.users[userId]
    });
  });

  // Admin routes require a valid admin JWT (the old header-only check let anyone call them)
  const verifySuperAdmin = requireAdminAuth;

  // 6. Admin Panel: Platform Analytics Overview
  router.get('/admin/overview', verifySuperAdmin, (req, res) => {
    try {
      const store = loadWalletStore();
      const users = Object.entries(store.users || {});
      const orders = Object.values(store.orders || {});

      const totalUsers = users.length;
      const totalTradingFunds = users.reduce((acc, [, u]) => acc + (Number(u.tradingBalance) || 0), 0);
      const totalCreditsOutstanding = users.reduce((acc, [, u]) => acc + (Number(u.credits) || 0), 0);
      
      const verifiedOrders = orders.filter(o => o.status === 'VERIFIED');
      const pendingOrders = orders.filter(o => o.status === 'PENDING');
      const rejectedOrders = orders.filter(o => o.status === 'REJECTED');
      const totalRevenueInr = verifiedOrders.reduce((acc, o) => acc + (Number(o.amount) || 0), 0);
      const pendingRevenueInr = pendingOrders.reduce((acc, o) => acc + (Number(o.amount) || 0), 0);

      res.json({
        ok: true,
        analytics: {
          totalUsers,
          totalTradingFunds,
          totalCreditsOutstanding,
          totalRevenueInr,
          pendingRevenueInr,
          totalOrdersCount: orders.length,
          verifiedOrdersCount: verifiedOrders.length,
          pendingOrdersCount: pendingOrders.length,
          rejectedOrdersCount: rejectedOrders.length,
          targetVpa: UPI_TARGET_VPA,
          payeeName: UPI_PAYEE_NAME,
          systemStatus: 'OPERATIONAL'
        }
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch admin overview', details: err.message });
    }
  });

  // 7. Admin Panel: List All Payment Orders
  router.get('/admin/orders', verifySuperAdmin, (req, res) => {
    try {
      const store = loadWalletStore();
      const orders = Object.values(store.orders || {}).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      res.json({ ok: true, orders });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch admin orders', details: err.message });
    }
  });

  // 8. Admin Panel: Manual Approval of UPI Payment Order
  router.post('/admin/approve-order', verifySuperAdmin, (req, res) => {
    try {
      const { orderId, adminNote, customAmount, customCredits } = req.body || {};
      if (!orderId) return res.status(400).json({ error: 'Order ID is required' });
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';
      const result = approvePayment({ id: orderId, adminEmail, adminNote, customAmount, customCredits });
      const { status, ...body } = result;
      res.status(status).json(body);
    } catch (err) {
      res.status(500).json({ error: 'Failed to approve order', details: err.message });
    }
  });

  router.post('/admin/reject-order', verifySuperAdmin, (req, res) => {
    try {
      const { orderId, reason = 'UTR Verification Failed / Invalid Reference' } = req.body || {};
      if (!orderId) return res.status(400).json({ error: 'Order ID is required' });
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';
      const result = rejectPayment({ id: orderId, adminEmail, reason });
      const { status, ...body } = result;
      res.status(status).json(body);
    } catch (err) {
      res.status(500).json({ error: 'Failed to reject order', details: err.message });
    }
  });

  // 10. Admin Panel: Direct Balance Adjustment
  router.post('/admin/adjust-balance', verifySuperAdmin, (req, res) => {
    try {
      const { userId = 'default-user', credits = 0, funds = 0, note = 'Admin adjustment' } = req.body;
      const store = loadWalletStore();
      const user = store.users[userId] || {
        credits: 100,
        tradingBalance: 0,
        totalCreditsPurchased: 0,
        premiumUnlocked: false,
        history: []
      };

      if (credits) {
        user.credits = Math.max(0, user.credits + Number(credits));
        if (credits > 0) user.totalCreditsPurchased = (user.totalCreditsPurchased || 0) + Number(credits);
      }
      if (funds) {
        user.tradingBalance = Math.max(0, user.tradingBalance + Number(funds));
      }
      if (user.credits >= 1000 || user.totalCreditsPurchased >= 1000) {
        user.premiumUnlocked = true;
      }

      user.history.unshift({
        id: `tx-${Date.now()}`,
        type: 'ADMIN_ADJUSTMENT',
        credits: Number(credits) || undefined,
        amount: Number(funds) || undefined,
        note,
        at: new Date().toISOString()
      });

      store.users[userId] = user;
      saveWalletStore(store);

      res.json({ ok: true, message: 'Balance adjusted successfully', user });
    } catch (err) {
      res.status(500).json({ error: 'Failed to adjust balance', details: err.message });
    }
  });

  // 11. Admin Panel: List Withdrawals
  router.get('/admin/withdrawals', verifySuperAdmin, (req, res) => {
    try {
      const store = loadWalletStore();
      const withdrawals = Object.values(store.withdrawals || {}).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      res.json({ ok: true, withdrawals });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch admin withdrawals', details: err.message });
    }
  });

  // 12. Admin Panel: Approve Withdrawal
  router.post('/admin/approve-withdrawal', verifySuperAdmin, (req, res) => {
    try {
      const { withdrawalId, adminNote = 'Processed via banking gateway' } = req.body;
      if (!withdrawalId) return res.status(400).json({ error: 'Withdrawal ID required' });
      const store = loadWalletStore();
      const w = store.withdrawals?.[withdrawalId];
      if (!w) return res.status(404).json({ error: 'Withdrawal request not found' });
      w.status = 'VERIFIED';
      w.adminNote = adminNote;
      w.verifiedAt = Date.now();
      saveWalletStore(store);
      res.json({ ok: true, message: `Withdrawal ${withdrawalId} approved and transferred.`, withdrawal: w });
    } catch (err) {
      res.status(500).json({ error: 'Failed to approve withdrawal', details: err.message });
    }
  });

  // 13. Admin Panel: Reject Withdrawal & Refund Balance
  router.post('/admin/reject-withdrawal', verifySuperAdmin, (req, res) => {
    try {
      const { withdrawalId, reason = 'Bank details mismatch' } = req.body;
      if (!withdrawalId) return res.status(400).json({ error: 'Withdrawal ID required' });
      const store = loadWalletStore();
      const w = store.withdrawals?.[withdrawalId];
      if (!w) return res.status(404).json({ error: 'Withdrawal request not found' });
      if (w.status !== 'REJECTED') {
        w.status = 'REJECTED';
        w.rejectionReason = reason;
        w.rejectedAt = Date.now();
        // Refund funds back to user
        const user = store.users[w.userId];
        if (user) {
          user.tradingBalance = Number((user.tradingBalance + w.amount).toFixed(2));
          user.history.unshift({
            id: `tx-${Date.now()}`,
            type: 'WITHDRAWAL_REFUND',
            amount: w.amount,
            note: `Refund for rejected withdrawal: ${reason}`,
            at: new Date().toISOString()
          });
        }
        saveWalletStore(store);
      }
      res.json({ ok: true, message: `Withdrawal ${withdrawalId} rejected and refunded.`, withdrawal: w });
    } catch (err) {
      res.status(500).json({ error: 'Failed to reject withdrawal', details: err.message });
    }
  });

  // 14. Admin Panel: List All Users & Balances
  router.get('/admin/users', verifySuperAdmin, (req, res) => {
    try {
      const store = loadWalletStore();
      const usersList = Object.entries(store.users || {}).map(([userId, data]) => ({
        userId,
        uid: userId,
        displayName: data.displayName || (data.email ? data.email.split('@')[0] : userId),
        email: data.email || (userId.includes('@') ? userId : ''),
        phone: data.phone || '',
        credits: data.credits || 0,
        tradingBalance: data.tradingBalance || 0,
        totalCreditsPurchased: data.totalCreditsPurchased || 0,
        premiumUnlocked: !!data.premiumUnlocked,
        isBanned: !!data.isBanned,
        canTrade: data.canTrade !== false,
        role: SUPER_ADMIN_EMAILS.includes((data.email || '').toLowerCase()) ? 'SUPER_ADMIN' : 'TRADER',
        txCount: Array.isArray(data.history) ? data.history.length : 0,
        history: data.history || [],
        joinedAt: data.joinedAt || null,
        updatedAt: data.lastActive || data.history?.[0]?.at || null
      }));
      res.json({ ok: true, users: usersList });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch users', details: err.message });
    }
  });

  // 14b. Admin Panel: Get Specific User Details & Full Transactions
  router.get('/admin/user/:userId', verifySuperAdmin, (req, res) => {
    try {
      const { userId } = req.params;
      const store = loadWalletStore();
      const user = store.users[userId];
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      const userOrders = Object.values(store.orders || {}).filter(o => o.userId === userId);
      res.json({
        ok: true,
        user: {
          uid: userId,
          displayName: user.displayName || (user.email ? user.email.split('@')[0] : userId),
          email: user.email || '',
          phone: user.phone || '',
          credits: user.credits || 0,
          tradingBalance: user.tradingBalance || 0,
          totalCreditsPurchased: user.totalCreditsPurchased || 0,
          premiumUnlocked: !!user.premiumUnlocked,
          isBanned: !!user.isBanned,
          canTrade: user.canTrade !== false,
          joinedAt: user.joinedAt || null,
          lastActive: user.lastActive || null,
          history: user.history || []
        },
        orders: userOrders
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch user details', details: err.message });
    }
  });

  // 15. Admin Panel: Update User Account Permissions (Ban / Trading Permission)
  router.post('/admin/update-permissions', verifySuperAdmin, (req, res) => {
    try {
      const { userId, isBanned, canTrade } = req.body;
      if (!userId) return res.status(400).json({ error: 'User ID is required' });
      const store = loadWalletStore();
      if (!store.users[userId]) {
        store.users[userId] = {
          credits: 100,
          tradingBalance: 0,
          totalCreditsPurchased: 0,
          premiumUnlocked: false,
          history: []
        };
      }
      if (typeof isBanned === 'boolean') store.users[userId].isBanned = isBanned;
      if (typeof canTrade === 'boolean') store.users[userId].canTrade = canTrade;
      saveWalletStore(store);
      res.json({ ok: true, message: `User ${userId} permissions updated successfully.`, user: store.users[userId] });
    } catch (err) {
      res.status(500).json({ error: 'Failed to update permissions', details: err.message });
    }
  });

  const BROADCAST_FILE = path.join(__dirname, '..', 'data', 'system-broadcast.json');
  const loadBroadcast = () => {
    try {
      if (fs.existsSync(BROADCAST_FILE)) {
        return JSON.parse(fs.readFileSync(BROADCAST_FILE, 'utf-8'));
      }
    } catch {}
    return { active: false, title: '', message: '', type: 'INFO', updatedAt: null };
  };
  const saveBroadcast = (bc) => {
    try {
      fs.writeFileSync(BROADCAST_FILE, JSON.stringify(bc, null, 2));
    } catch (err) {
      console.error('[Broadcast Save Error]', err);
    }
  };

  // 16. Public: Fetch Active System Broadcast
  router.get('/broadcast/active', (req, res) => {
    try {
      const bc = loadBroadcast();
      res.json({ ok: true, broadcast: bc });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch broadcast' });
    }
  });

  // 17. Admin Panel: Publish System Broadcast
  router.post('/admin/broadcast', verifySuperAdmin, (req, res) => {
    try {
      const { title, message, type = 'INFO', active = true } = req.body;
      if (!title || !message) {
        return res.status(400).json({ error: 'Title and message are required for broadcasting.' });
      }
      const bc = {
        id: `bc-${Date.now()}`,
        active: Boolean(active),
        title: title.trim(),
        message: message.trim(),
        type: type.toUpperCase(),
        updatedAt: new Date().toISOString(),
        createdBy: 'Super Admin'
      };
      saveBroadcast(bc);
      res.json({ ok: true, message: 'Broadcast published system-wide successfully.', broadcast: bc });
    } catch (err) {
      res.status(500).json({ error: 'Failed to publish broadcast', details: err.message });
    }
  });

  // 18. Admin Panel: Clear / Deactivate Broadcast
  router.post('/admin/broadcast/clear', verifySuperAdmin, (req, res) => {
    try {
      const bc = { active: false, title: '', message: '', type: 'INFO', updatedAt: new Date().toISOString() };
      saveBroadcast(bc);
      res.json({ ok: true, message: 'Broadcast cleared successfully.' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to clear broadcast' });
    }
  });

  // 19. User Redeem Promo Code (Direct fallback endpoint)
  router.post('/redeem-code', (req, res) => {
    try {
      const { uid, userId, code: inputCode } = req.body;
      const targetUid = uid || userId;
      if (!targetUid) return res.status(400).json({ error: 'UID is required' });
      const cleanCode = String(inputCode || '').trim().toUpperCase();
      if (!cleanCode) return res.status(400).json({ error: 'Please enter a redeem code.' });

      // Check code in promo_codes table
      const promo = db.queryOne('SELECT * FROM promo_codes WHERE UPPER(code) = ?', cleanCode);
      if (!promo) return res.status(404).json({ error: 'Invalid redeem code. Please verify and try again.' });
      if (!promo.active) return res.status(400).json({ error: 'This promo code has been deactivated.' });
      if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) {
        return res.status(400).json({ error: 'This promo code has expired.' });
      }
      if (promo.maxUses > 0 && promo.usedCount >= promo.maxUses) {
        return res.status(400).json({ error: 'This promo code has reached its maximum global usage limit.' });
      }

      // Check per-user limit
      const userRedemptions = db.queryAll('SELECT id FROM promo_redemptions WHERE codeId = ? AND uid = ?', promo.id, targetUid);
      if (userRedemptions.length >= promo.perUserLimit) {
        return res.status(400).json({ error: 'You have already redeemed this promo code.' });
      }

      const creditsToGive = Number(promo.credits);
      if (creditsToGive <= 0) return res.status(400).json({ error: 'Invalid credit value on this code.' });

      const nowIso = new Date().toISOString();
      const clientIp = req.ip || req.socket.remoteAddress || '';

      // Ensure user and wallet exist in SQLite
      let user = db.queryOne('SELECT * FROM users WHERE uid = ?', targetUid);
      if (!user) {
        db.execute(`
          INSERT OR REPLACE INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt, lastIp)
          VALUES (?, ?, NULL, NULL, 0, 'unverified', 'active', ?, ?, ?)
        `, targetUid, targetUid, nowIso, nowIso, clientIp);
        db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', targetUid);
      }

      let wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', targetUid) || { demoCredits: 100, realCredits: 0 };
      const newRealBalance = Number(((wallet.realCredits || 0) + creditsToGive).toFixed(2));

      db.runTransaction(() => {
        db.execute('UPDATE wallets SET realCredits = ? WHERE uid = ?', newRealBalance, targetUid);
        db.execute(`
          INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
          VALUES (?, 'real', 'promo', ?, ?, ?, ?, ?)
        `, targetUid, creditsToGive, newRealBalance, promo.code, `Redeemed promo code: ${promo.code}`, nowIso);
        db.execute('INSERT INTO promo_redemptions (codeId, uid, creditsGiven, createdAt) VALUES (?, ?, ?, ?)', promo.id, targetUid, creditsToGive, nowIso);
        db.execute('UPDATE promo_codes SET usedCount = usedCount + 1 WHERE id = ?', promo.id);
        db.execute(`
          INSERT INTO notifications (id, uid, title, body, createdAt)
          VALUES (?, ?, 'Promo Code Redeemed!', ?, ?)
        `, `notif-${Date.now()}`, targetUid, `Code ${promo.code} gave you ${creditsToGive} AI Credits.`, nowIso);
      });

      // Update wallet-store.json
      const store = loadWalletStore();
      if (!store.users) store.users = {};
      if (!store.users[targetUid]) {
        store.users[targetUid] = {
          uid: targetUid,
          credits: 0,
          realCredits: 0,
          demoCredits: 100,
          tradingBalance: 0,
          totalCreditsPurchased: 0,
          premiumUnlocked: false,
          history: []
        };
      }
      store.users[targetUid].credits = (Number(store.users[targetUid].credits) || 0) + creditsToGive;
      store.users[targetUid].realCredits = (Number(store.users[targetUid].realCredits) || 0) + creditsToGive;
      store.users[targetUid].totalCreditsPurchased = (Number(store.users[targetUid].totalCreditsPurchased) || 0) + creditsToGive;
      if (store.users[targetUid].credits >= 1000) store.users[targetUid].premiumUnlocked = true;
      if (!Array.isArray(store.users[targetUid].history)) store.users[targetUid].history = [];
      store.users[targetUid].history.unshift({
        id: `tx-promo-${Date.now()}`,
        type: 'PROMO_REDEEM',
        credits: creditsToGive,
        note: `Claimed promo code ${promo.code} (+${creditsToGive} AI Credits)`,
        at: nowIso
      });
      saveWalletStore(store);

      const liveWallet = {
        demoCredits: wallet.demoCredits ?? 100,
        realCredits: newRealBalance,
        credits: store.users[targetUid].credits,
        tradingBalance: store.users[targetUid].tradingBalance || 0
      };

      sendToUser(targetUid, 'wallet_update', liveWallet);
      sendToUser(targetUid, 'promo_claimed', { code: promo.code, creditsGiven: creditsToGive });

      return res.json({
        ok: true,
        success: true,
        message: `Successfully claimed code ${promo.code}! ${creditsToGive} AI Credits added to your account.`,
        creditsGiven: creditsToGive,
        credits: store.users[targetUid].credits,
        wallet: liveWallet
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to redeem promo code', details: err.message });
    }
  });

  return router;
}
