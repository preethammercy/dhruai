# DHRU.AI - Dhruti Super Admin Operations & Security Guide

## 1. Access & Credentials

- **Admin Panel URL**: `/dhruti` (Note: the old `/admin` route is permanently deactivated and returns HTTP 404).
- **Default Super Admin Email**: `dhruti@preetham.com`
- **Default Master Password**: `Dhruti@0416`
- **Security Architecture**:
  - Passwords are verified on the backend using constant-time cryptographic comparisons (`node:crypto.timingSafeEqual`).
  - Rate-limited: 5 failed login attempts result in an automatic 15-minute IP lockout.
  - Generates RFC 7519 HMAC-SHA256 JWT tokens with 24-hour expiration.
  - Zero sensitive credentials or secrets committed in frontend client code.

### Custom Password Generation
To generate your own custom PBKDF2 cryptographic hash:
```bash
node scripts/generate-admin-hash.js "YourStrongPasswordHere"
```
Copy the resulting `ADMIN_PASSWORD_HASH=pbkdf2$100000$...` line into your `.env` file and restart the server.

---

## 2. Admin Modules Overview

The Dhruti Control Center at `/dhruti` consists exclusively of the following streamlined operator desks:

### 2.1 Live Analytics Desk
- **Online Traders**: Real-time counter of active Server-Sent Events (SSE) connections.
- **Platform Capital**: Real credits outstanding vs demo credits simulated.
- **Deposit Flow**: Approved revenue (₹) vs pending deposits awaiting review.
- **Signups & Activity**: Daily registered users and volume over the last 7 and 30 days.
- **CSV Export**: One-click download of all platform audit metrics.

### 2.2 Payment Approvals Desk (UTR Verification)
- **Live Stream**: Pushes pending payment alerts to the admin console instantly with audio notification.
- **Single Source of Truth**: Connected directly to the centralized SQLite database (`server/data/dhru.db`).
- **UTR Uniqueness Enforcement**: Prevents duplicate transaction reference numbers across the platform.
- **Atomic Approval**:
  - Verifies payment against bank statement.
  - One-click "Approve" adds REAL credits to the user's wallet atomically in a single ACID database transaction.
  - Writes an immutable record to `wallet_ledger` and `audit_logs`.
  - Dispatches an instant real-time SSE notification and wallet balance update to the user.
- **Rejection with Reason**: Requires a mandatory explanation that is immediately displayed in the user's notification inbox.

### 2.3 User Management & 360° Dossier
- Searchable by Public UID (`DHRU-XXXXXX`), Email, Name, or Mobile Number.
- **User Dossier View**:
  - Identity status and KYC verification queue.
  - Demo and Real wallet balances.
  - Full audit ledger showing all deposits, withdrawals, trade PnLs, and admin adjustments.
  - Complete trade history with entry, exit, stop loss, and realized PnL.
- **User Actions**:
  - **Suspend / Ban**: Blocks abusive accounts with logged administrative reasons.
  - **Adjust Balance**: Manually credit or debit Demo or Real funds with mandatory ledger reasons.
  - **KYC Review**: Approve or reject submitted identity documents.

### 2.4 Support & Live Chat Center
- Real-time two-way communication with active users.
- Live ticket resolution, status toggling (Open, Pending, Resolved), and real-time push to user.

### 2.5 Broadcasts & Announcement Desk
- Dispatch site-wide modals, banners, or promotional posters.
- Target segments: `all`, `real`, or `demo` traders.
- Automatic expiration and view tracking.

### 2.6 Promo Codes Engine
- Generate single or bulk cryptographically random promo codes (e.g., `DHRU-SAVE50-XXXX`).
- Set custom credits, expiration dates, global usage limits, and per-user redemption limits.
- **Strict Financial Guardrail**: Promo codes credit **REAL** accounts only; demo balances are completely isolated.

### 2.7 System Settings
- Update UPI Target VPA (e.g., `preethamrishu@axl`) and Merchant Payee Name.
- Set minimum and maximum deposit limits.
- Toggle maintenance mode.

---

## 3. Security & Operational Checklist
1. Never share the `ADMIN_JWT_SECRET` key or leave `.env` exposed in public repositories.
2. Backups of `server/data/dhru.db` are automatically taken daily in `server/data/backups/`.
3. If hosting on containerized platforms (Railway, Render, Fly.io), ensure a persistent volume is mounted to `server/data`.
