# DHRU.AI - Production Deployment Guide

## 1. Hosting Architecture
DHRU.AI uses an Express backend (`server/index.js`) and a Vite + React frontend (`dist/`), backed by a high-performance **SQLite database with WAL mode** at `server/data/dhru.db`.

> **Hosting Requirement**: Because SQLite stores data in a local file, the hosting provider **must provide a persistent disk/volume**. Serverless platforms (such as standard Vercel functions) have ephemeral filesystems and will lose data on cold starts.
> 
> **Recommended Platforms**:
> - **Railway** (Attach a persistent Volume to `/app/server/data`)
> - **Render** (Add a Persistent Disk to `/var/data` and set `DB_PATH=/var/data/dhru.db`)
> - **Fly.io** (Mount a volume to `/data` and set `DB_PATH=/data/dhru.db`)
> - **Linux VPS** (Ubuntu 22.04 / 24.04 with PM2 or Docker)

---

## 2. Environment Variables

Create a `.env` file in the root directory:

```env
PORT=5000
NODE_ENV=production

# SQLite Database Location
DB_PATH=./server/data/dhru.db

# Super Admin Authentication (Generate hash with: npm run admin:hash)
ADMIN_EMAIL=dhruti@preetham.com
ADMIN_PASSWORD_HASH=pbkdf2$100000$salt$hash...
ADMIN_JWT_SECRET=super_secret_cryptographic_jwt_key_here

# Upstox (Optional for live broker quotes)
UPSTOX_ACCESS_TOKEN=your_upstox_token_here

# Google Gemini API Key
GEMINI_API_KEY=your_gemini_api_key_here
```

---

## 3. Build & Run Commands

```bash
# 1. Install dependencies
npm install

# 2. Build the client frontend
npm run build

# 3. Generate your secure admin password hash
node scripts/generate-admin-hash.js "YourPassword"

# 4. Start the production server
npm start
```

The server listens on `http://localhost:5000`, exposes the API at `/api/*`, the real-time streams at `/api/stream/*`, and serves the built single-page React app for all other routes.

---

## 4. Database Backups
- The server automatically takes daily backups of `dhru.db` to `server/data/backups/dhru_backup_YYYY-MM-DD.db`.
- The last 7 daily snapshots are preserved automatically.
- To restore from a backup:
  ```bash
  cp server/data/backups/dhru_backup_2026-11-07.db server/data/dhru.db
  ```
