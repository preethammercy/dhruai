// DHRU.AI - Admin Payments & User Management Router
// Strictly handles: Platform Analytics, Payment Approvals (UTR Desk), and User Management.
// Protected by requireAdminAuth middleware (JWT + role verification).

import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { requireAdminAuth } from './adminAuth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');
const AUDIT_FILE = path.join(DATA_DIR, 'audit-log.json');

function loadStore() {
  try {
    if (fs.existsSync(WALLET_FILE)) {
      return JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    }
  } catch (err) {
    console.warn('[AdminPayments] Failed to read store:', err.message);
  }
  return { users: {}, orders: {}, audits: [] };
}

function saveStore(store) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(WALLET_FILE, JSON.stringify(store, null, 2), 'utf8');
  } catch (err) {
    console.error('[AdminPayments] Failed to write store:', err.message);
  }
}

function appendAudit(audit) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    let logs = [];
    if (fs.existsSync(AUDIT_FILE)) {
      logs = JSON.parse(fs.readFileSync(AUDIT_FILE, 'utf8'));
    }
    logs.unshift(audit);
    fs.writeFileSync(AUDIT_FILE, JSON.stringify(logs.slice(0, 1000), null, 2), 'utf8');
  } catch (err) {
    console.warn('[AdminPayments] Failed to append audit log:', err.message);
  }
}

export function createAdminPaymentsRouter() {
  const router = express.Router();
  router.use(express.json());

  // 1. GET /api/admin/analytics - Real Platform Numbers
  router.get('/analytics', requireAdminAuth, (req, res) => {
    try {
      const store = loadStore();
      const users = Object.values(store.users || {});
      const orders = Object.values(store.orders || {});

      const totalUsers = users.length;
      const totalTradingFunds = users.reduce((sum, u) => sum + (Number(u.tradingBalance) || 0), 0);
      const totalCreditsOutstanding = users.reduce((sum, u) => sum + (Number(u.credits) || 0), 0);

      const verifiedOrders = orders.filter(o => o.status === 'VERIFIED' || o.status === 'approved');
      const pendingOrders = orders.filter(o => o.status === 'PENDING' || o.status === 'pending');
      const rejectedOrders = orders.filter(o => o.status === 'REJECTED' || o.status === 'rejected');

      const totalRevenueInr = verifiedOrders.reduce((sum, o) => sum + (Number(o.amount) || 0), 0);
      const pendingRevenueInr = pendingOrders.reduce((sum, o) => sum + (Number(o.amount) || 0), 0);

      res.json({
        ok: true,
        analytics: {
          totalUsers,
          totalTradingFunds,
          totalCreditsOutstanding,
          totalRevenueInr,
          pendingRevenueInr,
          totalOrdersCount: orders.length,
          verifiedOrdersCount: verifiedOrders.length,
          pendingOrdersCount: pendingOrders.length,
          rejectedOrdersCount: rejectedOrders.length,
          targetVpa: 'preethamrishu@axl',
          payeeName: 'DHRU AI Quantitative Markets',
          systemStatus: 'Operational'
        }
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to calculate analytics', details: err.message });
    }
  });

  // 2. GET /api/admin/payments - List All Payment Records
  router.get('/payments', requireAdminAuth, (req, res) => {
    try {
      const store = loadStore();
      const orders = Object.values(store.orders || {});
      // Map to standard schema
      const payments = orders.map(o => ({
        id: o.orderId || o.id,
        uid: o.userId || o.uid || 'anonymous',
        userEmail: o.userEmail || '',
        userName: o.userName || (o.userEmail ? o.userEmail.split('@')[0] : 'Trader'),
        userPhone: o.userPhone || '',
        amount: Number(o.amount) || 0,
        utr: o.utr || '',
        type: o.type || 'funds',
        credits: Number(o.credits) || 0,
        status: (o.status || 'pending').toLowerCase(),
        createdAt: o.createdAt ? (typeof o.createdAt === 'number' ? new Date(o.createdAt).toISOString() : o.createdAt) : new Date().toISOString(),
        reviewedAt: o.verifiedAt ? new Date(o.verifiedAt).toISOString() : (o.reviewedAt || null),
        reviewedBy: o.verifiedBy || o.reviewedBy || null,
        adminNote: o.rejectionReason || o.adminNote || ''
      }));

      payments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      res.json({ ok: true, payments });
    } catch (err) {
      res.status(500).json({ error: 'Failed to list payments', details: err.message });
    }
  });

  // 3. POST /api/admin/payments/:id/approve - Atomic Payment Approval & User Crediting
  router.post('/payments/:id/approve', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const { adminNote = 'Approved by administrator', customAmount, customCredits } = req.body;
      const adminEmail = req.adminUser?.sub || 'dhruti@preetham.com';

      const store = loadStore();
      const order = store.orders[id];
      if (!order) {
        return res.status(404).json({ error: `Payment order ${id} not found.` });
      }

      const amountToCredit = Number(customAmount ?? order.amount ?? 0);
      const creditsToCredit = Number(customCredits ?? order.credits ?? 0);

      // Atomic Status Update
      order.status = 'approved';
      order.verifiedAt = Date.now();
      order.verifiedBy = adminEmail;
      order.adminNote = adminNote;
      if (customAmount) order.amount = amountToCredit;
      if (customCredits) order.credits = creditsToCredit;

      // Credit User Account Atomically
      const targetUid = order.userId || order.uid;
      if (targetUid) {
        if (!store.users[targetUid]) {
          store.users[targetUid] = {
            uid: targetUid,
            displayName: order.userName || targetUid,
            email: order.userEmail || '',
            credits: 100,
            tradingBalance: 0,
            totalCreditsPurchased: 0,
            suspended: false,
            history: []
          };
        }

        const user = store.users[targetUid];
        if (order.type === 'credits') {
          user.credits = (user.credits || 0) + (creditsToCredit || amountToCredit);
          user.totalCreditsPurchased = (user.totalCreditsPurchased || 0) + (creditsToCredit || amountToCredit);
          user.history.unshift({
            id: `tx-credit-${Date.now()}`,
            type: 'CREDITS_DEPOSIT',
            amount: amountToCredit,
            credits: creditsToCredit || amountToCredit,
            utr: order.utr,
            orderId: id,
            at: new Date().toISOString(),
            status: 'VERIFIED'
          });
        } else {
          user.tradingBalance = (user.tradingBalance || 0) + amountToCredit;
          user.history.unshift({
            id: `tx-fund-${Date.now()}`,
            type: 'TRADING_FUND_DEPOSIT',
            amount: amountToCredit,
            utr: order.utr,
            orderId: id,
            at: new Date().toISOString(),
            status: 'VERIFIED'
          });
        }
      }

      // Write Audit Log
      const auditEntry = {
        id: `audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        action: 'PAYMENT_APPROVED',
        paymentId: id,
        targetUid,
        amount: amountToCredit,
        credits: creditsToCredit,
        reviewedBy: adminEmail,
        adminNote,
        timestamp: new Date().toISOString()
      };
      appendAudit(auditEntry);
      saveStore(store);

      res.json({
        ok: true,
        message: `Order ${id} approved successfully and credited to user ${targetUid}.`,
        order,
        userWallet: store.users[targetUid]
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to approve payment', details: err.message });
    }
  });

  // 4. POST /api/admin/payments/:id/reject - Payment Rejection with Mandatory Reason
  router.post('/payments/:id/reject', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      const adminEmail = req.adminUser?.sub || 'dhruti@preetham.com';

      if (!reason || !String(reason).trim()) {
        return res.status(400).json({ error: 'Rejection reason is strictly required.' });
      }

      const store = loadStore();
      const order = store.orders[id];
      if (!order) {
        return res.status(404).json({ error: `Payment order ${id} not found.` });
      }

      order.status = 'rejected';
      order.verifiedAt = Date.now();
      order.verifiedBy = adminEmail;
      order.adminNote = String(reason).trim();
      order.rejectionReason = String(reason).trim();

      const targetUid = order.userId || order.uid;
      if (targetUid && store.users[targetUid]) {
        store.users[targetUid].history.unshift({
          id: `tx-rejected-${Date.now()}`,
          type: 'PAYMENT_REJECTED',
          amount: order.amount,
          utr: order.utr,
          orderId: id,
          reason: String(reason).trim(),
          at: new Date().toISOString(),
          status: 'REJECTED'
        });
      }

      const auditEntry = {
        id: `audit-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
        action: 'PAYMENT_REJECTED',
        paymentId: id,
        targetUid,
        amount: order.amount,
        reviewedBy: adminEmail,
        adminNote: String(reason).trim(),
        timestamp: new Date().toISOString()
      };
      appendAudit(auditEntry);
      saveStore(store);

      res.json({
        ok: true,
        message: `Order ${id} rejected with reason logged.`,
        order
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to reject payment', details: err.message });
    }
  });

  // 5. GET /api/admin/users - User Management Roster
  router.get('/users', requireAdminAuth, (req, res) => {
    try {
      const store = loadStore();
      const users = Object.values(store.users || {}).map(u => ({
        uid: u.uid,
        displayName: u.displayName || u.uid,
        email: u.email || '',
        phone: u.phone || '',
        tradingBalance: Number(u.tradingBalance) || 0,
        credits: Number(u.credits) || 0,
        suspended: Boolean(u.suspended),
        joinedAt: u.joinedAt || new Date().toISOString(),
        lastActive: u.lastActive || new Date().toISOString(),
        historyCount: Array.isArray(u.history) ? u.history.length : 0
      }));

      res.json({ ok: true, users });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch users', details: err.message });
    }
  });

  // 6. POST /api/admin/users/:userId/status - Suspend / Unsuspend User
  router.post('/users/:userId/status', requireAdminAuth, (req, res) => {
    try {
      const { userId } = req.params;
      const { suspended } = req.body;
      const store = loadStore();

      if (!store.users[userId]) {
        return res.status(404).json({ error: `User ${userId} not found` });
      }

      store.users[userId].suspended = Boolean(suspended);
      saveStore(store);

      res.json({
        ok: true,
        message: `User ${userId} has been ${suspended ? 'suspended' : 'reactivated'}.`,
        user: store.users[userId]
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to update user status', details: err.message });
    }
  });

  // 7. POST /api/admin/users/:userId/adjust-balance - Adjust Balance with Memo
  router.post('/users/:userId/adjust-balance', requireAdminAuth, (req, res) => {
    try {
      const { userId } = req.params;
      const { deltaAmount = 0, deltaCredits = 0, note = 'Admin adjustment' } = req.body;
      const store = loadStore();

      if (!store.users[userId]) {
        return res.status(404).json({ error: `User ${userId} not found` });
      }

      const user = store.users[userId];
      user.tradingBalance = Math.max(0, (user.tradingBalance || 0) + Number(deltaAmount));
      user.credits = Math.max(0, (user.credits || 0) + Number(deltaCredits));

      user.history.unshift({
        id: `tx-adjust-${Date.now()}`,
        type: 'ADMIN_MANUAL_ADJUSTMENT',
        deltaAmount: Number(deltaAmount),
        deltaCredits: Number(deltaCredits),
        note,
        at: new Date().toISOString(),
        by: req.adminUser?.sub || 'dhruti@preetham.com'
      });

      saveStore(store);
      res.json({ ok: true, user });
    } catch (err) {
      res.status(500).json({ error: 'Failed to adjust balance', details: err.message });
    }
  });

  return router;
}
