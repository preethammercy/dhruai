// DHRU.AI - Signal Engine & Indicator Ensemble Unit Tests
// Tests technical indicator calculations, deterministic scoring, neutral filtering, and invalidation levels.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEMA,
  calculateSMA,
  calculateRSI,
  calculateMACD,
  calculateATR,
  calculateADX,
  calculatePivotPoints
} from '../server/services/indicators.js';
import { computeHistoricalScore } from '../server/services/backtestEngine.js';

test('calculateSMA returns correct moving average', () => {
  const closes = [10, 20, 30, 40, 50];
  const sma3 = calculateSMA(closes, 3);
  // (30 + 40 + 50) / 3 = 40
  assert.equal(sma3, 40);
});

test('calculateEMA weights recent prices more heavily than SMA', () => {
  const closes = [10, 10, 10, 10, 20];
  const ema = calculateEMA(closes, 3);
  const sma = calculateSMA(closes, 3);
  assert.ok(ema > sma, 'EMA should react faster to the price jump than SMA');
});

test('calculateRSI returns bounds between 0 and 100', () => {
  const strictlyRising = [10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38];
  const rsi = calculateRSI(strictlyRising, 14);
  assert.ok(rsi !== null && rsi > 70, `RSI for continuous rise should be > 70, got ${rsi}`);
  assert.ok(rsi <= 100, 'RSI cannot exceed 100');

  const strictlyFalling = [38, 36, 34, 32, 30, 28, 26, 24, 22, 20, 18, 16, 14, 12, 10];
  const rsiLow = calculateRSI(strictlyFalling, 14);
  assert.ok(rsiLow !== null && rsiLow < 30, `RSI for continuous fall should be < 30, got ${rsiLow}`);
  assert.ok(rsiLow >= 0, 'RSI cannot be below 0');
});

test('calculatePivotPoints returns correct classical floor and ceiling levels', () => {
  const high = 105;
  const low = 95;
  const close = 100;
  const pivots = calculatePivotPoints(high, low, close);

  // Pivot = (105 + 95 + 100) / 3 = 100
  assert.equal(pivots.pivot, 100);
  // R1 = 2 * 100 - 95 = 105
  assert.equal(pivots.r1, 105);
  // S1 = 2 * 100 - 105 = 95
  assert.equal(pivots.s1, 95);
  // R2 = 100 + (105 - 95) = 110
  assert.equal(pivots.r2, 110);
  // S2 = 100 - (105 - 95) = 90
  assert.equal(pivots.s2, 90);
});

test('computeHistoricalScore outputs deterministic score and positive ATR', () => {
  const mockCandles = [];
  for (let i = 0; i < 40; i++) {
    mockCandles.push({
      time: 1700000000 + i * 300,
      open: 100 + i * 0.5,
      high: 102 + i * 0.5,
      low: 99 + i * 0.5,
      close: 101 + i * 0.5,
      volume: 10000
    });
  }

  const { score, atr, rsi } = computeHistoricalScore(mockCandles);
  assert.ok(Number.isFinite(score), 'Score must be a finite number');
  assert.ok(atr > 0, 'ATR must be strictly positive');
  assert.ok(rsi >= 0 && rsi <= 100, 'RSI must be bounded between 0 and 100');
  assert.ok(score > 0, 'Steady upward trend should produce positive ensemble score');
});
