// DHRU.AI - Contact Us & Trader Help Center
import React, { useState } from 'react';
import { 
  Mail, Phone, MessageSquare, Send, CheckCircle2, 
  Sparkles, ArrowLeft, ShieldCheck, Instagram, Globe, X 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface Props {
  onNavigate?: (nav: string) => void;
  onClose?: () => void;
}

export const ContactUsPage: React.FC<Props> = ({ onNavigate, onClose }) => {
  const { user } = useAuth();
  const [name, setName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [subject, setSubject] = useState('Platform Support & Inquiries');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClose = () => {
    if (onClose) {
      onClose();
    } else if (onNavigate) {
      onNavigate('overview');
    } else if (typeof window !== 'undefined' && window.history.length > 1) {
      window.history.back();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please fill in your name, email, and message.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch('/api/contact/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          subject: subject.trim(),
          message: message.trim()
        })
      });

      const data = await res.json();
      if (data.ok) {
        setSubmitted(true);
        setMessage('');
      } else {
        setError(data.error || 'Failed to submit message.');
      }
    } catch (err: any) {
      setError(err.message || 'Network error. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 animate-fade-in pb-12 pt-2 px-3 sm:px-4">
      {/* Compact Responsive Header */}
      <div className="rounded-2xl border border-line bg-surface p-4 sm:p-5 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="p-2 rounded-xl bg-brand/10 text-brand border border-brand/20">
            <MessageSquare className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-lg sm:text-xl font-black text-ink tracking-tight flex items-center gap-2">
              <span>Contact &amp; Trader Help Center</span>
            </h1>
            <p className="text-[11px] text-ink-2 font-mono">
              Direct line to DHRU.AI Central Operations &amp; Super Admin
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigate && (
            <button
              type="button"
              onClick={() => onNavigate('overview')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-line bg-surface-2 hover:bg-surface text-xs font-mono font-bold text-ink-2 hover:text-ink transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-surface-2 hover:bg-surface border border-line hover:border-brand text-xs font-mono font-bold text-ink cursor-pointer transition-all shadow-xs"
            aria-label="Close Support Page"
          >
            <X className="w-4 h-4 text-ink-2 hover:text-ink" />
            <span>Close</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
        {/* Left Column: Direct Contact Info & Socials */}
        <div className="space-y-3 md:col-span-1">
          {/* Email Card */}
          <div className="p-4 rounded-xl border border-line bg-surface space-y-1.5 shadow-xs">
            <div className="flex items-center gap-2 text-brand font-bold text-xs uppercase font-mono">
              <Mail className="w-3.5 h-3.5" />
              <span>Super Admin Email</span>
            </div>
            <p className="text-[11px] text-ink-2">Approvals, priority verification, and queries:</p>
            <a
              href="mailto:preethamjee2008@gmail.com"
              className="text-xs font-mono font-bold text-ink hover:text-brand block break-all pt-0.5"
            >
              preethamjee2008@gmail.com
            </a>
          </div>

          {/* Social Channels (Instagram) */}
          <div className="p-4 rounded-xl border border-pink-500/25 bg-gradient-to-br from-pink-500/10 via-purple-500/5 to-transparent space-y-2.5 shadow-xs">
            <div className="flex items-center gap-2 text-pink-500 font-bold text-xs uppercase font-mono">
              <Instagram className="w-3.5 h-3.5" />
              <span>Official Instagram</span>
            </div>
            <p className="text-[11px] text-ink-2 leading-relaxed">
              Live algorithmic updates and signals:
            </p>
            <div className="space-y-1.5 font-mono text-xs">
              <a
                href="https://instagram.com/dhruai.in"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-2 rounded-lg bg-surface border border-pink-500/20 hover:border-pink-500 text-ink font-bold transition-all shadow-xs text-[11px]"
              >
                <span>Platform: @dhruai.in</span>
                <span className="text-[10px] text-pink-500 font-bold">Follow ↗</span>
              </a>

              <a
                href="https://instagram.com/preetham_va"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-2 rounded-lg bg-surface border border-purple-500/20 hover:border-purple-500 text-ink font-bold transition-all shadow-xs text-[11px]"
              >
                <span>Developer: @preetham_va</span>
                <span className="text-[10px] text-purple-500 font-bold">Follow ↗</span>
              </a>
            </div>
          </div>

          {/* Priority Guarantee Card */}
          <div className="p-3.5 rounded-xl border border-line bg-surface space-y-1 shadow-xs">
            <div className="flex items-center gap-1.5 text-emerald-500 font-bold text-xs uppercase font-mono">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Direct Admin Queue</span>
            </div>
            <p className="text-[11px] text-ink-2 leading-relaxed">
              All tickets submitted directly notify the Admin Operations Desk in real-time.
            </p>
          </div>
        </div>

        {/* Right Column: Contact & Message Form */}
        <div className="md:col-span-2">
          <div className="p-4 sm:p-5 rounded-2xl border border-line bg-surface shadow-xs">
            {submitted ? (
              <div className="text-center py-8 space-y-3">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 shadow-inner">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-ink">Inquiry Received!</h3>
                  <p className="text-xs text-ink-2 max-w-sm mx-auto">
                    Thank you, <strong>{name}</strong>. Your message is routed to Super Admin. We will reach back to you shortly.
                  </p>
                </div>
                <div className="flex items-center justify-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSubmitted(false)}
                    className="px-4 py-2 rounded-xl bg-surface-2 border border-line hover:border-brand text-ink text-xs font-bold font-mono transition-all cursor-pointer"
                  >
                    Send Another
                  </button>
                  <button
                    type="button"
                    onClick={handleClose}
                    className="px-4 py-2 rounded-xl bg-brand-fill text-on-brand text-xs font-bold font-mono uppercase tracking-wider transition-all cursor-pointer"
                  >
                    Close Support
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="border-b border-line pb-2">
                  <h2 className="text-sm font-bold text-ink">Send Message to Admin</h2>
                  <p className="text-[11px] text-ink-2">Deposits, UTR verifications, trading assistance, or feedback:</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-ink block font-mono">Your Name *</label>
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. Preetham"
                      required
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-medium outline-none focus:border-brand"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-ink block font-mono">Email Address *</label>
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      required
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-medium outline-none focus:border-brand"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-ink block font-mono">Phone / WhatsApp</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="+91 9876543210"
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-medium outline-none focus:border-brand"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-ink block font-mono">Inquiry Topic</label>
                    <select
                      value={subject}
                      onChange={e => setSubject(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-medium outline-none focus:border-brand"
                    >
                      <option value="UPI Deposit & UTR Verification">UPI Deposit &amp; UTR Verification</option>
                      <option value="Withdrawal Assistance">Withdrawal Assistance</option>
                      <option value="Quantitative Auto-Trade Desk">Quantitative Auto-Trade Desk</option>
                      <option value="SMC AI Predictions Suite">SMC AI Predictions Suite</option>
                      <option value="General Support">General Support &amp; Feedback</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-ink block font-mono">Message / Details *</label>
                  <textarea
                    rows={3}
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Describe your inquiry, payment UTR, order ID, or question..."
                    required
                    className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-medium outline-none focus:border-brand resize-none"
                  />
                </div>

                {error && (
                  <p className="text-xs text-rose-500 font-medium font-mono">{error}</p>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleClose}
                    className="py-2.5 px-4 rounded-xl border border-line bg-surface-2 hover:bg-surface text-ink text-xs font-mono font-bold cursor-pointer transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 py-2.5 rounded-xl bg-brand-fill hover:opacity-90 text-on-brand font-bold text-xs font-mono uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all active:scale-95 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{submitting ? 'Delivering...' : 'Submit Message to Admin'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
