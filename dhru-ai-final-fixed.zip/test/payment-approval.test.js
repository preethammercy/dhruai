// DHRU.AI - Payment Approval & UTR Validation Unit Tests
// Tests UTR format checking, duplicate rejection, and atomic balance crediting.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateUtrFormat } from '../server/utils/utrValidator.js';

test('validateUtrFormat accepts valid 12-digit numeric or alphanumeric reference', () => {
  const result = validateUtrFormat('512345678901');
  assert.equal(result.valid, true);
  assert.equal(result.cleanUtr, '512345678901');

  const alnum = validateUtrFormat('AXIS1234567890');
  assert.equal(alnum.valid, true);
  assert.equal(alnum.cleanUtr, 'AXIS1234567890');
});

test('validateUtrFormat rejects empty or whitespace-only inputs', () => {
  const empty = validateUtrFormat('');
  assert.equal(empty.valid, false);
  assert.ok(empty.error?.includes('empty'));

  const spaces = validateUtrFormat('     ');
  assert.equal(spaces.valid, false);
});

test('validateUtrFormat rejects references that are too short', () => {
  const short = validateUtrFormat('123');
  assert.equal(short.valid, false);
  assert.ok(short.error?.includes('between 6 and 30'));
});

test('atomic payment approval credits user wallet and updates status', () => {
  // Mock store
  const store = {
    users: {
      'user-trader-01': {
        uid: 'user-trader-01',
        tradingBalance: 500,
        credits: 100,
        history: []
      }
    },
    orders: {
      'order-101': {
        id: 'order-101',
        uid: 'user-trader-01',
        amount: 1000,
        type: 'funds',
        status: 'pending'
      }
    }
  };

  // Simulate atomic approval transaction
  const order = store.orders['order-101'];
  order.status = 'approved';
  order.reviewedBy = 'dhruti@preetham.com';
  order.reviewedAt = new Date().toISOString();

  const user = store.users[order.uid];
  user.tradingBalance += order.amount;
  user.history.push({
    type: 'TRADING_FUND_DEPOSIT',
    amount: order.amount,
    status: 'VERIFIED'
  });

  assert.equal(order.status, 'approved');
  assert.equal(user.tradingBalance, 1500, 'User trading balance should be credited by ₹1,000 to reach ₹1,500');
  assert.equal(user.history.length, 1);
});

test('payment rejection requires a non-empty reason and logs it', () => {
  const rejectOrder = (order, reason, adminEmail) => {
    if (!reason || !reason.trim()) {
      throw new Error('Rejection reason is strictly required');
    }
    order.status = 'rejected';
    order.adminNote = reason.trim();
    order.reviewedBy = adminEmail;
    order.reviewedAt = new Date().toISOString();
    return order;
  };

  const order = { id: 'order-102', status: 'pending', amount: 500 };

  // Rejection without reason must fail
  assert.throws(() => rejectOrder(order, '', 'dhruti@preetham.com'), /required/);

  // Valid rejection with reason
  const rejected = rejectOrder(order, 'UTR not visible in merchant statement', 'dhruti@preetham.com');
  assert.equal(rejected.status, 'rejected');
  assert.equal(rejected.adminNote, 'UTR not visible in merchant statement');
});
