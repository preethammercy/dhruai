// DHRU.AI - User Account, Wallet & Phone Verification Router
// Handles UID generation, Demo/Real credits, Ledger logging, and Mandatory Phone Verification.

import express from 'express';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin } from '../services/realtimeStream.js';

// Rate limiter for demo balance reset: Map<uid, timestamp>
const lastDemoReset = new Map();

/**
 * Generates a clean public UID e.g. DHRU-4A8K92
 */
export function generateUserUid() {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let rand = '';
  for (let i = 0; i < 6; i++) {
    rand += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `DHRU-${rand}`;
}

export function createUserRouter() {
  const router = express.Router();
  router.use(express.json());

  // 1. User Sync on Login / Registration (Ensures Wallet Exists)
  router.post('/sync', (req, res) => {
    try {
      const { uid: inputUid, name = '', email = '', phone = '', avatarUrl = '' } = req.body;
      const clientIp = req.ip || req.socket.remoteAddress || '';
      const nowIso = new Date().toISOString();

      let targetUid = inputUid;

      // Look up existing user by UID or email
      let existingUser = null;
      if (targetUid) {
        existingUser = db.queryOne('SELECT * FROM users WHERE uid = ?', targetUid);
      }
      if (!existingUser && email) {
        existingUser = db.queryOne('SELECT * FROM users WHERE email = ?', email);
        if (existingUser) targetUid = existingUser.uid;
      }

      if (!targetUid) {
        targetUid = generateUserUid();
      }

      // Atomic Transaction: Upsert user + ensure wallet with demo=100 & real=0 + ledger
      const syncTx = db.transaction(() => {
        if (!existingUser) {
          db.execute(`
            INSERT INTO users (uid, name, email, phone, phoneVerified, avatarUrl, kycStatus, status, createdAt, lastLoginAt, lastIp)
            VALUES (?, ?, ?, ?, ?, ?, 'unverified', 'active', ?, ?, ?)
          `, targetUid, name || 'Trader', email || null, phone || null, phone ? 1 : 0, avatarUrl || null, nowIso, nowIso, clientIp);

          // Create wallets: demo=100, real=0
          db.execute(`
            INSERT INTO wallets (uid, demoCredits, realCredits)
            VALUES (?, 100, 0)
          `, targetUid);

          // Write initial ledger row
          db.execute(`
            INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
            VALUES (?, 'demo', 'promo', 100, 100, 'Welcome 100 Demo Starting Credits', ?)
          `, targetUid, nowIso);

          // Write audit log
          db.execute(`
            INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, createdAt)
            VALUES (?, 'user', ?, 'USER_SIGNUP', 'users', ?, ?)
          `, `audit-${Date.now()}`, targetUid, targetUid, nowIso);
        } else {
          // Update login timestamp & IP
          db.execute(`
            UPDATE users SET lastLoginAt = ?, lastIp = ? WHERE uid = ?
          `, nowIso, clientIp, targetUid);

          // Ensure wallet exists for existing user
          const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', targetUid);
          if (!wallet) {
            db.execute('INSERT INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', targetUid);
            db.execute(`
              INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
              VALUES (?, 'demo', 'promo', 100, 100, 'Migrated starting demo credits', ?)
            `, targetUid, nowIso);
          }
        }
      });

      syncTx();

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', targetUid);
      const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', targetUid);

      const isNewUser = !existingUser;

      broadcastToAdmin('new_signup', { uid: targetUid, name: user.name, email: user.email });

      res.json({
        ok: true,
        isNewUser,
        user: {
          uid: user.uid,
          name: user.name,
          email: user.email,
          phone: user.phone,
          phoneVerified: Boolean(user.phoneVerified),
          onboardingCompleted: Boolean(user.onboardingCompleted),
          kycStatus: user.kycStatus,
          status: user.status,
          createdAt: user.createdAt
        },
        wallet: {
          demoCredits: wallet.demoCredits,
          realCredits: wallet.realCredits
        }
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to sync user', details: err.message });
    }
  });

  // 2. Mandatory Mobile Number Save & Verification
  router.post('/verify-phone', (req, res) => {
    try {
      const { uid, phone } = req.body;
      if (!uid || !phone) {
        return res.status(400).json({ error: 'UID and mobile number are required' });
      }

      // Normalize phone: remove spaces and hyphens
      let cleanPhone = String(phone).replace(/[\s-]/g, '').trim();
      if (!cleanPhone.startsWith('+')) {
        // If 10 digits, prefix +91
        if (/^\d{10}$/.test(cleanPhone)) {
          cleanPhone = `+91${cleanPhone}`;
        } else {
          cleanPhone = `+${cleanPhone}`;
        }
      }

      // Validate international E.164 format
      if (!/^\+[1-9]\d{9,14}$/.test(cleanPhone)) {
        return res.status(400).json({ error: 'Please enter a valid mobile number with country code (e.g. +91 9876543210)' });
      }

      // Ensure uniqueness
      const duplicate = db.queryOne('SELECT uid FROM users WHERE phone = ? AND uid != ?', cleanPhone, uid);
      if (duplicate) {
        return res.status(400).json({ error: 'This phone number is already registered to another account' });
      }

      // Update user in DB
      db.execute('UPDATE users SET phone = ?, phoneVerified = 1 WHERE uid = ?', cleanPhone, uid);

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);

      // Audit log
      db.execute(`
        INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, after, createdAt)
        VALUES (?, 'user', ?, 'PHONE_VERIFIED', 'users', ?, ?, ?)
      `, `audit-${Date.now()}`, uid, uid, JSON.stringify({ phone: cleanPhone }), new Date().toISOString());

      res.json({
        ok: true,
        message: 'Mobile number verified successfully',
        phone: cleanPhone,
        phoneVerified: true
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to verify phone', details: err.message });
    }
  });

  // 3. Reset Demo Credits to 100 (Rate limited to once per 5 minutes)
  router.post('/reset-demo', (req, res) => {
    try {
      const { uid } = req.body;
      if (!uid) return res.status(400).json({ error: 'UID is required' });

      const lastReset = lastDemoReset.get(uid) || 0;
      const now = Date.now();
      if (now - lastReset < 5 * 60 * 1000) {
        const waitSec = Math.ceil((5 * 60 * 1000 - (now - lastReset)) / 1000);
        return res.status(429).json({ error: `Demo balance can be reset once every 5 minutes. Please wait ${waitSec} seconds.` });
      }

      const tx = db.transaction(() => {
        db.execute('UPDATE wallets SET demoCredits = 100 WHERE uid = ?', uid);
        db.execute(`
          INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
          VALUES (?, 'demo', 'reset', 100, 100, 'User reset demo balance to 100', ?)
        `, uid, new Date().toISOString());
      });

      tx();
      lastDemoReset.set(uid, now);

      const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
      sendToUser(uid, 'wallet_update', { demoCredits: wallet.demoCredits, realCredits: wallet.realCredits });

      res.json({
        ok: true,
        message: 'Demo balance reset to 100 credits',
        demoCredits: 100
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to reset demo balance', details: err.message });
    }
  });

  // 4. Get User Profile with Balances, Ledger & KYC
  router.get('/profile', (req, res) => {
    try {
      const uid = req.query.uid;
      if (!uid) return res.status(400).json({ error: 'UID is required' });

      const user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) return res.status(404).json({ error: 'User not found' });

      const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid) || { demoCredits: 100, realCredits: 0 };
      const ledger = db.queryAll('SELECT * FROM wallet_ledger WHERE uid = ? ORDER BY createdAt DESC LIMIT 50', uid);
      const trades = db.queryAll('SELECT * FROM trades WHERE uid = ? ORDER BY openedAt DESC LIMIT 50', uid);
      const tickets = db.queryAll('SELECT * FROM support_tickets WHERE uid = ? ORDER BY updatedAt DESC LIMIT 20', uid);

      // Mask phone: +91 98••••••21
      let maskedPhone = user.phone;
      if (maskedPhone && maskedPhone.length > 6) {
        const start = maskedPhone.slice(0, 5);
        const end = maskedPhone.slice(-2);
        maskedPhone = `${start}••••••${end}`;
      }

      res.json({
        ok: true,
        profile: {
          uid: user.uid,
          name: user.name,
          email: user.email,
          phone: maskedPhone,
          rawPhone: user.phone,
          phoneVerified: Boolean(user.phoneVerified),
          onboardingCompleted: Boolean(user.onboardingCompleted),
          country: user.country,
          dob: user.dob,
          avatarUrl: user.avatarUrl,
          kycStatus: user.kycStatus,
          kycRejectReason: user.kycRejectReason,
          status: user.status,
          createdAt: user.createdAt,
          lastLoginAt: user.lastLoginAt
        },
        wallet: {
          demoCredits: wallet.demoCredits,
          realCredits: wallet.realCredits
        },
        ledger,
        trades,
        tickets
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch profile', details: err.message });
    }
  });

  // 5. Complete / Skip First-Time Animated Onboarding Guide
  router.post('/complete-onboarding', (req, res) => {
    try {
      const { uid } = req.body;
      if (!uid) return res.status(400).json({ error: 'UID is required' });

      db.execute('UPDATE users SET onboardingCompleted = 1 WHERE uid = ?', uid);
      res.json({ ok: true, onboardingCompleted: true });
    } catch (err) {
      res.status(500).json({ error: 'Failed to update onboarding status', details: err.message });
    }
  });

  return router;
}
