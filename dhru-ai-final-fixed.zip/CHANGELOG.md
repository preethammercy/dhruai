# DHRU.AI - Comprehensive Changelog & Architectural Overhaul

## Overview of System Architecture Overhaul
This update addresses the root disconnect between trader client actions and the admin panel, streamlines the administration console to high-priority operational workflows, strengthens mathematical trading prediction engines, and ensures zero mock/fake data across the entire platform.

---

### Phase 0: Centralized Real-Time SQLite Database & SSE Synchronization
- **Single Source of Truth**: Replaced fragmented in-memory maps and local stores with an ACID-compliant **SQLite database (WAL Mode)** located at `server/data/dhru.db`.
- **Database Migrations Engine**: Initialized `server/db/migrations/001_initial_schema.sql` versioning 15 interconnected relational tables:
  - `users`: Stores public UIDs (`DHRU-XXXXXX`), profile metadata, verified mobile numbers, KYC statuses, and login auditing.
  - `wallets`: Enforces credit isolation with strict CHECK constraints ensuring non-negative balances.
  - `wallet_ledger`: Immutable, append-only ledger tracking all deposits, withdrawals, promo redemptions, and administrative adjustments.
  - `payments`: Centralized UPI deposit store tracking transaction IDs/UTRs with strict uniqueness constraints.
  - `promo_codes` & `promo_redemptions`: Real-only credit promo code engine with per-user limits and expiration tracking.
  - `support_tickets` & `support_messages`: Real-time bidirectional support desk.
  - `broadcasts` & `broadcast_receipts`: Announcement, banner, and popup delivery engine.
  - `audit_logs`: Immutable security audit trail tracking administrative actions.
- **Automated Daily Backups**: Implemented daily database snapshotting to `server/data/backups/dhru_backup_YYYY-MM-DD.db` with automated 7-day retention rotation.
- **Server-Sent Events (SSE) Stream**: Built high-speed live event pipelines (`server/services/realtimeStream.js`) providing sub-second synchronization between users (`/api/stream/user`) and the Dhruti Admin console (`/api/stream/admin`).
- **Production Deployment Guide**: Authored `DEPLOY.md` detailing persistent disk volume configuration for Railway, Render, Fly.io, and Linux VPS environments, along with Vercel serverless fallbacks.

---

### Phase 1 & 2: User Accounts, Credit Segregation & Mobile Verification
- **Dual Wallet Architecture**:
  - Every registered trader receives a **Demo Account** (100 credits starting capital) and a **Real Account** (0 credits initial balance).
  - Clear account switcher in the header with distinct visual badges and live balance indicators.
  - "Reset Demo to 100" button with a 5-minute rate-limiting cooldown and immutable ledger record.
- **Strict Credit Segregation**:
  - Demo credits are strictly isolated from real funds.
  - Real credits are only added through approved UPI deposits or verified promotional redemption codes.
- **Mandatory Mobile Number Input**:
  - Enforces E.164 and Indian 10-digit mobile number format validation (`+91 9876543210`).
  - Verifies number uniqueness across the SQLite database and sets `phoneVerified = 1` without requiring third-party SMS OTP dependencies.

---

### Phase 3: Binance-Style User Profile & Control Desk
- Implemented comprehensive trader dossier in `src/pages/ProfilePage.tsx` with 8 modular sections:
  1. **Overview**: Trader identity, public UID with quick-copy, verified masked phone/email, and account status.
  2. **Identity & KYC**: Verification submission form with ID type, document upload, and audit queue.
  3. **Security**: Session controls, recent login audit log, and password management.
  4. **Wallet & Ledger**: Detailed breakdown of Demo and Real balances with complete immutable ledger history.
  5. **Trade History**: Realized PnL, win rate, equity curve, and closed trade details.
  6. **Redeem Promo Code**: Immediate redemption interface for promotional vouchers.
  7. **Support Chat**: Threaded live chat with admin support.
  8. **Preferences**: Theme, sound alerts, and base currency configuration.

---

### Phase 4: Payments & UTR Approval Engine (The Root Fix)
- **Eliminated Data Mismatch**: Unified user payment submissions and administrative approvals into a single shared SQLite store.
- **Validation**:
  - Enforced 10 to 22-character alphanumeric format check per NPCI UPI standards.
  - Database-level UNIQUE constraint rejecting duplicate UTR submissions.
  - Rate-limited to a maximum of 5 concurrent pending requests per user.
- **Atomic Admin Approval**:
  - Single ACID transaction: marks payment as approved, credits Real credits to the user's wallet, writes an immutable ledger entry, logs an administrative audit entry, and sends an immediate real-time SSE push.
- **Mandatory Rejection Reason**: Requires non-empty administrative explanation displayed directly in the user's inbox.

---

### Phase 5: Promo Codes Engine
- Implemented cryptographic promo code generator in `server/routes/promos.js`.
- Configurable parameters: credits, expiration dates, global usage limits, and per-user limits.
- **Strict Financial Safeguard**: Promo vouchers strictly credit **REAL** accounts only; demo balances cannot be converted or transferred.

---

### Phase 6 & 7: Dedicated Dhruti Super Admin Console (`/dhruti`)
- **Route Migration**: Relocated administration console from `/admin` to `/dhruti`. The old `/admin` path strictly returns HTTP 404.
- **Cryptographic Security**:
  - Default Admin Email: `dhruti@preetham.com`.
  - Constant-time password verification via `node:crypto.timingSafeEqual` against PBKDF2 hashes.
  - 15-minute IP lockout after 5 consecutive failed login attempts.
  - RFC 7519 HMAC-SHA256 JWT tokens with 24-hour expiration.
  - Created `scripts/generate-admin-hash.js` for custom administrator credential hashing.
- **Consolidated Control Modules**: Stripped unnecessary routes and focused strictly on:
  - Analytics Desk (live online users, deposits, revenues, signups over time).
  - Payment Approvals Desk (live audio alerts, atomic approvals/rejections).
  - User Management (UID search, complete dossier, manual adjustments with mandatory audit reasons).
  - Support Center (real-time live chat).
  - Broadcasts & Announcement Manager.
  - Promo Code Management.
  - System Settings (UPI target VPA, payee name, deposit thresholds).

---

### Phase 8: Quality Assurance, Verification & Zero-Data-Mock Verification
- **Automated Test Suite**:
  - Built and verified unit and integration tests across all modules.
  - **Result**: 11 Test Suites, 63 Tests Passed, 0 Failures (`node --test test/*.test.js`).
- **Production Build**:
  - Vite v6.4.4 production client build completed with zero errors (`npm run build`).
- **Documentation**:
  - Authored `ADMIN_GUIDE.md` detailing operational instructions for `/dhruti`.
  - Authored `DEPLOY.md` detailing production persistent volume hosting.
