// DHRU.AI - Standalone Cryptographic Authentication & JWT Engine
// Pure Node.js built-ins (node:crypto) with zero external npm dependencies.

import crypto from 'node:crypto';

export const ADMIN_EMAIL_DEFAULT = 'dhruti@preetham.com';
const JWT_EXPIRY_SECONDS = 24 * 60 * 60; // 24 hours

/**
 * Creates a cryptographically secure PBKDF2 hash of a password.
 * Format: pbkdf2$iterations$salt$hash
 */
export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const iterations = 100000;
  const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha256').toString('hex');
  return `pbkdf2$${iterations}$${salt}$${hash}`;
}

/**
 * Compares a plain password against an environment hash.
 */
export function verifyPassword(password, storedHash) {
  if (!storedHash || !password) return false;

  try {
    if (storedHash.startsWith('pbkdf2$')) {
      const [, iterStr, salt, expectedHash] = storedHash.split('$');
      const iterations = parseInt(iterStr, 10);
      const computedHash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha256').toString('hex');
      return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(expectedHash, 'hex'));
    }

    if (storedHash.startsWith('sha256$')) {
      const [, salt, expectedHash] = storedHash.split('$');
      const computedHash = crypto.createHmac('sha256', salt).update(password).digest('hex');
      return crypto.timingSafeEqual(Buffer.from(computedHash, 'hex'), Buffer.from(expectedHash, 'hex'));
    }

    // Direct constant-time string comparison for dev fallback
    const bufA = Buffer.from(password);
    const bufB = Buffer.from(storedHash);
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch (err) {
    console.error('[AdminAuth] Password verification error:', err.message);
    return false;
  }
}

/**
 * Creates an RFC 7519 HMAC-SHA256 JWT without external dependencies.
 */
export function signJwt(payload, secret) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url');
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${signature}`;
}

/**
 * Verifies an RFC 7519 HMAC-SHA256 JWT.
 */
export function verifyJwt(token, secret) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  const [encodedHeader, encodedPayload, signature] = parts;
  const data = `${encodedHeader}.${encodedPayload}`;
  const expectedSig = crypto.createHmac('sha256', secret).update(data).digest('base64url');

  if (signature.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) return null;

  try {
    const payload = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString('utf8'));
    if (payload.exp && Math.floor(Date.now() / 1000) > payload.exp) {
      return null; // Expired
    }
    return payload;
  } catch {
    return null;
  }
}

/**
 * Express middleware to protect /api/admin/* and /api/dhruti/* endpoints.
 */
export function requireAdminAuth(req, res, next) {
  const authHeader = req.headers.authorization || req.headers['x-admin-token'];
  let token = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (typeof authHeader === 'string') {
    token = authHeader.trim();
  }

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized: Admin authentication token required' });
  }

  const jwtSecret = process.env.ADMIN_JWT_SECRET || 'dhru_secret_admin_jwt_key_2026';
  const decoded = verifyJwt(token, jwtSecret);

  if (!decoded || decoded.role !== 'SUPER_ADMIN') {
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired admin session' });
  }

  req.adminUser = decoded;
  next();
}
