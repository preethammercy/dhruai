import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode, useRef } from 'react';
import { dispatchTradeNotification } from '../components/common/TradeNotificationToast';
import { useAuth } from './AuthContext';

export interface WalletTransaction {
  id: string;
  type: 'WELCOME_BONUS' | 'CREDIT_PURCHASE' | 'FUND_DEPOSIT' | 'REPORT_CONSUME' | 'AUTOTRADE_CONSUME';
  amount?: number;
  credits?: number;
  symbol?: string;
  utr?: string;
  note?: string;
  at: string;
}

export interface WalletState {
  credits: number;
  demoCredits: number;
  realCredits: number;
  tradingBalance: number;
  totalCreditsPurchased: number;
  premiumUnlocked: boolean;
  history: WalletTransaction[];
}

interface WalletContextType {
  wallet: WalletState;
  isUpiModalOpen: boolean;
  upiModalTab: 'credits' | 'funds';
  openDepositModal: (tab?: 'credits' | 'funds') => void;
  closeDepositModal: () => void;
  isWithdrawModalOpen: boolean;
  openWithdrawModal: () => void;
  closeWithdrawModal: () => void;
  requestWithdrawal: (params: {
    amount: number;
    method: 'BANK' | 'UPI';
    bankDetails?: any;
    upiDetails?: any;
  }) => Promise<{ ok: boolean; message?: string; error?: string }>;
  consumeCredits: (type: 'report' | 'autotrade', cost: number, symbol?: string) => Promise<{ ok: boolean; remaining?: number; error?: string }>;
  refreshWallet: () => Promise<void>;
  updateWalletDirectly: (patch: Partial<WalletState>) => void;
  adjustTradingBalance: (delta: number, note?: string) => void;
}

const WALLET_STORAGE_KEY = 'dhru_user_wallet_v2';

const DEFAULT_WALLET: WalletState = {
  credits: 0,          // Real account starts with 0 credits
  realCredits: 0,      // Real account credits = 0
  demoCredits: 100,    // Only Demo account gets 100 free starting credits
  tradingBalance: 0,
  totalCreditsPurchased: 0,
  premiumUnlocked: false,
  history: [
    {
      id: 'tx-demo-welcome',
      type: 'WELCOME_BONUS',
      credits: 100,
      note: '100 Free Demo Credits (Simulation Only)',
      at: new Date().toISOString()
    }
  ]
};

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const prevBalanceRef = useRef<number | null>(null);
  const prevCreditsRef = useRef<number | null>(null);

  const [wallet, setWallet] = useState<WalletState>(() => {
    try {
      const saved = localStorage.getItem(WALLET_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const realCreds = Number.isFinite(parsed.realCredits)
          ? parsed.realCredits
          : (Number.isFinite(parsed.credits) && parsed.credits !== 100 ? parsed.credits : 0);
        const demoCreds = Number.isFinite(parsed.demoCredits) ? parsed.demoCredits : 100;

        return {
          credits: realCreds,
          realCredits: realCreds,
          demoCredits: demoCreds,
          tradingBalance: Number.isFinite(parsed.tradingBalance) ? parsed.tradingBalance : 0,
          totalCreditsPurchased: Number(parsed.totalCreditsPurchased || 0),
          premiumUnlocked: Boolean(parsed.premiumUnlocked || realCreds >= 1000 || parsed.totalCreditsPurchased >= 1000),
          history: Array.isArray(parsed.history) ? parsed.history : DEFAULT_WALLET.history
        };
      }
    } catch {
      /* fallback */
    }
    return DEFAULT_WALLET;
  });

  const [isUpiModalOpen, setIsUpiModalOpen] = useState(false);
  const [upiModalTab, setUpiModalTab] = useState<'credits' | 'funds'>('credits');
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);

  // Persist wallet state
  useEffect(() => {
    try {
      localStorage.setItem(WALLET_STORAGE_KEY, JSON.stringify(wallet));
    } catch {
      /* storage unavailable */
    }
  }, [wallet]);

  // Sync with backend on startup and whenever user/order status changes
  const refreshWallet = useCallback(async () => {
    const userId = user?.uid || 'active-trader';
    try {
      const res = await fetch(`/api/wallet/state?userId=${encodeURIComponent(userId)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.wallet) {
          const newBalance = Number(data.wallet.tradingBalance) || 0;
          const newRealCredits = Number(data.wallet.realCredits ?? data.wallet.credits ?? 0);
          const newDemoCredits = Number(data.wallet.demoCredits ?? 100);

          // If balance increased, notify user
          if (prevBalanceRef.current !== null && newBalance > prevBalanceRef.current) {
            const added = newBalance - prevBalanceRef.current;
            dispatchTradeNotification({
              type: 'PROFIT',
              title: 'Trading Funds Approved & Credited!',
              symbol: 'DEPOSIT',
              status: 'VERIFIED',
              reason: `₹${added.toLocaleString('en-IN')} has been approved by Admin and credited to your trading balance!`
            });
          }

          if (prevCreditsRef.current !== null && newRealCredits > prevCreditsRef.current) {
            const added = newRealCredits - prevCreditsRef.current;
            dispatchTradeNotification({
              type: 'PROFIT',
              title: 'AI Credits Approved & Added!',
              symbol: 'CREDITS',
              status: 'VERIFIED',
              reason: `${added} AI Credits approved by Admin and added to your wallet!`
            });
          }

          prevBalanceRef.current = newBalance;
          prevCreditsRef.current = newRealCredits;

          setWallet(prev => {
            const hasChanged = 
              prev.tradingBalance !== newBalance ||
              prev.realCredits !== newRealCredits ||
              prev.demoCredits !== newDemoCredits ||
              prev.credits !== newRealCredits ||
              prev.premiumUnlocked !== Boolean(data.wallet.premiumUnlocked || newRealCredits >= 1000);
            
            if (!hasChanged) return prev; // Preserve identity to avoid glitching re-renders

            return {
              ...prev,
              ...data.wallet,
              tradingBalance: newBalance,
              realCredits: newRealCredits,
              demoCredits: newDemoCredits,
              credits: newRealCredits,
              premiumUnlocked: Boolean(data.wallet.premiumUnlocked || newRealCredits >= 1000)
            };
          });
        }
      }
    } catch {
      /* offline or local fallback */
    }
  }, [user?.uid]);

  useEffect(() => {
    void refreshWallet();
    const interval = setInterval(refreshWallet, 5000); // 5s active poll for rapid sync with admin approval
    const handleStatusChange = () => { void refreshWallet(); };
    window.addEventListener('dhru_payment_status_changed', handleStatusChange);
    window.addEventListener('dhru_orders_updated', handleStatusChange);
    window.addEventListener('focus', handleStatusChange);

    // Real-time SSE Stream connection for instant zero-latency admin approvals
    const userId = user?.uid || 'active-trader';
    let es: EventSource | null = null;
    try {
      es = new EventSource(`/api/stream/user?uid=${encodeURIComponent(userId)}`);

      es.addEventListener('wallet_update', (e: any) => {
        try {
          const data = JSON.parse(e.data);
          if (data) {
            setWallet(prev => ({
              ...prev,
              tradingBalance: Number.isFinite(data.tradingBalance) ? Number(data.tradingBalance) : prev.tradingBalance,
              realCredits: Number.isFinite(data.realCredits) ? Number(data.realCredits) : prev.realCredits,
              credits: Number.isFinite(data.credits) ? Number(data.credits) : (Number.isFinite(data.realCredits) ? Number(data.realCredits) : prev.credits),
              demoCredits: Number.isFinite(data.demoCredits) ? Number(data.demoCredits) : prev.demoCredits,
              premiumUnlocked: Boolean(data.premiumUnlocked || (Number(data.credits ?? data.realCredits) >= 1000))
            }));
          }
        } catch {}
      });

      es.addEventListener('payment_approved', (e: any) => {
        try {
          const data = JSON.parse(e.data);
          void refreshWallet();
          dispatchTradeNotification({
            type: 'PROFIT',
            title: 'Payment Order Approved!',
            symbol: data.credits ? 'CREDITS' : 'FUNDS',
            status: 'VERIFIED',
            reason: data.credits
              ? `Approved! Credited +${data.credits} AI Credits to your wallet.`
              : `Approved! Credited ₹${data.amount} Trading Funds to your balance.`
          });
        } catch {}
      });

      es.addEventListener('payment_rejected', (e: any) => {
        try {
          const data = JSON.parse(e.data);
          window.dispatchEvent(new CustomEvent('dhru_payment_status_changed'));
          dispatchTradeNotification({
            type: 'LOSS',
            title: 'Payment Rejected',
            symbol: 'PAYMENT',
            status: 'REJECTED',
            reason: data?.reason ? `Your payment was rejected: ${data.reason}` : 'Your payment was rejected by Admin.'
          });
        } catch {}
      });

      es.addEventListener('promo_claimed', () => {
        void refreshWallet();
      });
    } catch {}

    return () => {
      clearInterval(interval);
      es?.close();
      window.removeEventListener('dhru_payment_status_changed', handleStatusChange);
      window.removeEventListener('dhru_orders_updated', handleStatusChange);
      window.removeEventListener('focus', handleStatusChange);
    };
  }, [refreshWallet, user?.uid]);

  const openDepositModal = useCallback((tab: 'credits' | 'funds' = 'credits') => {
    setUpiModalTab(tab);
    setIsUpiModalOpen(true);
  }, []);

  const closeDepositModal = useCallback(() => {
    setIsUpiModalOpen(false);
  }, []);

  const openWithdrawModal = useCallback(() => {
    setIsWithdrawModalOpen(true);
  }, []);

  const closeWithdrawModal = useCallback(() => {
    setIsWithdrawModalOpen(false);
  }, []);

  const requestWithdrawal = useCallback(async (params: {
    amount: number;
    method: 'BANK' | 'UPI';
    bankDetails?: any;
    upiDetails?: any;
  }): Promise<{ ok: boolean; message?: string; error?: string }> => {
    const numAmount = Number(params.amount);
    if (!Number.isFinite(numAmount) || numAmount < 100) {
      return { ok: false, error: 'Minimum withdrawal amount is ₹100' };
    }
    if (wallet.tradingBalance < numAmount) {
      return { ok: false, error: `Insufficient real balance. You have ₹${wallet.tradingBalance.toLocaleString()}` };
    }

    try {
      void fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...params, userId: 'active-trader' })
      }).catch(() => {});
    } catch {}

    const nextBal = Number((wallet.tradingBalance - numAmount).toFixed(2));
    const newTx: WalletTransaction = {
      id: `tx-wdr-${Date.now()}`,
      type: 'AUTOTRADE_CONSUME',
      amount: numAmount,
      note: `Withdrawal request of ₹${numAmount.toLocaleString()} to ${params.method === 'UPI' ? params.upiDetails?.upiId : params.bankDetails?.bankName}`,
      at: new Date().toISOString()
    };

    setWallet(prev => ({
      ...prev,
      tradingBalance: nextBal,
      history: [newTx, ...prev.history].slice(0, 100)
    }));

    dispatchTradeNotification({
      type: 'OPEN',
      title: 'Withdrawal Request Submitted',
      accountType: 'REAL',
      symbol: 'INR',
      status: 'PENDING',
      reason: `₹${numAmount.toLocaleString()} transfer initiated to your verified ${params.method === 'UPI' ? 'UPI ID' : 'Bank Account'}. Processing within 5–15 mins.`
    });

    closeWithdrawModal();
    return { ok: true, message: 'Withdrawal request submitted successfully' };
  }, [wallet.tradingBalance, closeWithdrawModal]);

  const updateWalletDirectly = useCallback((patch: Partial<WalletState>) => {
    setWallet(prev => {
      const nextCredits = patch.credits !== undefined ? patch.credits : prev.credits;
      const nextPurchased = patch.totalCreditsPurchased !== undefined ? patch.totalCreditsPurchased : prev.totalCreditsPurchased;
      const isPremium = nextCredits >= 1000 || nextPurchased >= 1000 || patch.premiumUnlocked || prev.premiumUnlocked;
      return {
        ...prev,
        ...patch,
        credits: nextCredits,
        premiumUnlocked: isPremium
      };
    });
  }, []);

  const adjustTradingBalance = useCallback((delta: number, note = 'Realized trade P&L') => {
    if (!Number.isFinite(delta) || delta === 0) return;
    setWallet(prev => {
      const nextBal = Math.max(0, Number((prev.tradingBalance + delta).toFixed(2)));
      const newTx: WalletTransaction = {
        id: `tx-trade-${Date.now()}`,
        type: delta >= 0 ? 'FUND_DEPOSIT' : 'AUTOTRADE_CONSUME',
        amount: Math.abs(delta),
        note: `${note}: ${delta >= 0 ? '+' : '-'}₹${Math.abs(delta).toFixed(2)}`,
        at: new Date().toISOString()
      };
      return {
        ...prev,
        tradingBalance: nextBal,
        history: [newTx, ...prev.history].slice(0, 100)
      };
    });
  }, []);

  // Consumes credits for Reports (5 credits) or Auto-Trade (10 credits)
  const consumeCredits = useCallback(async (
    type: 'report' | 'autotrade',
    cost: number,
    symbol = ''
  ): Promise<{ ok: boolean; remaining?: number; error?: string }> => {
    if (wallet.credits < cost) {
      dispatchTradeNotification({
        type: 'REJECTED',
        title: 'Credits Depleted',
        symbol: symbol || 'CREDITS',
        status: 'BLOCKED',
        reason: `Need ${cost} credits (you have ${wallet.credits}). Buy credits via UPI to continue.`
      });
      openDepositModal('credits');
      return { ok: false, error: 'Insufficient credits', remaining: wallet.credits };
    }

    try {
      // Notify backend if available
      void fetch('/api/wallet/consume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, cost, symbol, userId: 'active-trader' })
      }).catch(() => {});
    } catch {
      /* offline */
    }

    const nextCredits = wallet.credits - cost;
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      type: type === 'autotrade' ? 'AUTOTRADE_CONSUME' : 'REPORT_CONSUME',
      credits: -cost,
      symbol,
      at: new Date().toISOString()
    };

    setWallet(prev => ({
      ...prev,
      credits: nextCredits,
      history: [newTx, ...prev.history].slice(0, 100)
    }));

    return { ok: true, remaining: nextCredits };
  }, [wallet.credits, openDepositModal]);

  return (
    <WalletContext.Provider
      value={{
        wallet,
        isUpiModalOpen,
        upiModalTab,
        openDepositModal,
        closeDepositModal,
        isWithdrawModalOpen,
        openWithdrawModal,
        closeWithdrawModal,
        requestWithdrawal,
        consumeCredits,
        refreshWallet,
        updateWalletDirectly,
        adjustTradingBalance
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = (): WalletContextType => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
