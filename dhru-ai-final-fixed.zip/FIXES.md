# Payment / Admin ↔ User connection fixes

## Root causes found
1. **Two wallets that never agreed.** User balance is read from `server/data/wallet-store.json`
   (`/api/wallet/state`), admin approvals wrote to SQLite, and funds were added to *AI credits* in SQLite.
2. **Triple approval.** The admin panel called three different approve endpoints. They used different status
   words (`approved` vs `VERIFIED`), so the same payment could be credited 2–3 times, or fail half-way.
3. **Fake success.** The user's submit swallowed network errors, so a payment looked "submitted" while the
   admin never received it. Admin approve also marked the payment approved locally before the server answered.
4. **Missing endpoint.** The dashboard's "Adjust balance" called `/api/admin/users/:uid/adjust-balance`, which did not exist (404).
5. **Stale status for users.** Approval wrote status to Firestore from the browser; the user's history listened to
   Firestore and kept showing "pending".
6. **Imported orders lost their type** (`credits` became `funds`) when copied from the JSON store into SQLite.
7. **Security.** `x-admin-email: dhruti@preetham.com` header alone granted full admin access (no password), and the
   admin password was hard-coded in the browser bundle.

## What changed
- `server/services/paymentCore.js` (new): the only place that approves / rejects / adjusts. Idempotent, one SQLite
  transaction, mirrors into wallet-store.json, pushes `payment_approved` + `wallet_update` / `payment_rejected` to the user.
- `server/db/migrations/003_wallet_trading_balance.sql` (new): `wallets.tradingBalance` (runs automatically on start).
- `admin.js`, `payments.js`, `wallet.js`: approve/reject routes delegate to paymentCore; added `/users/:uid/adjust-balance`.
- `adminAuth.js`: header-only bypass removed; a valid admin JWT is required. `wallet.js` admin routes use it too.
- `paymentService.ts`: submit fails loudly if the server did not get it; approve/reject make ONE call and report real errors.
- `AdminDashboardPage.tsx`: no hard-coded password, 5-second polling fallback for new requests, auto re-login on expired token.
- `AuthContext.tsx`: removed the hard-coded-password admin auto-login.

## You must do
1. `npm install && npm run build` (the shipped `dist/` is the OLD frontend).
2. Set in `.env`: `ADMIN_PASSWORD_HASH` (run `node scripts/generate-admin-hash.js`) and `ADMIN_JWT_SECRET`.
   Without them the server falls back to the default password `Dhruti@0416` and a public JWT secret. Change both.
3. **Do not host on Vercel serverless.** Each instance has its own `/tmp` database and no shared disk, so a payment
   submitted on one instance is invisible to the admin on another, and live updates (SSE) cannot work.
   Use Railway/Render/Fly/VPS with a persistent disk (see DEPLOY.md).
4. Restart the server so migration 003 runs.
