// DHRU.AI - Centralized UTR Validator
// Validates UPI UTR and Transaction Reference numbers.

export function validateUtrFormat(utr) {
  const cleanUtr = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
  if (!cleanUtr) {
    return { valid: false, cleanUtr: '', error: 'UTR or Transaction ID cannot be empty.' };
  }
  if (cleanUtr.length < 6 || cleanUtr.length > 30) {
    return {
      valid: false,
      cleanUtr,
      error: 'Invalid UTR format. UPI UTR must be between 6 and 30 characters.'
    };
  }
  return { valid: true, cleanUtr };
}
