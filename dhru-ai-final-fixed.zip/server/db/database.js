// DHRU.AI - Centralized SQLite Database Engine
// Supports better-sqlite3, node:sqlite, and sql.js (WebAssembly SQLite)
// with WAL mode/in-memory sync, transactions, automated migrations, and daily backup rotations.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isVercel = Boolean(process.env.VERCEL);
const DATA_DIR = isVercel ? '/tmp/data' : path.resolve(__dirname, '../data');
const BACKUPS_DIR = path.resolve(DATA_DIR, 'backups');
const MIGRATIONS_DIR = path.resolve(__dirname, 'migrations');
const DEFAULT_DB_PATH = path.resolve(DATA_DIR, 'dhru.db');

export const DB_PATH = process.env.DB_PATH || DEFAULT_DB_PATH;

try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(BACKUPS_DIR)) {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  }

  // If on Vercel and bundled seed db exists, copy to /tmp if not present
  if (isVercel) {
    const bundledDb = path.resolve(__dirname, '../data/dhru.db');
    if (fs.existsSync(bundledDb) && !fs.existsSync(DB_PATH)) {
      fs.copyFileSync(bundledDb, DB_PATH);
    }
  }
} catch (e) {
  console.warn('[Database] Directory init warning:', e.message);
}

// Load SQLite engine: prefer better-sqlite3, fallback to node:sqlite, then sql.js
let rawDb = null;
let dbEngineType = 'unknown';
let persistDb = () => {};

try {
  const { default: BetterSqlite3 } = await import('better-sqlite3');
  rawDb = new BetterSqlite3(DB_PATH);
  dbEngineType = 'better-sqlite3';
  rawDb.exec('PRAGMA journal_mode = WAL;');
  rawDb.exec('PRAGMA foreign_keys = ON;');
  rawDb.exec('PRAGMA busy_timeout = 5000;');
} catch {
  try {
    const { DatabaseSync } = await import('node:sqlite');
    rawDb = new DatabaseSync(DB_PATH);
    dbEngineType = 'node:sqlite';
    rawDb.exec('PRAGMA journal_mode = WAL;');
    rawDb.exec('PRAGMA foreign_keys = ON;');
    rawDb.exec('PRAGMA busy_timeout = 5000;');
  } catch {
    // Fallback to pure WebAssembly sql.js
    const { default: initSqlJs } = await import('sql.js');
    const SQL = await initSqlJs();
    let filebuffer = null;
    if (fs.existsSync(DB_PATH)) {
      try {
        filebuffer = fs.readFileSync(DB_PATH);
      } catch (err) {
        console.warn('[Database] Reading existing db file failed, initializing fresh:', err.message);
      }
    }
    const sqlDb = filebuffer && filebuffer.length > 0 ? new SQL.Database(filebuffer) : new SQL.Database();
    dbEngineType = 'sql.js';

    let saveTimeout = null;
    persistDb = () => {
      try {
        if (saveTimeout) clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          try {
            const data = sqlDb.export();
            fs.writeFileSync(DB_PATH, Buffer.from(data));
          } catch (err) {
            console.error('[Database sql.js] Persistence error:', err.message);
          }
        }, 100);
      } catch {}
    };

    // Helper: translate ? placeholders to sql.js binding
    function executeSqlJs(sql, params = []) {
      const stmt = sqlDb.prepare(sql);
      try {
        stmt.bind(params);
        while (stmt.step()) {}
      } finally {
        stmt.free();
      }
      persistDb();
    }

    function queryOneSqlJs(sql, params = []) {
      const stmt = sqlDb.prepare(sql);
      try {
        stmt.bind(params);
        if (stmt.step()) {
          return stmt.getAsObject();
        }
        return null;
      } finally {
        stmt.free();
      }
    }

    function queryAllSqlJs(sql, params = []) {
      const stmt = sqlDb.prepare(sql);
      const rows = [];
      try {
        stmt.bind(params);
        while (stmt.step()) {
          rows.push(stmt.getAsObject());
        }
        return rows;
      } finally {
        stmt.free();
      }
    }

    rawDb = {
      _sqlDb: sqlDb,
      exec(sql) {
        sqlDb.exec(sql);
        persistDb();
      },
      prepare(sql) {
        return {
          get(...params) {
            return queryOneSqlJs(sql, params);
          },
          all(...params) {
            return queryAllSqlJs(sql, params);
          },
          run(...params) {
            executeSqlJs(sql, params);
            return { changes: 1 };
          }
        };
      }
    };
  }
}

console.log(`[Database] SQLite engine initialized using ${dbEngineType} at ${DB_PATH}`);

// Run Migrations Runner
export function runMigrations() {
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      appliedAt TEXT NOT NULL
    );
  `);

  if (!fs.existsSync(MIGRATIONS_DIR)) return;

  const files = fs.readdirSync(MIGRATIONS_DIR)
    .filter(f => f.endsWith('.sql'))
    .sort();

  for (const file of files) {
    const checkStmt = rawDb.prepare('SELECT version FROM schema_migrations WHERE version = ?');
    const existing = checkStmt.get(file);
    if (!existing) {
      console.log(`[Database Migration] Applying ${file}...`);
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
      rawDb.exec(sql);
      const insertStmt = rawDb.prepare('INSERT INTO schema_migrations (version, appliedAt) VALUES (?, ?)');
      insertStmt.run(file, new Date().toISOString());
    }
  }

  // Seed default settings if empty
  seedDefaultSettings();
}

function seedDefaultSettings() {
  const defaults = [
    { key: 'target_vpa', value: 'preethamrishu@axl' },
    { key: 'payee_name', value: 'DHRU AI Quantitative Markets' },
    { key: 'min_deposit', value: '100' },
    { key: 'max_deposit', value: '1000000' },
    { key: 'credits_per_rupee', value: '1' },
    { key: 'demo_starting_credits', value: '100' },
    { key: 'maintenance_mode', value: 'false' },
    { key: 'registration_enabled', value: 'true' }
  ];

  for (const item of defaults) {
    const existing = rawDb.prepare('SELECT key FROM settings WHERE key = ?').get(item.key);
    if (!existing) {
      rawDb.prepare('INSERT INTO settings (key, value, updatedAt) VALUES (?, ?, ?)')
        .run(item.key, item.value, new Date().toISOString());
    }
  }
}

// Database Daily Backup Routine (Retains last 7 backups)
export function performDailyBackup() {
  try {
    const dateStr = new Date().toISOString().slice(0, 10);
    const backupFile = path.join(BACKUPS_DIR, `dhru_backup_${dateStr}.db`);

    // Only backup once per calendar day
    if (!fs.existsSync(backupFile) && fs.existsSync(DB_PATH)) {
      fs.copyFileSync(DB_PATH, backupFile);
      console.log(`[Database Backup] Created daily snapshot: ${backupFile}`);
    }

    // Prune backups older than 7 days
    const allBackups = fs.readdirSync(BACKUPS_DIR)
      .filter(f => f.startsWith('dhru_backup_') && f.endsWith('.db'))
      .sort();

    if (allBackups.length > 7) {
      const toDelete = allBackups.slice(0, allBackups.length - 7);
      for (const oldFile of toDelete) {
        fs.unlinkSync(path.join(BACKUPS_DIR, oldFile));
        console.log(`[Database Backup] Pruned expired backup: ${oldFile}`);
      }
    }
  } catch (err) {
    console.warn('[Database Backup] Backup error:', err.message);
  }
}

// Schedule daily backup check every 6 hours
setInterval(performDailyBackup, 6 * 60 * 60 * 1000).unref();

/**
 * Standard Database Wrapper with Transactions
 */
export const db = {
  raw: rawDb,

  exec(sql) {
    return rawDb.exec(sql);
  },

  prepare(sql) {
    return rawDb.prepare(sql);
  },

  queryOne(sql, ...params) {
    const stmt = rawDb.prepare(sql);
    return stmt.get(...params);
  },

  queryAll(sql, ...params) {
    const stmt = rawDb.prepare(sql);
    return stmt.all(...params);
  },

  execute(sql, ...params) {
    const stmt = rawDb.prepare(sql);
    return stmt.run(...params);
  },

  /**
   * Executes atomic database transaction function (returns runner)
   */
  transaction(fn) {
    return function (...args) {
      try {
        rawDb.exec('BEGIN TRANSACTION;');
        const result = fn(...args);
        rawDb.exec('COMMIT;');
        persistDb();
        return result;
      } catch (err) {
        try { rawDb.exec('ROLLBACK;'); } catch {}
        throw err;
      }
    };
  },

  /**
   * Immediately runs an atomic database transaction
   */
  runTransaction(fn) {
    try {
      rawDb.exec('BEGIN TRANSACTION;');
      const result = fn();
      rawDb.exec('COMMIT;');
      persistDb();
      return result;
    } catch (err) {
      try { rawDb.exec('ROLLBACK;'); } catch {}
      throw err;
    }
  }
};

// Initialize migrations on module import
runMigrations();
performDailyBackup();
