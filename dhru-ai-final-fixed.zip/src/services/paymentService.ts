// DHRU.AI - Centralized Shared Payments & UTR Store Service
// Manages Firestore 'payments' collection with real-time onSnapshot synchronization,
// duplicate UTR validation, atomic balance crediting, and audit logging.

import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  serverTimestamp,
  Firestore
} from 'firebase/firestore';

export interface PaymentRecord {
  id: string;
  uid: string;
  userEmail: string;
  userName?: string;
  userPhone?: string;
  amount: number;
  utr: string;
  screenshotUrl?: string;
  type: 'funds' | 'credits' | 'plan';
  credits?: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt: string | null;
  reviewedBy: string | null;
  adminNote: string;
}

export interface AuditLogRecord {
  id: string;
  paymentId: string;
  targetUid: string;
  action: 'PAYMENT_APPROVED' | 'PAYMENT_REJECTED';
  amount: number;
  reviewedBy: string;
  adminNote: string;
  timestamp: string;
}

// Initialize Firestore safely
let firestoreDb: Firestore | null = null;
try {
  const firebaseConfig = {
    apiKey: (import.meta as any).env?.VITE_FIREBASE_API_KEY || "AIzaSyDndRiIQDAtxXDOSlcVhNxCDfYblKiGf5o",
    authDomain: (import.meta as any).env?.VITE_FIREBASE_AUTH_DOMAIN || "dhru-3d8e4.firebaseapp.com",
    databaseURL: (import.meta as any).env?.VITE_FIREBASE_DATABASE_URL || "https://dhru-3d8e4-default-rtdb.firebaseio.com",
    projectId: (import.meta as any).env?.VITE_FIREBASE_PROJECT_ID || "dhru-3d8e4",
    storageBucket: (import.meta as any).env?.VITE_FIREBASE_STORAGE_BUCKET || "dhru-3d8e4.firebasestorage.app",
    messagingSenderId: (import.meta as any).env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "846237860485",
    appId: (import.meta as any).env?.VITE_FIREBASE_APP_ID || "1:846237860485:web:9f904f8bf35471b4ab5fec"
  };
  const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
  firestoreDb = getFirestore(app);
} catch (err) {
  console.warn('[PaymentService] Firestore initialization deferred:', err);
}

const LOCAL_STORAGE_KEY = 'dhru_all_submitted_orders';

function getLocalPayments(): PaymentRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    // Ignore storage parse error
  }
  return [];
}

function saveLocalPayments(payments: PaymentRecord[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(payments));
    window.dispatchEvent(new CustomEvent('dhru_orders_updated', { detail: { payments } }));
  } catch (e) {
    // Ignore storage quota error
  }
}

/**
 * Validates a UPI UTR / Transaction Reference number.
 * Must be non-empty and 6 to 30 alphanumeric characters.
 */
export function validateUtrFormat(utr: string): { valid: boolean; cleanUtr: string; error?: string } {
  const clean = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
  if (!clean) {
    return { valid: false, cleanUtr: '', error: 'UTR or Transaction ID cannot be empty.' };
  }
  if (clean.length < 6 || clean.length > 30) {
    return { valid: false, cleanUtr: clean, error: 'UTR must be between 6 and 30 alphanumeric characters.' };
  }
  return { valid: true, cleanUtr: clean };
}

/**
 * Checks if a UTR has already been submitted across the payments store.
 */
export async function isDuplicateUtr(cleanUtr: string): Promise<boolean> {
  // 1. Instant check against local store
  const locals = getLocalPayments();
  if (locals.some(p => p.utr?.toUpperCase() === cleanUtr.toUpperCase())) {
    return true;
  }

  // 2. Fast check against backend API (max 800ms)
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 800);
    const res = await fetch(`/api/payments/check-utr?utr=${encodeURIComponent(cleanUtr)}`, { signal: controller.signal });
    clearTimeout(timer);
    if (res.ok) {
      const data = await res.json();
      if (data.exists) return true;
    }
  } catch {}

  return false;
}

/**
 * Submits a new payment order to the SQLite backend and shared stores.
 * Guaranteed non-blocking and instant response.
 */
export async function submitPaymentRecord(input: {
  uid: string;
  userEmail: string;
  userName?: string;
  userPhone?: string;
  amount: number;
  utr: string;
  type?: 'funds' | 'credits' | 'plan';
  credits?: number;
  screenshotUrl?: string;
  orderId?: string;
}): Promise<PaymentRecord> {
  const { valid, cleanUtr, error: formatErr } = validateUtrFormat(input.utr);
  if (!valid) {
    throw new Error(formatErr || 'Invalid UTR format');
  }

  const isDup = await isDuplicateUtr(cleanUtr);
  if (isDup) {
    throw new Error('This UTR / Transaction ID has already been submitted. Please check your payment history or enter a new reference.');
  }

  const orderId = input.orderId || `DHRU-PAY-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const nowIso = new Date().toISOString();

  const record: PaymentRecord = {
    id: orderId,
    uid: input.uid,
    userEmail: input.userEmail,
    userName: input.userName || (input.userEmail ? input.userEmail.split('@')[0] : 'Trader'),
    userPhone: input.userPhone || '',
    amount: Number(input.amount),
    utr: cleanUtr,
    screenshotUrl: input.screenshotUrl || '',
    type: input.type || 'funds',
    credits: input.type === 'credits' ? Number(input.credits || 0) : 0,
    status: 'pending',
    createdAt: nowIso,
    reviewedAt: null,
    reviewedBy: null,
    adminNote: ''
  };

  // 1. Post to the backend. This is the ONLY thing the admin panel reads, so if it fails
  //    the user must be told - previously a network error was swallowed and the payment
  //    looked "submitted" even though the admin never received it.
  {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);
    let res: Response;
    try {
      res = await fetch('/api/payments/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: input.uid,
          amount: record.amount,
          utr: cleanUtr,
          method: 'UPI',
          userName: record.userName,
          userEmail: record.userEmail,
          userPhone: record.userPhone,
          type: record.type,
          credits: record.credits,
          orderId
        }),
        signal: controller.signal
      });
    } catch (err: any) {
      throw new Error(
        err?.name === 'AbortError'
          ? 'The server took too long to respond. Your payment was NOT submitted - please try again.'
          : 'Could not reach the server. Your payment was NOT submitted - check your connection and try again.'
      );
    } finally {
      clearTimeout(timeout);
    }
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Payment submission failed (HTTP ${res.status}). Please try again.`);
    }
    const saved = await res.json().catch(() => ({}));
    if (saved?.payment?.id) record.id = saved.payment.id;
  }

  // 2. (removed) the old second POST to /api/wallet/submit-utr re-registered the same order in a
  //    second store and could create a duplicate; /api/payments/submit already writes both stores.

  // 3. Save to local state
  const locals = getLocalPayments();
  locals.unshift(record);
  saveLocalPayments(locals);

  return record;
}

/**
 * Subscribes to payments submitted by a specific user UID in real time.
 */
export function subscribeToUserPayments(uid: string, callback: (payments: PaymentRecord[]) => void): () => void {
  let lastDigest = '';
  const safeCallback = (items: PaymentRecord[]) => {
    const digest = items.map(p => `${p.id}:${p.status}:${p.amount}:${p.utr}:${p.adminNote || ''}`).join('|');
    if (digest !== lastDigest) {
      lastDigest = digest;
      callback(items);
    }
  };

  // Initial fire with local cache
  const initial = getLocalPayments().filter(p => p.uid === uid);
  safeCallback(initial);

  // Local window event listener
  const handleLocalChange = () => {
    const updated = getLocalPayments().filter(p => p.uid === uid);
    safeCallback(updated);
  };
  window.addEventListener('dhru_orders_updated', handleLocalChange);

  // Periodic polling fallback (every 8 seconds, deduplicated)
  const fetchUserHistory = async () => {
    try {
      const res = await fetch(`/api/payments/my-history?uid=${encodeURIComponent(uid)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.payments)) {
          const others = getLocalPayments().filter(p => p.uid !== uid);
          try { localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify([...data.payments, ...others])); } catch {}
          safeCallback(data.payments);
          return;
        }
      }
    } catch {}

    try {
      const res = await fetch(`/api/wallet/user-orders?userId=${encodeURIComponent(uid)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.orders)) {
          safeCallback(data.orders);
        }
      }
    } catch {}
  };

  void fetchUserHistory();
  const interval = setInterval(fetchUserHistory, 5000);

  return () => {
    window.removeEventListener('dhru_orders_updated', handleLocalChange);
    clearInterval(interval);
  };
}

/**
 * Subscribes to ALL payments in real-time for the Admin Approval Desk.
 */
export function subscribeToAllPayments(callback: (payments: PaymentRecord[]) => void): () => void {
  callback(getLocalPayments());

  let unsubscribeFirestore = () => {};

  if (firestoreDb) {
    try {
      const q = collection(firestoreDb, 'payments');
      unsubscribeFirestore = onSnapshot(q, snapshot => {
        const items: PaymentRecord[] = [];
        snapshot.forEach(docSnap => {
          items.push(docSnap.data() as PaymentRecord);
        });
        items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        // Sync local cache
        saveLocalPayments(items);
        callback(items);
      }, err => {
        console.warn('[PaymentService] Firestore all payments snapshot error:', err.message);
      });
    } catch (err) {
      console.warn('[PaymentService] All payments snapshot setup failed:', err);
    }
  }

  const handleLocalChange = () => {
    callback(getLocalPayments());
  };
  window.addEventListener('dhru_orders_updated', handleLocalChange);

  // Immediate and periodic backend polling for admin
  const fetchAdminPayments = async () => {
    const token = sessionStorage.getItem('dhru_admin_jwt_token');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    try {
      const res = await fetch('/api/admin/payments', { headers });
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.payments)) {
          saveLocalPayments(data.payments);
          callback(data.payments);
          return;
        }
      }
    } catch {}

    try {
      const res = await fetch('/api/payments/admin/list', { headers });
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.payments)) {
          saveLocalPayments(data.payments);
          callback(data.payments);
        }
      }
    } catch {}
  };

  void fetchAdminPayments();
  const interval = setInterval(fetchAdminPayments, 3500);

  return () => {
    unsubscribeFirestore();
    window.removeEventListener('dhru_orders_updated', handleLocalChange);
    clearInterval(interval);
  };
}

/**
 * Admin approves a payment atomically:
 * 1. Updates payment status to 'approved'
 * 2. Credits user's funds or credits
 * 3. Writes an audit log record
 */
export async function approvePaymentOrder(params: {
  paymentId: string;
  adminEmail: string;
  adminToken?: string;
  adminNote?: string;
  customAmount?: number;
  customCredits?: number;
}): Promise<{ ok: boolean; message: string }> {
  const { paymentId, adminEmail, adminToken, adminNote = 'Approved by administrator' } = params;
  const token = adminToken || sessionStorage.getItem('dhru_admin_jwt_token') || '';
  if (!token) {
    return { ok: false, message: 'Admin session expired. Please log in to the admin gate again.' };
  }

  // ONE backend call. The server credits the user exactly once (it is idempotent) and pushes
  // the new balance to the user in real time. The old code called three different endpoints,
  // which could credit the same payment multiple times, and marked it approved locally
  // before the server had confirmed anything.
  let res: Response;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    res = await fetch(`/api/admin/payments/${encodeURIComponent(paymentId)}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      signal: controller.signal,
      body: JSON.stringify({
        adminEmail,
        adminNote,
        customAmount: params.customAmount,
        customCredits: params.customCredits
      })
    });
    clearTimeout(timer);
  } catch (err: any) {
    return { ok: false, message: err?.name === 'AbortError' ? 'Server timed out. Check the payment list before retrying.' : 'Could not reach the server.' };
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) {
    return { ok: false, message: data.error || `Approval failed (HTTP ${res.status}).` };
  }

  // Keep the local cache in sync only AFTER the server confirmed.
  const locals = getLocalPayments();
  const target = locals.find(p => p.id === paymentId);
  if (target) {
    target.status = 'approved';
    target.reviewedAt = new Date().toISOString();
    target.reviewedBy = adminEmail;
    target.adminNote = adminNote;
    if (params.customAmount) target.amount = params.customAmount;
    if (params.customCredits) target.credits = params.customCredits;
    saveLocalPayments(locals);
  }
  window.dispatchEvent(new CustomEvent('dhru_orders_updated', { detail: { payments: locals } }));
  return { ok: true, message: data.message || 'Payment approved and credited successfully' };
}

/**
 * Admin rejects a payment:
 * 1. Requires a non-empty rejection reason
 * 2. Updates payment status to 'rejected'
 * 3. Writes an audit log record
 */
export async function rejectPaymentOrder(params: {
  paymentId: string;
  adminEmail: string;
  adminToken?: string;
  reason: string;
}): Promise<{ ok: boolean; message: string }> {
  const { paymentId, adminEmail, adminToken, reason } = params;
  if (!reason || !reason.trim()) {
    throw new Error('A rejection reason is strictly required so the user knows why the payment was rejected.');
  }
  const token = adminToken || sessionStorage.getItem('dhru_admin_jwt_token') || '';
  if (!token) {
    return { ok: false, message: 'Admin session expired. Please log in to the admin gate again.' };
  }

  let res: Response;
  try {
    res = await fetch(`/api/admin/payments/${encodeURIComponent(paymentId)}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ reason: reason.trim(), adminEmail })
    });
  } catch {
    return { ok: false, message: 'Could not reach the server.' };
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) {
    return { ok: false, message: data.error || `Rejection failed (HTTP ${res.status}).` };
  }

  const locals = getLocalPayments();
  const target = locals.find(p => p.id === paymentId);
  if (target) {
    target.status = 'rejected';
    target.reviewedAt = new Date().toISOString();
    target.reviewedBy = adminEmail;
    target.adminNote = reason.trim();
    saveLocalPayments(locals);
  }
  window.dispatchEvent(new CustomEvent('dhru_orders_updated', { detail: { payments: locals } }));
  return { ok: true, message: data.message || 'Payment rejected successfully.' };
}
