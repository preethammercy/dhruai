// DHRU.AI - Promo Codes Engine
// Generates codes, handles redemptions, enforces per-user limits and atomic REAL-only wallet credits.

import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin } from '../services/realtimeStream.js';
import { requireAdminAuth } from './adminAuth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');

// Failed attempt rate-limiting for promo redemption: Map<identifier, { count: number, resetAt: number }>
const redemptionRateLimit = new Map();
const MAX_FAILED_ATTEMPTS = 5;
const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 mins

function checkRateLimit(key) {
  const now = Date.now();
  const entry = redemptionRateLimit.get(key);
  if (!entry || now > entry.resetAt) {
    redemptionRateLimit.set(key, { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return true;
  }
  return entry.count < MAX_FAILED_ATTEMPTS;
}

function recordFailedAttempt(key) {
  const now = Date.now();
  const entry = redemptionRateLimit.get(key) || { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
  entry.count += 1;
  redemptionRateLimit.set(key, entry);
}

function clearRateLimit(key) {
  redemptionRateLimit.delete(key);
}

/**
 * Generate a cryptographically random promo code
 */
export function generateRandomCode(prefix = 'DHRU') {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let rand = '';
  const bytes = crypto.randomBytes(6);
  for (let i = 0; i < 6; i++) {
    rand += chars.charAt(bytes[i] % chars.length);
  }
  return `${prefix}-${rand}`;
}

export function createPromosRouter() {
  const router = express.Router();
  router.use(express.json());

  // ==========================================
  // USER ENDPOINT: Redeem Promo Code
  // ==========================================
  router.post('/redeem', (req, res) => {
    try {
      const { uid, code: inputCode } = req.body;
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      const rateLimitKey = `${uid || clientIp}`;

      if (!uid) {
        return res.status(400).json({ error: 'UID is required to redeem code.' });
      }

      if (!checkRateLimit(rateLimitKey)) {
        return res.status(429).json({
          error: 'Too many invalid redemption attempts. Please wait 15 minutes before trying again.'
        });
      }

      const cleanCode = String(inputCode || '').trim().toUpperCase();
      if (!cleanCode) {
        return res.status(400).json({ error: 'Please enter a promo code.' });
      }

      // Check if user exists, if not auto-register them
      let user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) {
        const clientIp = req.ip || req.socket.remoteAddress || '';
        const nowIso = new Date().toISOString();
        db.execute(`
          INSERT OR REPLACE INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt, lastIp)
          VALUES (?, ?, NULL, NULL, 0, 'unverified', 'active', ?, ?, ?)
        `, uid, uid, nowIso, nowIso, clientIp);
        db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', uid);
        user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      }
      if (user && user.status !== 'active') {
        return res.status(403).json({ error: `Account is currently ${user.status}. Cannot redeem promo code.` });
      }

      // Query code
      const promo = db.queryOne('SELECT * FROM promo_codes WHERE UPPER(code) = ?', cleanCode);
      if (!promo) {
        recordFailedAttempt(rateLimitKey);
        return res.status(404).json({ error: 'Invalid promo code. Please verify and try again.' });
      }

      if (!promo.active) {
        recordFailedAttempt(rateLimitKey);
        return res.status(400).json({ error: 'This promo code has been deactivated.' });
      }

      if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) {
        recordFailedAttempt(rateLimitKey);
        return res.status(400).json({ error: 'This promo code has expired.' });
      }

      if (promo.maxUses > 0 && promo.usedCount >= promo.maxUses) {
        recordFailedAttempt(rateLimitKey);
        return res.status(400).json({ error: 'This promo code has reached its maximum global usage limit.' });
      }

      // Check per-user limit
      const userRedemptions = db.queryAll(
        'SELECT id FROM promo_redemptions WHERE codeId = ? AND uid = ?',
        promo.id, uid
      );
      if (userRedemptions.length >= promo.perUserLimit) {
        return res.status(400).json({
          error: promo.perUserLimit === 1
            ? 'You have already redeemed this promo code.'
            : `You have reached the limit of ${promo.perUserLimit} redemptions for this code.`
        });
      }

      const creditsToGive = Number(promo.credits);
      if (creditsToGive <= 0) {
        return res.status(400).json({ error: 'Invalid credit amount on this code.' });
      }

      const nowIso = new Date().toISOString();

      // ATOMIC TRANSACTION:
      // 1. Credit REAL account in wallets (never demo!)
      // 2. Append to wallet_ledger (account: 'real', type: 'promo')
      // 3. Insert into promo_redemptions
      // 4. Increment promo_codes.usedCount
      // 5. Append to audit_logs
      // 6. Append to notifications
      let updatedWallet = null;
      db.runTransaction(() => {
        // Ensure wallet exists
        let wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
        if (!wallet) {
          db.execute('INSERT INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', uid);
          wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
        }

        const newRealBalance = Number((wallet.realCredits + creditsToGive).toFixed(2));
        const newDemoCredits = Number(((wallet.demoCredits || 0) + creditsToGive).toFixed(2));

        // Credit both demoCredits (AI Analysis credits) and realCredits in SQLite
        db.execute('UPDATE wallets SET demoCredits = ?, realCredits = ? WHERE uid = ?', newDemoCredits, newRealBalance, uid);

        // Record in ledger
        db.execute(`
          INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
          VALUES (?, 'real', 'promo', ?, ?, ?, ?, ?)
        `, uid, creditsToGive, newRealBalance, promo.code, `Redeemed promo code: ${promo.code}`, nowIso);

        // Record redemption
        db.execute(`
          INSERT INTO promo_redemptions (codeId, uid, creditsGiven, createdAt)
          VALUES (?, ?, ?, ?)
        `, promo.id, uid, creditsToGive, nowIso);

        // Increment used count
        db.execute('UPDATE promo_codes SET usedCount = usedCount + 1 WHERE id = ?', promo.id);

        // Add Notification
        db.execute(`
          INSERT INTO notifications (uid, title, body, readAt, createdAt)
          VALUES (?, 'Promo Code Redeemed!', ?, NULL, ?)
        `, uid, `Congratulations! Code ${promo.code} gave you ${creditsToGive} AI Credits.`, nowIso);

        // Audit log
        db.execute(`
          INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, before, after, ip, userAgent, createdAt)
          VALUES (?, 'user', ?, 'REDEEM_PROMO', 'promo_codes', ?, ?, ?, ?, ?, ?)
        `, `audit-${Date.now()}`, uid, String(promo.id), JSON.stringify({ credits: wallet.demoCredits, realCredits: wallet.realCredits }), JSON.stringify({ credits: newDemoCredits, realCredits: newRealBalance, code: promo.code }), clientIp, req.headers['user-agent'] || '', nowIso);

        // Dual update wallet-store.json for AI intelligence credits
        try {
          if (fs.existsSync(WALLET_FILE)) {
            const store = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
            if (!store.users) store.users = {};
            if (!store.users[uid]) {
              store.users[uid] = {
                uid,
                credits: 0,
                realCredits: 0,
                demoCredits: 100,
                tradingBalance: 0,
                totalCreditsPurchased: 0,
                premiumUnlocked: false,
                history: []
              };
            }
            store.users[uid].credits = (Number(store.users[uid].credits) || 0) + creditsToGive;
            store.users[uid].realCredits = (Number(store.users[uid].realCredits) || 0) + creditsToGive;
            store.users[uid].totalCreditsPurchased = (Number(store.users[uid].totalCreditsPurchased) || 0) + creditsToGive;
            if (store.users[uid].credits >= 1000) {
              store.users[uid].premiumUnlocked = true;
            }
            if (!Array.isArray(store.users[uid].history)) store.users[uid].history = [];
            store.users[uid].history.unshift({
              id: `tx-promo-${Date.now()}`,
              type: 'PROMO_REDEEM',
              credits: creditsToGive,
              note: `Claimed promo code ${promo.code} (+${creditsToGive} AI Credits)`,
              at: nowIso
            });
            fs.writeFileSync(WALLET_FILE, JSON.stringify(store, null, 2), 'utf8');
          }
        } catch (err) {
          console.warn('[Promo] Wallet store sync error:', err.message);
        }

        updatedWallet = { demoCredits: newDemoCredits, realCredits: newRealBalance, credits: newRealBalance, tradingBalance: 0 };
      });

      // Clear failed rate limit on success
      clearRateLimit(rateLimitKey);

      // Real-time SSE dispatch
      sendToUser(uid, 'wallet_update', updatedWallet);
      sendToUser(uid, 'notification', {
        title: 'Promo Code Redeemed!',
        body: `Code ${promo.code} credited ${creditsToGive} AI Credits to your account.`
      });
      broadcastToAdmin('promo_redeemed', {
        uid,
        code: promo.code,
        credits: creditsToGive,
        timestamp: nowIso
      });

      return res.json({
        ok: true,
        success: true,
        message: `Successfully claimed code ${promo.code}! ${creditsToGive} AI Credits added to your account.`,
        creditsGiven: creditsToGive,
        credits: updatedWallet.credits,
        wallet: updatedWallet
      });

    } catch (err) {
      console.error('[Promo] Redemption error:', err);
      return res.status(500).json({ error: 'Failed to redeem promo code', details: err.message });
    }
  });

  // User redemption history
  router.get('/my-history', (req, res) => {
    try {
      const { uid } = req.query;
      if (!uid) return res.status(400).json({ error: 'UID required' });

      const history = db.queryAll(`
        SELECT pr.id, pr.creditsGiven, pr.createdAt, pc.code, pc.note
        FROM promo_redemptions pr
        JOIN promo_codes pc ON pr.codeId = pc.id
        WHERE pr.uid = ?
        ORDER BY pr.createdAt DESC
      `, uid);

      return res.json({ history });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch redemption history', details: err.message });
    }
  });

  // ==========================================
  // ADMIN ENDPOINTS (Protected with requireAdminAuth)
  // ==========================================

  // List all promo codes with redemption counts
  router.get('/admin/list', requireAdminAuth, (req, res) => {
    try {
      const codes = db.queryAll(`
        SELECT pc.*,
          (SELECT COUNT(*) FROM promo_redemptions pr WHERE pr.codeId = pc.id) as totalRedemptions
        FROM promo_codes pc
        ORDER BY pc.createdAt DESC
      `);
      return res.json({ codes });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to list promo codes', details: err.message });
    }
  });

  // Create or bulk generate promo codes
  router.post('/admin/create', requireAdminAuth, (req, res) => {
    try {
      const {
        code,
        credits,
        maxUses = 1,
        perUserLimit = 1,
        expiresAt = null,
        note = '',
        bulkCount = 1,
        prefix = 'DHRU'
      } = req.body;

      const numCredits = Number(credits);
      if (!Number.isFinite(numCredits) || numCredits <= 0) {
        return res.status(400).json({ error: 'Credits must be a positive number' });
      }

      const createdCodes = [];
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';
      const nowIso = new Date().toISOString();

      const count = Math.min(Math.max(1, Number(bulkCount) || 1), 50);

      db.runTransaction(() => {
        for (let i = 0; i < count; i++) {
          const finalCode = (count === 1 && code) ? String(code).trim().toUpperCase() : generateRandomCode(prefix);

          // Check if code exists
          const existing = db.queryOne('SELECT id FROM promo_codes WHERE code = ?', finalCode);
          if (existing) {
            if (count === 1) throw new Error(`Code ${finalCode} already exists.`);
            continue;
          }

          const promoId = `pc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
          db.execute(`
            INSERT INTO promo_codes (id, code, credits, maxUses, usedCount, perUserLimit, expiresAt, active, createdBy, createdAt, note)
            VALUES (?, ?, ?, ?, 0, ?, ?, 1, ?, ?, ?)
          `, promoId, finalCode, numCredits, Number(maxUses), Number(perUserLimit), expiresAt || null, adminEmail, nowIso, note || 'Admin generated');

          createdCodes.push(finalCode);
        }
      });

      return res.json({
        success: true,
        message: `Successfully generated ${createdCodes.length} promo code(s).`,
        codes: createdCodes
      });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  // Toggle active / deactivate
  router.patch('/admin/:id/toggle', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const code = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!code) return res.status(404).json({ error: 'Promo code not found' });

      const newActive = code.active ? 0 : 1;
      db.execute('UPDATE promo_codes SET active = ? WHERE id = ?', newActive, id);

      return res.json({ success: true, active: newActive });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update promo code', details: err.message });
    }
  });

  // Delete promo code
  router.delete('/admin/:id', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const code = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!code) return res.status(404).json({ error: 'Promo code not found' });

      db.execute('DELETE FROM promo_codes WHERE id = ?', id);
      return res.json({ ok: true, success: true, message: `Promo code ${code.code} deleted successfully.` });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to delete promo code', details: err.message });
    }
  });

  // Dual-method Aliases
  router.post('/admin/:id/toggle', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const code = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!code) return res.status(404).json({ error: 'Promo code not found' });
      const newActive = code.active ? 0 : 1;
      db.execute('UPDATE promo_codes SET active = ? WHERE id = ?', newActive, id);
      return res.json({ ok: true, success: true, active: newActive });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update promo code', details: err.message });
    }
  });

  router.post('/:id/toggle', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const code = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!code) return res.status(404).json({ error: 'Promo code not found' });
      const newActive = code.active ? 0 : 1;
      db.execute('UPDATE promo_codes SET active = ? WHERE id = ?', newActive, id);
      return res.json({ ok: true, success: true, active: newActive });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update promo code', details: err.message });
    }
  });

  router.delete('/:id', requireAdminAuth, (req, res) => {
    try {
      const { id } = req.params;
      const code = db.queryOne('SELECT * FROM promo_codes WHERE id = ?', id);
      if (!code) return res.status(404).json({ error: 'Promo code not found' });
      db.execute('DELETE FROM promo_codes WHERE id = ?', id);
      return res.json({ ok: true, success: true, message: `Promo code ${code.code} deleted successfully.` });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to delete promo code', details: err.message });
    }
  });

  router.post('/create', requireAdminAuth, (req, res) => {
    const handler = router.stack.find(l => l.route && l.route.path === '/admin/create')?.route?.stack[1]?.handle;
    if (handler) return handler(req, res);
    res.status(404).json({ error: 'Not found' });
  });

  router.get('/list', requireAdminAuth, (req, res) => {
    const handler = router.stack.find(l => l.route && l.route.path === '/admin/list')?.route?.stack[1]?.handle;
    if (handler) return handler(req, res);
    res.status(404).json({ error: 'Not found' });
  });

  return router;
}
