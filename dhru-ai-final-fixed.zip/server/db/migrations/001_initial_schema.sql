-- DHRU.AI Master Schema Migration 001
-- SQLite in WAL mode with Foreign Keys and Check Constraints

PRAGMA foreign_keys = ON;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  passwordHash TEXT,
  firebaseUid TEXT UNIQUE,
  phone TEXT UNIQUE,
  phoneVerified INTEGER NOT NULL DEFAULT 0,
  country TEXT DEFAULT 'IN',
  dob TEXT,
  avatarUrl TEXT,
  kycStatus TEXT CHECK(kycStatus IN ('unverified','pending','verified','rejected')) DEFAULT 'unverified',
  kycDocType TEXT,
  kycDocNumber TEXT,
  kycDocUrl TEXT,
  kycSubmittedAt TEXT,
  kycReviewedAt TEXT,
  kycReviewedBy TEXT,
  kycRejectReason TEXT,
  status TEXT CHECK(status IN ('active','suspended','banned')) DEFAULT 'active',
  createdAt TEXT NOT NULL,
  lastLoginAt TEXT,
  lastIp TEXT
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- 2. Wallets Table (Enforcing demo and real credits, never negative)
CREATE TABLE IF NOT EXISTS wallets (
  uid TEXT PRIMARY KEY REFERENCES users(uid) ON DELETE CASCADE,
  demoCredits INTEGER NOT NULL DEFAULT 100 CHECK(demoCredits >= 0),
  realCredits INTEGER NOT NULL DEFAULT 0 CHECK(realCredits >= 0)
);

-- 3. Wallet Ledger (Append-only record of all balance changes)
CREATE TABLE IF NOT EXISTS wallet_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  account TEXT NOT NULL CHECK(account IN ('demo','real')),
  type TEXT NOT NULL CHECK(type IN ('deposit','withdraw','trade_pnl','promo','admin_adjust','reset')),
  amount INTEGER NOT NULL,
  balanceAfter INTEGER NOT NULL,
  refId TEXT,
  note TEXT,
  createdAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ledger_uid ON wallet_ledger(uid);
CREATE INDEX IF NOT EXISTS idx_ledger_createdAt ON wallet_ledger(createdAt);

-- 4. Payments Table (Real money deposits awaiting admin review)
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  amount REAL NOT NULL CHECK(amount > 0),
  method TEXT DEFAULT 'UPI',
  utr TEXT NOT NULL UNIQUE,
  screenshotUrl TEXT,
  type TEXT DEFAULT 'funds',
  credits INTEGER DEFAULT 0,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected')) DEFAULT 'pending',
  adminNote TEXT,
  reviewedBy TEXT,
  createdAt TEXT NOT NULL,
  reviewedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_payments_uid ON payments(uid);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_utr ON payments(utr);

-- 5. Promo Codes (Redeemable for real credits only)
CREATE TABLE IF NOT EXISTS promo_codes (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  credits INTEGER NOT NULL CHECK(credits > 0),
  maxUses INTEGER NOT NULL CHECK(maxUses > 0),
  usedCount INTEGER NOT NULL DEFAULT 0 CHECK(usedCount <= maxUses),
  perUserLimit INTEGER NOT NULL DEFAULT 1,
  expiresAt TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  createdBy TEXT,
  createdAt TEXT NOT NULL,
  note TEXT
);

CREATE INDEX IF NOT EXISTS idx_promo_code ON promo_codes(code);

-- 6. Promo Redemptions (Tracks promo code uses per user)
CREATE TABLE IF NOT EXISTS promo_redemptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codeId TEXT NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  creditsGiven INTEGER NOT NULL,
  createdAt TEXT NOT NULL,
  UNIQUE(codeId, uid)
);

CREATE INDEX IF NOT EXISTS idx_promo_redemptions_uid ON promo_redemptions(uid);

-- 7. Trades Table (Isolated Demo and Real Trading Executions)
CREATE TABLE IF NOT EXISTS trades (
  id TEXT PRIMARY KEY,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  account TEXT NOT NULL CHECK(account IN ('demo','real')),
  symbol TEXT NOT NULL,
  side TEXT NOT NULL CHECK(side IN ('BUY','SELL')),
  qty REAL NOT NULL CHECK(qty > 0),
  entryPrice REAL NOT NULL,
  exitPrice REAL,
  stopLoss REAL,
  takeProfit REAL,
  status TEXT NOT NULL CHECK(status IN ('OPEN','CLOSED','CANCELLED')) DEFAULT 'OPEN',
  pnl REAL DEFAULT 0,
  fees REAL DEFAULT 0,
  openedAt TEXT NOT NULL,
  closedAt TEXT,
  source TEXT NOT NULL CHECK(source IN ('manual','auto')) DEFAULT 'manual'
);

CREATE INDEX IF NOT EXISTS idx_trades_uid ON trades(uid);
CREATE INDEX IF NOT EXISTS idx_trades_account ON trades(account);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);

-- 8. Support Tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id TEXT PRIMARY KEY,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('open','pending','resolved')) DEFAULT 'open',
  priority TEXT CHECK(priority IN ('low','normal','high','urgent')) DEFAULT 'normal',
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tickets_uid ON support_tickets(uid);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);

-- 9. Support Messages (Threaded messages between user and admin)
CREATE TABLE IF NOT EXISTS support_messages (
  id TEXT PRIMARY KEY,
  ticketId TEXT NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  senderType TEXT NOT NULL CHECK(senderType IN ('user','admin')),
  senderId TEXT NOT NULL,
  body TEXT NOT NULL,
  attachmentUrl TEXT,
  readAt TEXT,
  createdAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_messages_ticket ON support_messages(ticketId);

-- 10. Broadcasts (Popups, Banners, Posters, Messages)
CREATE TABLE IF NOT EXISTS broadcasts (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL CHECK(type IN ('message','poster','popup','banner')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  imageUrl TEXT,
  target TEXT NOT NULL DEFAULT 'all',
  targetSegment TEXT,
  startsAt TEXT NOT NULL,
  expiresAt TEXT,
  createdBy TEXT,
  createdAt TEXT NOT NULL
);

-- 11. Broadcast Receipts (Tracks seen/read state per user)
CREATE TABLE IF NOT EXISTS broadcast_receipts (
  broadcastId TEXT NOT NULL REFERENCES broadcasts(id) ON DELETE CASCADE,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  seenAt TEXT NOT NULL,
  PRIMARY KEY (broadcastId, uid)
);

-- 12. Notifications (User notifications inbox)
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  readAt TEXT,
  createdAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_notifications_uid ON notifications(uid);

-- 13. Audit Logs (Immutable security and action ledger)
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actorType TEXT NOT NULL,
  actorId TEXT NOT NULL,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entityId TEXT,
  before TEXT,
  after TEXT,
  ip TEXT,
  userAgent TEXT,
  createdAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_createdAt ON audit_logs(createdAt);

-- 14. Admin Sessions & Login Security
CREATE TABLE IF NOT EXISTS admin_sessions (
  id TEXT PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  adminEmail TEXT NOT NULL,
  ip TEXT,
  userAgent TEXT,
  createdAt TEXT NOT NULL,
  expiresAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS login_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  identifier TEXT NOT NULL,
  ip TEXT NOT NULL,
  success INTEGER NOT NULL,
  attemptedAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_login_attempts_ip ON login_attempts(ip, attemptedAt);

-- 15. Platform Settings (Key-Value configuration for UPI, rates, flags)
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
