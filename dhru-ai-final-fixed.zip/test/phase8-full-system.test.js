// DHRU.AI - Phase 8 Comprehensive Full System & SQLite Integration Tests
// Verifies user signup, wallets, ledger, phone validation, atomic payments, promos, and audit logs.

import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../server/db/database.js';
import { generateUserUid } from '../server/routes/users.js';
import { validateUtrFormat } from '../server/utils/utrValidator.js';
import { hashPassword, verifyPassword, signJwt, verifyJwt } from '../server/utils/cryptoAuth.js';
import { generateRandomCode } from '../server/routes/promos.js';

const testUid = `TEST-${Date.now()}`;
const testEmail = `test_${Date.now()}@dhru.ai`;

test('8.1 User Signup creates Demo (100) and Real (0) Wallets with Ledger Entry', () => {
  const nowIso = new Date().toISOString();

  db.runTransaction(() => {
    // 1. Create user
    db.execute(`
      INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt)
      VALUES (?, 'Integration Tester', ?, '+919988776655', 1, 'unverified', 'active', ?, ?)
    `, testUid, testEmail, nowIso, nowIso);

    // 2. Create wallets
    db.execute(`
      INSERT INTO wallets (uid, demoCredits, realCredits)
      VALUES (?, 100, 0)
    `, testUid);

    // 3. Write initial ledger row
    db.execute(`
      INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
      VALUES (?, 'demo', 'promo', 100, 100, 'Welcome 100 Demo Starting Credits', ?)
    `, testUid, nowIso);
  });

  const user = db.queryOne('SELECT * FROM users WHERE uid = ?', testUid);
  const wallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
  const ledger = db.queryAll('SELECT * FROM wallet_ledger WHERE uid = ?', testUid);

  assert.ok(user, 'User must exist in database');
  assert.equal(user.uid, testUid);
  assert.equal(wallet.demoCredits, 100, 'Demo credits must start at 100');
  assert.equal(wallet.realCredits, 0, 'Real credits must start at 0');
  assert.equal(ledger.length, 1, 'Ledger must contain 1 entry');
  assert.equal(ledger[0].account, 'demo');
  assert.equal(ledger[0].amount, 100);
});

test('8.2 Phone Format & Uniqueness Validation', () => {
  const invalidShort = validateUtrFormat('12');
  assert.equal(invalidShort.valid, false);

  // Phone validation logic
  const checkPhoneUnique = (phone, uid) => {
    return db.queryOne('SELECT uid FROM users WHERE phone = ? AND uid != ?', phone, uid);
  };

  const duplicate = checkPhoneUnique('+919988776655', 'DIFFERENT-UID');
  assert.ok(duplicate, 'Should find existing phone as duplicate for different UID');

  const sameUser = checkPhoneUnique('+919988776655', testUid);
  assert.ok(!sameUser, 'Should allow same user to verify their own phone');
});

test('8.3 Atomic Payment Submission & Approval Credits REAL Credits Atomically', () => {
  const paymentId = `PAY-TEST-${Date.now()}`;
  const utr = `UTR${Date.now()}`;
  const nowIso = new Date().toISOString();
  const depositAmount = 2500;

  // 1. User submits payment
  db.execute(`
    INSERT INTO payments (id, uid, amount, method, utr, status, createdAt)
    VALUES (?, ?, ?, 'UPI', ?, 'pending', ?)
  `, paymentId, testUid, depositAmount, utr, nowIso);

  const pending = db.queryOne('SELECT * FROM payments WHERE id = ?', paymentId);
  assert.equal(pending.status, 'pending');

  // 2. Admin approves atomically
  db.runTransaction(() => {
    db.execute(`
      UPDATE payments SET status = 'approved', reviewedBy = 'dhruti@preetham.com', reviewedAt = ?
      WHERE id = ?
    `, nowIso, paymentId);

    const w = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
    const newReal = w.realCredits + depositAmount;

    db.execute('UPDATE wallets SET realCredits = ? WHERE uid = ?', newReal, testUid);

    db.execute(`
      INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
      VALUES (?, 'real', 'deposit', ?, ?, ?, 'Approved UPI Deposit', ?)
    `, testUid, depositAmount, newReal, paymentId, nowIso);

    db.execute(`
      INSERT INTO audit_logs (actorType, actorId, action, entity, entityId, after, createdAt)
      VALUES ('admin', 'dhruti@preetham.com', 'PAYMENT_APPROVED', 'payments', ?, ?, ?)
    `, paymentId, JSON.stringify({ realCreditsAdded: depositAmount }), nowIso);
  });

  const updatedWallet = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
  const updatedPayment = db.queryOne('SELECT * FROM payments WHERE id = ?', paymentId);
  const ledgerEntries = db.queryAll("SELECT * FROM wallet_ledger WHERE uid = ? AND account = 'real'", testUid);

  assert.equal(updatedPayment.status, 'approved');
  assert.equal(updatedWallet.realCredits, 2500, 'Real credits must increase by deposit amount');
  assert.equal(updatedWallet.demoCredits, 100, 'Demo credits must remain untouched');
  assert.equal(ledgerEntries.length, 1);
  assert.equal(ledgerEntries[0].amount, 2500);
});

test('8.4 Promo Code Redemption Credits REAL ONLY, Enforces Per-User Limit', () => {
  const promoCode = `PROMO-${Date.now()}`;
  const promoCredits = 150;
  const nowIso = new Date().toISOString();

  const promoId = `pc-${Date.now()}`;
  // 1. Create promo code with perUserLimit = 1
  db.execute(`
    INSERT INTO promo_codes (id, code, credits, maxUses, usedCount, perUserLimit, active, createdBy, createdAt)
    VALUES (?, ?, ?, 10, 0, 1, 1, 'admin', ?)
  `, promoId, promoCode, promoCredits, nowIso);

  const promo = db.queryOne('SELECT * FROM promo_codes WHERE code = ?', promoCode);
  assert.ok(promo);

  // 2. User redeems promo code
  const redeem = (uid, codeObj) => {
    const existing = db.queryAll('SELECT id FROM promo_redemptions WHERE codeId = ? AND uid = ?', codeObj.id, uid);
    if (existing.length >= codeObj.perUserLimit) {
      throw new Error('Already redeemed code');
    }

    db.runTransaction(() => {
      const w = db.queryOne('SELECT * FROM wallets WHERE uid = ?', uid);
      const newReal = w.realCredits + codeObj.credits;

      db.execute('UPDATE wallets SET realCredits = ? WHERE uid = ?', newReal, uid);

      db.execute(`
        INSERT INTO promo_redemptions (codeId, uid, creditsGiven, createdAt)
        VALUES (?, ?, ?, ?)
      `, codeObj.id, uid, codeObj.credits, new Date().toISOString());

      db.execute(`
        INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, refId, note, createdAt)
        VALUES (?, 'real', 'promo', ?, ?, ?, 'Redeemed promo', ?)
      `, uid, codeObj.credits, newReal, codeObj.code, new Date().toISOString());

      db.execute('UPDATE promo_codes SET usedCount = usedCount + 1 WHERE id = ?', codeObj.id);
    });
  };

  // First redemption succeeds
  redeem(testUid, promo);

  const walletAfterFirst = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
  assert.equal(walletAfterFirst.realCredits, 2500 + 150, 'Real credits must increase by promo amount');
  assert.equal(walletAfterFirst.demoCredits, 100, 'Demo credits must NOT be credited from promo codes');

  // Second redemption must fail due to perUserLimit
  assert.throws(() => redeem(testUid, promo), /Already redeemed/);
});

test('8.5 Demo Balance Reset with 5-Minute Rate Limiting', () => {
  const rateLimitMap = new Map();

  const resetDemo = (uid) => {
    const last = rateLimitMap.get(uid) || 0;
    const now = Date.now();
    if (now - last < 5 * 60 * 1000) {
      throw new Error('Rate limit: wait 5 minutes');
    }

    db.runTransaction(() => {
      db.execute('UPDATE wallets SET demoCredits = 100 WHERE uid = ?', uid);
      db.execute(`
        INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
        VALUES (?, 'demo', 'reset', 100, 100, 'Demo balance reset to 100', ?)
      `, uid, new Date().toISOString());
    });

    rateLimitMap.set(uid, now);
  };

  // Reset 1 works
  resetDemo(testUid);
  const w = db.queryOne('SELECT * FROM wallets WHERE uid = ?', testUid);
  assert.equal(w.demoCredits, 100);

  // Immediate second reset fails
  assert.throws(() => resetDemo(testUid), /Rate limit/);
});

test('8.6 Clean Up Test Fixtures', () => {
  db.execute('DELETE FROM promo_redemptions WHERE uid = ?', testUid);
  db.execute('DELETE FROM wallet_ledger WHERE uid = ?', testUid);
  db.execute('DELETE FROM payments WHERE uid = ?', testUid);
  db.execute('DELETE FROM wallets WHERE uid = ?', testUid);
  db.execute('DELETE FROM users WHERE uid = ?', testUid);
});
