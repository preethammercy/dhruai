#!/usr/bin/env node
// DHRU.AI - Quantitative Walk-Forward Backtester & Model Calibration CLI
// Usage: node scripts/run-backtest.js [--symbol BTC-USD] [--tf 5m] [--all]

import { fetchInstrumentCandles } from '../server/services/marketData.js';
import { runWalkForwardValidation } from '../server/services/backtestEngine.js';

const BENCHMARK_SYMBOLS = ['BTC-USD', 'ETH-USD', 'RELIANCE.NS', 'TCS.NS', 'INFY.NS'];

function parseArgs() {
  const args = process.argv.slice(2);
  let symbol = 'BTC-USD';
  let tf = '5m';
  let runAll = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--symbol' && args[i + 1]) {
      symbol = args[i + 1].toUpperCase();
      i++;
    } else if (args[i] === '--tf' && args[i + 1]) {
      tf = args[i + 1];
      i++;
    } else if (args[i] === '--all') {
      runAll = true;
    }
  }
  return { symbol, tf, runAll };
}

async function testSymbol(symbol, tf) {
  console.log(`\n======================================================`);
  console.log(`  📊 DHRU.AI Quantitative Walk-Forward Backtest & Calibration`);
  console.log(`  Instrument : ${symbol}`);
  console.log(`  Timeframe  : ${tf}`);
  console.log(`  Friction   : 5 bps fees + 2 bps slippage per fill`);
  console.log(`======================================================\n`);

  const range = tf === '1d' ? '1y' : (tf === '60m' || tf === '1h' ? '1mo' : '5d');
  const res = await fetchInstrumentCandles(symbol, range, tf);
  const candles = res?.candles || [];

  if (!candles.length) {
    console.warn(`⚠️ No historical candles returned for ${symbol} on ${tf}. Skipping.`);
    return null;
  }

  console.log(`Loaded ${candles.length} historical candles.`);
  const result = runWalkForwardValidation(candles, { minBars: 35 });

  console.log(`\n--- Walk-Forward Out-of-Sample Performance ---`);
  console.log(`Sample Size       : ${result.samples} trades`);
  console.log(`Win Rate          : ${result.winRate !== null ? `${result.winRate}%` : 'Unvalidated (< 15 completed trades)'}`);
  console.log(`Status            : ${result.status}`);
  console.log(`Average R         : ${result.avgR}R`);
  console.log(`Profit Factor     : ${result.profitFactor}`);
  console.log(`Sharpe Ratio      : ${result.sharpeRatio ?? 'N/A'}`);
  console.log(`Precision         : ${result.precision != null ? `${(result.precision * 100).toFixed(1)}%` : 'N/A'}`);
  console.log(`Max Drawdown      : ${result.maxDrawdownPct}%`);
  console.log(`Total Return      : ${result.totalReturnPct}%`);

  if (result.calibrationTable && result.calibrationTable.length > 0) {
    console.log(`\n--- Model Calibration Table (Score Bucket vs Out-of-Sample Hit Rate) ---`);
    console.table(result.calibrationTable);
  }

  return result;
}

async function main() {
  const { symbol, tf, runAll } = parseArgs();

  if (runAll) {
    console.log(`Running comprehensive walk-forward benchmark across ${BENCHMARK_SYMBOLS.length} instruments...`);
    for (const sym of BENCHMARK_SYMBOLS) {
      await testSymbol(sym, tf);
    }
  } else {
    await testSymbol(symbol, tf);
  }
}

main().catch(err => {
  console.error('Backtest failed:', err);
  process.exit(1);
});
