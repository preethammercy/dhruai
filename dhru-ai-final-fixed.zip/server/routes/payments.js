// DHRU.AI - Payments & UTR Approval Engine (Single DB Transaction & Audit Log)
// Handles user payment submissions, UTR uniqueness, atomic approvals, and audit logging.

import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin } from '../services/realtimeStream.js';
import { requireAdminAuth } from './adminAuth.js';
import { approvePayment, rejectPayment } from '../services/paymentCore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const WALLET_FILE = path.join(DATA_DIR, 'wallet-store.json');

function loadWalletStoreSafe() {
  try {
    if (fs.existsSync(WALLET_FILE)) {
      return JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    }
  } catch {}
  return { users: {}, orders: {} };
}

function saveWalletStoreSafe(store) {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(WALLET_FILE, JSON.stringify(store, null, 2), 'utf8');
  } catch {}
}

export function createPaymentsRouter() {
  const router = express.Router();
  router.use(express.json());

  // 0. Check UTR Duplication Check
  router.get('/check-utr', (req, res) => {
    try {
      const { utr } = req.query;
      const cleanUtr = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
      if (!cleanUtr) return res.json({ exists: false });
      const duplicate = db.queryOne('SELECT id, status FROM payments WHERE utr = ?', cleanUtr);
      res.json({ exists: Boolean(duplicate), status: duplicate?.status });
    } catch {
      res.json({ exists: false });
    }
  });

  // 1. User Submits UPI Deposit with UTR
  router.post('/submit', (req, res) => {
    try {
      const {
        uid: inputUid,
        userId,
        userName = '',
        userEmail = '',
        userPhone = '',
        amount,
        utr,
        method = 'UPI',
        type = 'funds',
        credits = 0,
        screenshotUrl = '',
        orderId
      } = req.body;

      const uid = inputUid || userId;
      if (!uid) return res.status(400).json({ error: 'UID is required' });

      const numAmount = Number(amount);
      if (!Number.isFinite(numAmount) || numAmount <= 0) {
        return res.status(400).json({ error: 'Please enter a valid deposit amount.' });
      }

      // Check min/max limits from settings (allow ₹99 for credit packs)
      const minDeposit = Number((db.queryOne('SELECT value FROM settings WHERE key = ?', 'min_deposit') || {}).value || 99);
      const minAllowed = type === 'credits' ? Math.min(99, minDeposit) : minDeposit;
      const maxDeposit = Number((db.queryOne('SELECT value FROM settings WHERE key = ?', 'max_deposit') || {}).value || 1000000);

      if (numAmount < minAllowed) {
        return res.status(400).json({ error: `Minimum deposit amount is ₹${minAllowed}.` });
      }
      if (numAmount > maxDeposit) {
        return res.status(400).json({ error: `Maximum deposit amount is ₹${maxDeposit.toLocaleString('en-IN')}.` });
      }

      // Clean and validate UTR (6 to 30 alphanumeric characters)
      const cleanUtr = String(utr ?? '').trim().replace(/[^a-zA-Z0-9]/g, '');
      if (cleanUtr.length < 6 || cleanUtr.length > 30) {
        return res.status(400).json({ error: 'Please enter a valid 12-digit UPI UTR or Transaction Reference number (6 to 30 characters).' });
      }

      // Check UTR uniqueness across payments table
      const duplicateUtr = db.queryOne('SELECT id, status FROM payments WHERE utr = ?', cleanUtr);
      if (duplicateUtr) {
        return res.status(400).json({
          error: `This UTR has already been submitted (Status: ${duplicateUtr.status.toUpperCase()}). Duplicate submissions are strictly rejected.`
        });
      }

      // Max 10 pending requests per user
      const pendingCount = (db.queryOne("SELECT COUNT(*) as c FROM payments WHERE uid = ? AND status = 'pending'", uid) || {}).c || 0;
      if (pendingCount >= 10) {
        return res.status(400).json({
          error: 'You have pending payment requests awaiting verification. Please wait for them to be reviewed before submitting more.'
        });
      }

      const paymentId = orderId || `DHRU-PAY-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const nowIso = new Date().toISOString();
      const clientIp = req.ip || req.socket.remoteAddress || '';

      // Ensure user and wallet exist in SQLite
      let user = db.queryOne('SELECT * FROM users WHERE uid = ?', uid);
      if (!user) {
        db.execute(`
          INSERT INTO users (uid, name, email, phone, phoneVerified, kycStatus, status, createdAt, lastLoginAt, lastIp)
          VALUES (?, ?, ?, ?, ?, 'unverified', 'active', ?, ?, ?)
        `, uid, userName || (userEmail ? userEmail.split('@')[0] : 'Trader'), userEmail || null, userPhone || null, userPhone ? 1 : 0, nowIso, nowIso, clientIp);

        db.execute('INSERT OR IGNORE INTO wallets (uid, demoCredits, realCredits) VALUES (?, 100, 0)', uid);
        db.execute(`
          INSERT INTO wallet_ledger (uid, account, type, amount, balanceAfter, note, createdAt)
          VALUES (?, 'demo', 'promo', 100, 100, 'Welcome 100 Demo Starting Credits', ?)
        `, uid, nowIso);
      } else if (userPhone && !user.phone) {
        db.execute('UPDATE users SET phone = ?, phoneVerified = 1 WHERE uid = ?', userPhone, uid);
      }

      const finalCredits = type === 'credits' ? (Number(credits) || (numAmount === 99 ? 200 : numAmount === 199 ? 500 : numAmount === 499 ? 1200 : numAmount === 899 ? 2000 : numAmount)) : 0;

      db.execute(`
        INSERT INTO payments (id, uid, amount, method, utr, screenshotUrl, status, type, credits, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
      `, paymentId, uid, numAmount, method, cleanUtr, screenshotUrl || null, type || 'funds', finalCredits, nowIso);

      // Also persist to wallet-store.json for dual-engine synchronization
      try {
        const store = loadWalletStoreSafe();
        if (!store.orders) store.orders = {};
        store.orders[paymentId] = {
          orderId: paymentId,
          id: paymentId,
          userId: uid,
          uid,
          userName: userName || (userEmail ? userEmail.split('@')[0] : 'Trader'),
          userEmail: userEmail || '',
          userPhone: userPhone || '',
          amount: numAmount,
          utr: cleanUtr,
          type: type || 'funds',
          credits: finalCredits,
          status: 'PENDING',
          createdAt: Date.now()
        };
        saveWalletStoreSafe(store);
      } catch {}

      // Audit log
      db.execute(`
        INSERT INTO audit_logs (id, actorType, actorId, action, entity, entityId, after, createdAt)
        VALUES (?, 'user', ?, 'PAYMENT_SUBMITTED', 'payments', ?, ?, ?)
      `, `audit-${Date.now()}`, uid, paymentId, JSON.stringify({ amount: numAmount, utr: cleanUtr, type, credits: finalCredits }), nowIso);

      const payment = db.queryOne('SELECT * FROM payments WHERE id = ?', paymentId);
      const userDetails = db.queryOne('SELECT name, email, phone FROM users WHERE uid = ?', uid) || {};

      // Broadcast to Admin via SSE in real time
      broadcastToAdmin('new_payment', {
        ...payment,
        userName: userDetails.name || userName || 'Trader',
        userEmail: userDetails.email || userEmail || '',
        userPhone: userDetails.phone || userPhone || ''
      });

      res.json({
        ok: true,
        message: 'Payment submitted successfully. Awaiting Dhruti Admin verification.',
        payment
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to submit payment', details: err.message });
    }
  });

  // 2. User Gets Their Payment History with Live Status
  router.get('/my-history', (req, res) => {
    try {
      const uid = req.query.uid;
      if (!uid) return res.status(400).json({ error: 'UID is required' });
      const payments = db.queryAll('SELECT * FROM payments WHERE uid = ? ORDER BY createdAt DESC LIMIT 50', uid);
      res.json({ ok: true, payments });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch payment history', details: err.message });
    }
  });

  // 3. Admin Gets List of Payments (Filtered & Searchable)
  router.get('/admin/list', requireAdminAuth, (req, res) => {
    try {
      const { status, search, limit = 100 } = req.query;
      let sql = `
        SELECT p.*, u.name as userName, u.email as userEmail, u.phone as userPhone
        FROM payments p
        LEFT JOIN users u ON p.uid = u.uid
      `;
      const params = [];
      const conditions = [];

      if (status && status !== 'ALL') {
        conditions.push('p.status = ?');
        params.push(status.toLowerCase());
      }
      if (search && String(search).trim()) {
        const q = `%${String(search).trim()}%`;
        conditions.push('(p.utr LIKE ? OR p.id LIKE ? OR p.uid LIKE ? OR u.name LIKE ? OR u.email LIKE ?)');
        params.push(q, q, q, q, q);
      }

      if (conditions.length > 0) {
        sql += ` WHERE ${conditions.join(' AND ')}`;
      }
      sql += ' ORDER BY p.createdAt DESC LIMIT ?';
      params.push(Number(limit));

      const payments = db.queryAll(sql, ...params);
      res.json({ ok: true, payments });
    } catch (err) {
      res.status(500).json({ error: 'Failed to list payments', details: err.message });
    }
  });

  // 4. Admin Approves Payment Atomically (Credits Real Account + Ledger + Audit Log)
  router.post('/admin/:id/approve', requireAdminAuth, (req, res) => {
    try {
      const { adminNote, customAmount, customCredits } = req.body || {};
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const result = approvePayment({ id: req.params.id, adminEmail, adminNote, customAmount, customCredits });
      const { status, ...body } = result;
      res.status(status).json(body);
    } catch (err) {
      res.status(500).json({ error: 'Failed to approve payment', details: err.message });
    }
  });

  router.post('/admin/:id/reject', requireAdminAuth, (req, res) => {
    try {
      const adminEmail = req.adminUser?.email || req.adminUser?.sub || 'dhruti@preetham.com';
      const result = rejectPayment({ id: req.params.id, adminEmail, reason: req.body?.reason });
      const { status, ...body } = result;
      res.status(status).json(body);
    } catch (err) {
      res.status(500).json({ error: 'Failed to reject payment', details: err.message });
    }
  });

  // Alias routes without /admin prefix
  router.get('/list', requireAdminAuth, (req, res) => {
    const listHandler = router.stack.find(layer => layer.route && layer.route.path === '/admin/list')?.route?.stack[1]?.handle;
    if (listHandler) return listHandler(req, res);
    res.status(404).json({ error: 'Not found' });
  });

  router.post('/:id/approve', requireAdminAuth, (req, res, next) => {
    const approveHandler = router.stack.find(layer => layer.route && layer.route.path === '/admin/:id/approve')?.route?.stack[1]?.handle;
    if (approveHandler) return approveHandler(req, res, next);
    res.status(404).json({ error: 'Not found' });
  });

  router.post('/:id/reject', requireAdminAuth, (req, res, next) => {
    const rejectHandler = router.stack.find(layer => layer.route && layer.route.path === '/admin/:id/reject')?.route?.stack[1]?.handle;
    if (rejectHandler) return rejectHandler(req, res, next);
    res.status(404).json({ error: 'Not found' });
  });

  return router;
}
