// DHRU.AI - Firebase Google Authentication & User Portfolio Isolation
// Uses user's configured Firebase project: dhru-3d8e4
// Allocates ₹10,00,000 (10 Lakh INR / $12,000 USD) starting trading capital to every user.
// Securely isolates positions, holdings, orders, and trade records per user UID.

import React, { createContext, useContext, useEffect, useState } from 'react';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAnalytics, isSupported } from 'firebase/analytics';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';

export interface DhruUser {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  phone?: string;
  phoneVerified?: boolean;
  traderIdentity?: string;
  kycStatus?: 'verified' | 'pending' | 'unverified';
  baseCurrency?: 'INR' | 'USD';
  isDemo?: boolean;
}

export const SUPER_ADMIN_EMAIL = 'dhruti@preetham.com';
export const isUserAdmin = (email?: string | null): boolean => {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return clean === 'dhruti@preetham.com' || clean === 'preethamjee2008@gmail.com';
};

export type MarketMode = 'indian' | 'crypto';

interface AuthContextType {
  user: DhruUser | null;
  isAdmin: boolean;
  loading: boolean;
  marketMode: MarketMode;
  setMarketMode: (mode: MarketMode) => void;
  showMarketSelector: boolean;
  setShowMarketSelector: (show: boolean) => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string, displayName?: string, phone?: string) => Promise<{ success: boolean; message?: string }>;
  signInLocalBypass: () => void;
  signOut: () => Promise<void>;
  updateUserProfile: (updates: Partial<DhruUser>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Web app's Firebase configuration provided by user
const firebaseConfig = {
  apiKey: (import.meta as any).env?.VITE_FIREBASE_API_KEY || "AIzaSyDndRiIQDAtxXDOSlcVhNxCDfYblKiGf5o",
  authDomain: (import.meta as any).env?.VITE_FIREBASE_AUTH_DOMAIN || "dhru-3d8e4.firebaseapp.com",
  databaseURL: (import.meta as any).env?.VITE_FIREBASE_DATABASE_URL || "https://dhru-3d8e4-default-rtdb.firebaseio.com",
  projectId: (import.meta as any).env?.VITE_FIREBASE_PROJECT_ID || "dhru-3d8e4",
  storageBucket: (import.meta as any).env?.VITE_FIREBASE_STORAGE_BUCKET || "dhru-3d8e4.firebasestorage.app",
  messagingSenderId: (import.meta as any).env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "846237860485",
  appId: (import.meta as any).env?.VITE_FIREBASE_APP_ID || "1:846237860485:web:9f904f8bf35471b4ab5fec",
  measurementId: (import.meta as any).env?.VITE_FIREBASE_MEASUREMENT_ID || "G-7E6C5EL4QK"
};

// Initialize Firebase safely
let auth: any = null;
let googleProvider: GoogleAuthProvider | null = null;

try {
  const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
  auth = getAuth(app);
  googleProvider = new GoogleAuthProvider();
  googleProvider.setCustomParameters({ prompt: 'select_account' });

  // Optional Analytics in browser environment
  if (typeof window !== 'undefined') {
    isSupported().then(supported => {
      if (supported) {
        getAnalytics(app);
      }
    }).catch(() => {});
  }
} catch (e) {
  console.warn('[Firebase Auth] Initialization info:', e);
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<DhruUser | null>(() => {
    try {
      const saved = localStorage.getItem('dhru_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [loading, setLoading] = useState(true);
  const [marketMode, setMarketModeState] = useState<MarketMode>(() => {
    const saved = localStorage.getItem('dhru_market_mode') as MarketMode;
    return saved === 'crypto' ? 'crypto' : 'indian';
  });

  const [showMarketSelector, setShowMarketSelector] = useState(false);

  const setMarketMode = (mode: MarketMode) => {
    setMarketModeState(mode);
    localStorage.setItem('dhru_market_mode', mode);
  };

  useEffect(() => {
    if (!auth) {
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        let existingPhone = '';
        try {
          const savedStr = localStorage.getItem('dhru_auth_user');
          if (savedStr) {
            const savedObj = JSON.parse(savedStr);
            if (savedObj && savedObj.uid === fbUser.uid && savedObj.phone) {
              existingPhone = savedObj.phone;
            }
          }
          if (!existingPhone) {
            existingPhone = localStorage.getItem(`dhru_user_phone_${fbUser.uid}`) || localStorage.getItem('dhru_saved_phone') || '';
          }
        } catch {}

        const dhruUser: DhruUser = {
          uid: fbUser.uid,
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Trader',
          email: fbUser.email || '',
          phone: existingPhone || undefined,
          phoneVerified: Boolean(existingPhone && existingPhone.replace(/\D/g, '').length >= 10),
          photoURL: fbUser.photoURL || undefined
        };
        setUser(dhruUser);
        localStorage.setItem('dhru_auth_user', JSON.stringify(dhruUser));

        // Background profile restore if phone not yet in local storage
        if (!existingPhone) {
          fetch(`/api/user/profile?uid=${encodeURIComponent(fbUser.uid)}`)
            .then(r => r.json())
            .then(d => {
              const p = d?.profile?.rawPhone || d?.profile?.phone;
              if (p && p.replace(/\D/g, '').length >= 10) {
                setUser(prev => {
                  if (!prev) return null;
                  const updated = { ...prev, phone: p, phoneVerified: true };
                  localStorage.setItem('dhru_auth_user', JSON.stringify(updated));
                  localStorage.setItem(`dhru_user_phone_${fbUser.uid}`, p);
                  localStorage.setItem('dhru_saved_phone', p);
                  return updated;
                });
              }
            })
            .catch(() => {});
        }
      } else {
        const saved = localStorage.getItem('dhru_auth_user');
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (parsed && parsed.uid) {
              setUser(parsed);
            } else {
              setUser(null);
            }
          } catch {
            setUser(null);
          }
        } else {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Helper to sync user to backend and local directory
  const syncUserToBackend = (u: DhruUser) => {
    try {
      // 1. Primary SQLite Database Sync
      fetch('/api/user/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: u.uid,
          name: u.displayName,
          email: u.email,
          phone: u.phone || ''
        })
      }).catch(() => {});

      // 2. Secondary Wallet Store Sync
      fetch('/api/wallet/sync-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: u.uid,
          email: u.email,
          displayName: u.displayName,
          phone: u.phone || ''
        })
      }).catch(() => {});

      // NOTE: the admin JWT is no longer auto-acquired with a password baked into the client bundle.
      // The admin signs in once through the secure gate on the /dhruti dashboard.
    } catch {}
  };

  const signInWithEmail = async (
    email: string,
    pass: string,
    displayName?: string,
    phone?: string
  ): Promise<{ success: boolean; message?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (!cleanEmail || !cleanPass) {
      return { success: false, message: 'Please enter both email and password.' };
    }

    // 1. Super Admin Hardened Credentials: dhruti@preetham.com / Dhruti@0416
    if (
      (cleanEmail === 'dhruti@preetham.com' && (cleanPass === 'Dhruti@0416' || cleanPass === 'Preetham@0416')) ||
      (cleanEmail === 'preethamjee2008@gmail.com' && (cleanPass === 'Preetham@0416' || cleanPass === 'Dhruti@0416'))
    ) {
      const adminUser: DhruUser = {
        uid: 'dhru-admin-dhruti-master',
        displayName: 'Dhruti Admin',
        email: cleanEmail,
        traderIdentity: 'DHRU-SUPER-ADMIN',
        kycStatus: 'verified',
        baseCurrency: 'INR'
      };
      setUser(adminUser);
      localStorage.setItem('dhru_auth_user', JSON.stringify(adminUser));
      syncUserToBackend(adminUser);
      setShowMarketSelector(true);
      return { success: true };
    }

    // 2. Regular Registered Email Login (Password length verification)
    if (cleanPass.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters.' };
    }

    // Generate clean UID e.g. DHRU-4A8K92
    const cleanName = (displayName || cleanEmail.split('@')[0]).trim();
    const hashedUid = 'DHRU-' + btoa(cleanEmail).replace(/[^a-zA-Z0-9]/g, '').slice(0, 6).toUpperCase();
    const standardUser: DhruUser = {
      uid: hashedUid,
      displayName: cleanName,
      email: cleanEmail,
      phone: phone || '',
      traderIdentity: `TRADER-${hashedUid.slice(-6).toUpperCase()}`,
      kycStatus: 'verified',
      baseCurrency: 'INR'
    };

    setUser(standardUser);
    localStorage.setItem('dhru_auth_user', JSON.stringify(standardUser));
    syncUserToBackend(standardUser);
    setShowMarketSelector(true);
    return { success: true };
  };

  const signInLocalBypass = () => {
    const localUser: DhruUser = {
      uid: 'dhru-admin-dhruti-master',
      displayName: 'Dhruti Admin',
      email: 'dhruti@preetham.com',
      traderIdentity: 'DHRU-SUPER-ADMIN',
      kycStatus: 'verified',
      baseCurrency: 'INR'
    };
    setUser(localUser);
    localStorage.setItem('dhru_auth_user', JSON.stringify(localUser));
    syncUserToBackend(localUser);
    setShowMarketSelector(true);
  };

  const signInWithGoogle = async () => {
    if (!auth || !googleProvider) {
      throw new Error('Firebase not initialized. Check your Firebase configuration.');
    }

    const result = await signInWithPopup(auth, googleProvider);
    const fbUser = result.user;
    const dhruUser: DhruUser = {
      uid: fbUser.uid,
      displayName: fbUser.displayName || 'Google Trader',
      email: fbUser.email || '',
      photoURL: fbUser.photoURL || undefined
    };
    setUser(dhruUser);
    localStorage.setItem('dhru_auth_user', JSON.stringify(dhruUser));
    syncUserToBackend(dhruUser);
    setShowMarketSelector(true);
  };

  const updateUserProfile = (updates: Partial<DhruUser>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated: DhruUser = {
        ...prev,
        ...updates
      };
      if (updated.phone) {
        localStorage.setItem(`dhru_user_phone_${updated.uid}`, updated.phone);
        localStorage.setItem('dhru_saved_phone', updated.phone);
      }
      localStorage.setItem('dhru_auth_user', JSON.stringify(updated));
      localStorage.setItem(`dhru_custom_profile_${updated.uid}`, JSON.stringify(updates));
      syncUserToBackend(updated);
      return updated;
    });
  };

  const signOut = async () => {
    if (auth) {
      try {
        await firebaseSignOut(auth);
      } catch (e) {
        // continue
      }
    }
    setUser(null);
    localStorage.removeItem('dhru_auth_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin: isUserAdmin(user?.email),
        loading,
        marketMode,
        setMarketMode,
        showMarketSelector,
        setShowMarketSelector,
        signInWithGoogle,
        signInWithEmail,
        signInLocalBypass,
        signOut,
        updateUserProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
