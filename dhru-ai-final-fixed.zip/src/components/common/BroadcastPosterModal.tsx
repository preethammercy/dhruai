// DHRU.AI - Global Broadcast & Poster Pop-up Modal
// Displays site-wide administrative announcements, promotional posters, and alerts
// to users upon opening the website, featuring an instant closing button.

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, AlertCircle, Bell, ExternalLink, Check, Megaphone } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export interface BroadcastItem {
  id: string | number;
  type?: 'poster' | 'popup' | 'banner' | 'message' | 'alert' | 'promo' | string;
  title: string;
  body?: string;
  message?: string;
  imageUrl?: string;
  target?: string;
  createdAt?: string;
}

export const BroadcastPosterModal: React.FC = () => {
  const { user } = useAuth();
  const [activeBroadcast, setActiveBroadcast] = useState<BroadcastItem | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Check if a broadcast was already dismissed by this user
  const isDismissed = useCallback((id: string | number) => {
    try {
      const key = `dhru_dismissed_bc_${id}`;
      return localStorage.getItem(key) === 'true';
    } catch {
      return false;
    }
  }, []);

  const fetchActiveBroadcast = useCallback(async () => {
    try {
      const uid = user?.uid || '';
      const res = await fetch(`/api/broadcasts/active?uid=${encodeURIComponent(uid)}`);
      if (res.ok) {
        const data = await res.json();
        const bc = data.active || (Array.isArray(data.broadcasts) && data.broadcasts[0]) || (data.broadcast?.active ? data.broadcast : null);
        if (bc && bc.title && !isDismissed(bc.id)) {
          setActiveBroadcast(bc);
          setIsOpen(true);
          return;
        }
      }
    } catch {}

    // Fallback to wallet broadcast active route
    try {
      const res2 = await fetch('/api/wallet/broadcast/active');
      if (res2.ok) {
        const data2 = await res2.json();
        if (data2.ok && data2.broadcast?.active && data2.broadcast.title) {
          const bc = data2.broadcast;
          if (!isDismissed(bc.id || 'bc-active')) {
            setActiveBroadcast({
              id: bc.id || 'bc-active',
              type: bc.type || 'poster',
              title: bc.title,
              body: bc.message || bc.body || '',
              message: bc.message || bc.body || '',
              imageUrl: bc.imageUrl || ''
            });
            setIsOpen(true);
          }
        }
      }
    } catch {}
  }, [user?.uid, isDismissed]);

  useEffect(() => {
    void fetchActiveBroadcast();

    // Listen to real-time broadcast SSE updates
    const handleNewBroadcast = (e: any) => {
      try {
        const bc = e.detail;
        if (bc && bc.title && !isDismissed(bc.id)) {
          setActiveBroadcast(bc);
          setIsOpen(true);
        }
      } catch {}
    };

    window.addEventListener('dhru_new_broadcast', handleNewBroadcast);
    return () => {
      window.removeEventListener('dhru_new_broadcast', handleNewBroadcast);
    };
  }, [fetchActiveBroadcast, isDismissed]);

  const handleClose = () => {
    if (activeBroadcast?.id) {
      try {
        localStorage.setItem(`dhru_dismissed_bc_${activeBroadcast.id}`, 'true');
        // Notify backend of dismissal
        fetch('/api/broadcasts/dismiss', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ broadcastId: activeBroadcast.id, uid: user?.uid || 'guest' })
        }).catch(() => {});
      } catch {}
    }
    setIsOpen(false);
  };

  if (!isOpen || !activeBroadcast) return null;

  const contentMessage = activeBroadcast.body || activeBroadcast.message || '';
  const isPoster = Boolean(activeBroadcast.imageUrl && activeBroadcast.imageUrl.trim().length > 5);
  const typeUpper = (activeBroadcast.type || 'ANNOUNCEMENT').toUpperCase();

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 320 }}
          className="relative w-full max-w-lg sm:max-w-xl bg-surface border border-brand/30 dark:border-line rounded-3xl shadow-2xl overflow-hidden z-10 my-auto flex flex-col"
        >
          {/* Top Header Banner with Close Button */}
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-line bg-surface-2/80">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-brand/10 text-brand">
                <Megaphone className="w-4 h-4 text-cyan-400" />
              </span>
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-ink">
                {typeUpper === 'POSTER' ? '📢 Featured Poster' : typeUpper === 'ALERT' ? '⚠️ Important Notice' : '⚡ System Announcement'}
              </span>
            </div>

            {/* Prominent Top Close Button */}
            <button
              onClick={handleClose}
              type="button"
              className="p-1.5 rounded-xl bg-surface hover:bg-rose-500/10 text-ink-3 hover:text-rose-500 border border-line transition-all cursor-pointer shadow-xs active:scale-90"
              aria-label="Close Announcement"
              title="Close (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Poster Image (If provided) */}
            {isPoster && (
              <div className="relative rounded-2xl overflow-hidden border border-line bg-slate-950/40 shadow-inner group">
                {!imageLoaded && (
                  <div className="h-56 sm:h-64 flex items-center justify-center text-ink-3 font-mono text-xs animate-pulse">
                    Loading Poster...
                  </div>
                )}
                <img
                  src={activeBroadcast.imageUrl}
                  alt={activeBroadcast.title}
                  onLoad={() => setImageLoaded(true)}
                  onError={() => setImageLoaded(true)}
                  className={`w-full max-h-80 object-contain rounded-2xl transition-transform duration-300 group-hover:scale-[1.01] ${
                    imageLoaded ? 'block' : 'hidden'
                  }`}
                />
              </div>
            )}

            {/* Title */}
            <div className="space-y-1.5">
              <h2 className="text-lg sm:text-xl font-black text-ink tracking-tight flex items-center gap-2">
                <span>{activeBroadcast.title}</span>
              </h2>

              {/* Message Description */}
              {contentMessage && (
                <p className="text-xs sm:text-sm text-ink-2 leading-relaxed whitespace-pre-line font-sans">
                  {contentMessage}
                </p>
              )}
            </div>
          </div>

          {/* Modal Footer with Closing Buttons */}
          <div className="px-5 py-3.5 bg-surface-2 border-t border-line flex items-center justify-between gap-3">
            <span className="text-[11px] font-mono text-ink-3 hidden sm:inline">
              DHRU.AI Official Platform Broadcast
            </span>

            <div className="flex items-center gap-2.5 ml-auto w-full sm:w-auto">
              <button
                type="button"
                onClick={handleClose}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase font-mono tracking-wider shadow-md hover:shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Close &amp; Continue</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
