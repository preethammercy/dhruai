import React, { useState } from 'react';
import { useTrading } from '../../context/TradingContext';
import { useWallet } from '../../context/WalletContext';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, RotateCcw, Coins, Wallet } from 'lucide-react';

interface Props {
  compact?: boolean;
}

export const AccountTypeSwitcher: React.FC<Props> = ({ compact }) => {
  const { accountType, setAccountType } = useTrading();
  const { wallet, updateWalletDirectly } = useWallet();
  const { user } = useAuth();
  const [resetBusy, setResetBusy] = useState(false);

  const handleResetDemo = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Reset your Demo paper balance back to 100 Credits?')) return;
    setResetBusy(true);
    try {
      const res = await fetch('/api/user/reset-demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: user?.uid || 'default-user' })
      });
      const d = await res.json();
      if (d.ok) {
        updateWalletDirectly({ demoCredits: 100 });
      } else {
        alert(d.error || 'Failed to reset demo balance');
      }
    } catch {
      updateWalletDirectly({ demoCredits: 100 });
    } finally {
      setResetBusy(false);
    }
  };

  const demoBalance = Number.isFinite(wallet.demoCredits) ? wallet.demoCredits : 100;
  const realCredits = Number.isFinite(wallet.realCredits) ? wallet.realCredits : (Number.isFinite(wallet.credits) ? wallet.credits : 0);
  const realBalance = Number.isFinite(wallet.tradingBalance) ? wallet.tradingBalance : 0;

  if (compact) {
    return (
      <div className="inline-flex items-center p-0.5 rounded-xl bg-surface-2 border border-line text-[11px] font-mono font-bold select-none gap-0.5">
        <button
          type="button"
          onClick={() => setAccountType('demo')}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-all cursor-pointer ${
            accountType === 'demo'
              ? 'bg-amber-500 text-white shadow-sm font-black'
              : 'text-ink-2 hover:text-ink'
          }`}
          title={`Demo Simulation: ${demoBalance} Credits`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-amber-200" />
          <span>Demo</span>
          <span className="opacity-80 text-[10px]">({demoBalance})</span>
        </button>

        <button
          type="button"
          onClick={() => setAccountType('real')}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-all cursor-pointer ${
            accountType === 'real'
              ? 'bg-emerald-600 text-white shadow-sm font-black'
              : 'text-ink-2 hover:text-ink'
          }`}
          title={`Real Account: ₹${realBalance}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-200" />
          <span>Real</span>
          <span className="opacity-80 text-[10px]">₹{realBalance}</span>
        </button>

        {accountType === 'demo' && (
          <button
            type="button"
            onClick={handleResetDemo}
            disabled={resetBusy}
            className="p-1 rounded-md text-amber-600 hover:text-amber-700 hover:bg-amber-500/10 transition-all cursor-pointer"
            title="Reset demo credits to 100"
          >
            <RotateCcw className={`w-3 h-3 ${resetBusy ? 'animate-spin' : ''}`} />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="inline-flex items-center p-1 rounded-2xl bg-surface-2 border border-line text-xs font-mono font-bold select-none gap-1">
      <button
        type="button"
        onClick={() => setAccountType('demo')}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
          accountType === 'demo'
            ? 'bg-amber-500 text-white shadow-md font-black'
            : 'text-ink-2 hover:text-ink'
        }`}
        title="Switch to Demo Simulation Account (100 Free Credits)"
      >
        <span className="w-2 h-2 rounded-full bg-amber-200 animate-pulse" />
        <span>DEMO</span>
        <span className={`ml-1 text-[10px] px-1.5 py-0.5 rounded font-mono ${
          accountType === 'demo' ? 'bg-amber-700/80 text-amber-100' : 'bg-surface text-ink-2'
        }`}>
          {demoBalance} Cr
        </span>
      </button>

      <button
        type="button"
        onClick={() => setAccountType('real')}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
          accountType === 'real'
            ? 'bg-emerald-600 text-white shadow-md font-black'
            : 'text-ink-2 hover:text-ink'
        }`}
        title="Switch to Real Account (Live Wallet Funds)"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-200 animate-pulse" />
        <span>REAL ACCOUNT</span>
        <span className={`ml-1 text-[10px] px-1.5 py-0.5 rounded font-mono ${
          accountType === 'real' ? 'bg-emerald-800/80 text-emerald-100' : 'bg-surface text-ink-2'
        }`}>
          ₹{realBalance.toLocaleString()}
        </span>
      </button>

      {accountType === 'demo' && (
        <button
          type="button"
          onClick={handleResetDemo}
          disabled={resetBusy}
          className="flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-mono text-amber-600 dark:text-amber-400 hover:bg-amber-500/10 border border-amber-500/30 transition-all cursor-pointer ml-0.5"
          title="Reset demo balance back to 100 credits"
        >
          <RotateCcw className={`w-3 h-3 ${resetBusy ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">Reset 100</span>
        </button>
      )}
    </div>
  );
};
