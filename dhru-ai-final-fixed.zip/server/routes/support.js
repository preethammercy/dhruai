// DHRU.AI - Support Tickets & Live Chat Router
// Enables real-time two-way communication between users and the Dhruti Admin Desk.

import express from 'express';
import { db } from '../db/database.js';
import { sendToUser, broadcastToAdmin } from '../services/realtimeStream.js';
import { requireAdminAuth } from './adminAuth.js';

export function createSupportRouter() {
  const router = express.Router();
  router.use(express.json());

  // ==========================================
  // USER ENDPOINTS
  // ==========================================

  // 1. Get user tickets
  router.get('/my-tickets', (req, res) => {
    try {
      const { uid } = req.query;
      if (!uid) return res.status(400).json({ error: 'UID is required' });

      const tickets = db.queryAll(`
        SELECT t.*,
          (SELECT COUNT(*) FROM support_messages m WHERE m.ticketId = t.id AND m.senderType = 'admin' AND m.readAt IS NULL) as unreadAdminMessages,
          (SELECT body FROM support_messages m WHERE m.ticketId = t.id ORDER BY m.createdAt DESC LIMIT 1) as lastMessageBody,
          (SELECT createdAt FROM support_messages m WHERE m.ticketId = t.id ORDER BY m.createdAt DESC LIMIT 1) as lastMessageAt
        FROM support_tickets t
        WHERE t.uid = ?
        ORDER BY t.updatedAt DESC
      `, uid);

      return res.json({ tickets });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch tickets', details: err.message });
    }
  });

  // 2. Create new ticket
  router.post('/tickets', (req, res) => {
    try {
      const { uid, subject, message, priority = 'normal', attachmentUrl = '' } = req.body;
      if (!uid || !subject?.trim() || !message?.trim()) {
        return res.status(400).json({ error: 'UID, subject, and message are required.' });
      }

      const nowIso = new Date().toISOString();

      let newTicketId = null;
      db.runTransaction(() => {
        // Insert ticket
        db.execute(`
          INSERT INTO support_tickets (uid, subject, status, priority, createdAt, updatedAt)
          VALUES (?, ?, 'open', ?, ?, ?)
        `, uid, subject.trim(), priority, nowIso, nowIso);

        const row = db.queryOne('SELECT last_insert_rowid() as id');
        newTicketId = row.id;

        // Insert first message
        db.execute(`
          INSERT INTO support_messages (ticketId, senderType, senderId, body, attachmentUrl, readAt, createdAt)
          VALUES (?, 'user', ?, ?, ?, NULL, ?)
        `, newTicketId, uid, message.trim(), attachmentUrl, nowIso);
      });

      const fullTicket = db.queryOne('SELECT * FROM support_tickets WHERE id = ?', newTicketId);

      // Real-time dispatch to Admin
      broadcastToAdmin('new_support_ticket', {
        ticket: fullTicket,
        firstMessage: message.trim(),
        userUid: uid
      });

      return res.json({
        success: true,
        message: 'Support ticket submitted successfully.',
        ticket: fullTicket
      });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to create ticket', details: err.message });
    }
  });

  // 3. Get ticket message thread
  router.get('/tickets/:ticketId/messages', (req, res) => {
    try {
      const { ticketId } = req.params;
      const { uid } = req.query; // If user requesting, verify ownership

      const ticket = db.queryOne('SELECT * FROM support_tickets WHERE id = ?', ticketId);
      if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

      // If uid provided, ensure match
      if (uid && ticket.uid !== uid) {
        return res.status(403).json({ error: 'Access denied: not ticket owner.' });
      }

      // Mark admin messages as read if user is viewing
      if (uid) {
        db.execute(`
          UPDATE support_messages
          SET readAt = ?
          WHERE ticketId = ? AND senderType = 'admin' AND readAt IS NULL
        `, new Date().toISOString(), ticketId);
      }

      const messages = db.queryAll(`
        SELECT * FROM support_messages
        WHERE ticketId = ?
        ORDER BY createdAt ASC
      `, ticketId);

      return res.json({ ticket, messages });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to load messages', details: err.message });
    }
  });

  // 4. Send message in ticket (User)
  router.post('/tickets/:ticketId/messages', (req, res) => {
    try {
      const { ticketId } = req.params;
      const { uid, body, attachmentUrl = '' } = req.body;

      if (!uid || !body?.trim()) {
        return res.status(400).json({ error: 'UID and message body are required' });
      }

      const ticket = db.queryOne('SELECT * FROM support_tickets WHERE id = ?', ticketId);
      if (!ticket) return res.status(404).json({ error: 'Ticket not found' });
      if (ticket.uid !== uid) return res.status(403).json({ error: 'Access denied' });

      const nowIso = new Date().toISOString();

      db.runTransaction(() => {
        db.execute(`
          INSERT INTO support_messages (ticketId, senderType, senderId, body, attachmentUrl, readAt, createdAt)
          VALUES (?, 'user', ?, ?, ?, NULL, ?)
        `, ticketId, uid, body.trim(), attachmentUrl, nowIso);

        // Reopen ticket if resolved
        db.execute(`
          UPDATE support_tickets
          SET status = CASE WHEN status = 'resolved' THEN 'open' ELSE status END,
              updatedAt = ?
          WHERE id = ?
        `, nowIso, ticketId);
      });

      const messageRecord = db.queryOne(`
        SELECT * FROM support_messages WHERE ticketId = ? ORDER BY id DESC LIMIT 1
      `, ticketId);

      // Notify admin
      broadcastToAdmin('support_message', {
        ticketId: Number(ticketId),
        senderType: 'user',
        uid,
        message: messageRecord
      });

      return res.json({ success: true, message: messageRecord });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to send message', details: err.message });
    }
  });

  // ==========================================
  // ADMIN ENDPOINTS (Protected)
  // ==========================================

  // Admin: Get all tickets with user details
  router.get('/admin/tickets', requireAdminAuth, (req, res) => {
    try {
      const { status } = req.query;
      let sql = `
        SELECT t.*, u.name as userName, u.email as userEmail, u.phone as userPhone,
          (SELECT COUNT(*) FROM support_messages m WHERE m.ticketId = t.id) as messageCount,
          (SELECT body FROM support_messages m WHERE m.ticketId = t.id ORDER BY m.createdAt DESC LIMIT 1) as lastMessageBody,
          (SELECT createdAt FROM support_messages m WHERE m.ticketId = t.id ORDER BY m.createdAt DESC LIMIT 1) as lastMessageAt
        FROM support_tickets t
        LEFT JOIN users u ON t.uid = u.uid
      `;
      const params = [];
      if (status && status !== 'all') {
        sql += ' WHERE t.status = ?';
        params.push(status);
      }
      sql += ' ORDER BY t.updatedAt DESC';

      const tickets = db.queryAll(sql, ...params);
      return res.json({ tickets });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch admin tickets', details: err.message });
    }
  });

  // Admin: Reply to ticket
  router.post('/admin/tickets/:ticketId/reply', requireAdminAuth, (req, res) => {
    try {
      const { ticketId } = req.params;
      const { body, attachmentUrl = '', statusChange } = req.body;
      const adminEmail = req.adminUser?.email || 'dhruti@preetham.com';

      if (!body?.trim()) {
        return res.status(400).json({ error: 'Reply message cannot be empty' });
      }

      const ticket = db.queryOne('SELECT * FROM support_tickets WHERE id = ?', ticketId);
      if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

      const nowIso = new Date().toISOString();

      db.runTransaction(() => {
        db.execute(`
          INSERT INTO support_messages (ticketId, senderType, senderId, body, attachmentUrl, readAt, createdAt)
          VALUES (?, 'admin', ?, ?, ?, NULL, ?)
        `, ticketId, adminEmail, body.trim(), attachmentUrl, nowIso);

        const newStatus = statusChange || (ticket.status === 'open' ? 'pending' : ticket.status);
        db.execute(`
          UPDATE support_tickets
          SET status = ?, updatedAt = ?
          WHERE id = ?
        `, newStatus, nowIso, ticketId);
      });

      const messageRecord = db.queryOne(`
        SELECT * FROM support_messages WHERE ticketId = ? ORDER BY id DESC LIMIT 1
      `, ticketId);

      // Send real-time SSE to user
      sendToUser(ticket.uid, 'support_message', {
        ticketId: Number(ticketId),
        senderType: 'admin',
        body: body.trim(),
        message: messageRecord,
        status: statusChange || ticket.status
      });

      sendToUser(ticket.uid, 'notification', {
        title: `Reply on Ticket #${ticketId}`,
        body: `Support team: ${body.trim().slice(0, 80)}...`
      });

      return res.json({ success: true, message: messageRecord });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to send admin reply', details: err.message });
    }
  });

  // Admin: Change ticket status (open, pending, resolved)
  router.patch('/admin/tickets/:ticketId/status', requireAdminAuth, (req, res) => {
    try {
      const { ticketId } = req.params;
      const { status } = req.body;

      if (!['open', 'pending', 'resolved'].includes(status)) {
        return res.status(400).json({ error: 'Invalid status' });
      }

      const nowIso = new Date().toISOString();
      db.execute('UPDATE support_tickets SET status = ?, updatedAt = ? WHERE id = ?', status, nowIso, ticketId);

      const ticket = db.queryOne('SELECT * FROM support_tickets WHERE id = ?', ticketId);
      if (ticket) {
        sendToUser(ticket.uid, 'ticket_status_change', { ticketId: Number(ticketId), status });
      }

      return res.json({ success: true, status });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update ticket status', details: err.message });
    }
  });

  return router;
}
