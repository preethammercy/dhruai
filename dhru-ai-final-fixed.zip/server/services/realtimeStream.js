// DHRU.AI - Real-Time Server-Sent Events (SSE) Stream Service
// Powers live synchronized channels for both User (/api/stream/user) and Admin (/api/stream/admin).
// Features keepalive heartbeats, authenticated channels, and broadcast dispatchers.

import express from 'express';
import { requireAdminAuth } from '../routes/adminAuth.js';
import { db } from '../db/database.js';

// Map<uid, Set<Response>>
const userConnections = new Map();
// Set<Response>
const adminConnections = new Set();

/**
 * Send an event payload to a specific user UID's active SSE connections.
 */
export function sendToUser(uid, eventType, data) {
  if (!uid) return;
  const connections = userConnections.get(uid);
  if (connections && connections.size > 0) {
    const payload = `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of connections) {
      try {
        res.write(payload);
      } catch (err) {
        connections.delete(res);
      }
    }
  }
}

/**
 * Broadcast an event payload to all active Dhruti Admin connections.
 */
export function broadcastToAdmin(eventType, data) {
  if (adminConnections.size === 0) return;
  const payload = `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of adminConnections) {
    try {
      res.write(payload);
    } catch (err) {
      adminConnections.delete(res);
    }
  }
}

/**
 * Broadcast an event to ALL active connections (users and admins).
 */
export function broadcastToAll(eventType, data) {
  const payload = `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const [, conns] of userConnections) {
    for (const res of conns) {
      try {
        res.write(payload);
      } catch (err) {
        conns.delete(res);
      }
    }
  }
  for (const res of adminConnections) {
    try {
      res.write(payload);
    } catch (err) {
      adminConnections.delete(res);
    }
  }
}

/**
 * Helper to get currently online user count
 */
export function getOnlineUsersCount() {
  let count = 0;
  for (const [, conns] of userConnections) {
    if (conns.size > 0) count++;
  }
  return count;
}

export const getOnlineUserCount = getOnlineUsersCount;

// 15-second keep-alive heartbeat ping to prevent connection drops across proxies/firewalls
setInterval(() => {
  const ping = ':keepalive\n\n';
  for (const [, conns] of userConnections) {
    for (const res of conns) {
      try {
        res.write(ping);
      } catch {
        conns.delete(res);
      }
    }
  }
  for (const res of adminConnections) {
    try {
      res.write(ping);
    } catch {
      adminConnections.delete(res);
    }
  }
}, 15000).unref();

/**
 * Express Router for Real-Time SSE Streams
 */
export function createRealtimeRouter() {
  const router = express.Router();

  // 1. User Stream Channel: /api/stream/user?uid=...
  router.get('/user', (req, res) => {
    const uid = req.query.uid || req.headers['x-user-uid'];
    if (!uid) {
      return res.status(400).json({ error: 'UID is required for user stream' });
    }

    // Configure SSE headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    if (!userConnections.has(uid)) {
      userConnections.set(uid, new Set());
    }
    userConnections.get(uid).add(res);

    // Initial snapshot: wallet balance, unread notifications, pending payments
    try {
      const wallet = db.queryOne('SELECT demoCredits, realCredits, tradingBalance FROM wallets WHERE uid = ?', uid) || { demoCredits: 100, realCredits: 0, tradingBalance: 0 };
      const pendingPayments = db.queryAll('SELECT * FROM payments WHERE uid = ? AND status = "pending" ORDER BY createdAt DESC', uid);
      const notifications = db.queryAll('SELECT * FROM notifications WHERE uid = ? AND readAt IS NULL ORDER BY createdAt DESC LIMIT 10', uid);
      const activeBroadcasts = db.queryAll('SELECT * FROM broadcasts WHERE expiresAt > datetime("now") ORDER BY createdAt DESC LIMIT 5');

      res.write(`event: snapshot\ndata: ${JSON.stringify({ wallet, pendingPayments, notifications, activeBroadcasts })}\n\n`);
    } catch (err) {
      console.warn('[RealtimeStream] Error sending initial user snapshot:', err.message);
    }

    // Notify admin of user online count change
    broadcastToAdmin('online_users_count', { count: getOnlineUsersCount() });

    req.on('close', () => {
      const conns = userConnections.get(uid);
      if (conns) {
        conns.delete(res);
        if (conns.size === 0) userConnections.delete(uid);
      }
      broadcastToAdmin('online_users_count', { count: getOnlineUsersCount() });
    });
  });

  // 2. Admin Stream Channel: /api/stream/admin
  // Uses admin token query or header
  router.get('/admin', requireAdminAuth, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    adminConnections.add(res);

    // Initial admin snapshot: pending payments, open tickets, online users count
    try {
      const pendingPayments = db.queryAll('SELECT * FROM payments WHERE status = "pending" ORDER BY createdAt DESC');
      const openTickets = db.queryAll('SELECT * FROM support_tickets WHERE status != "resolved" ORDER BY updatedAt DESC');
      const recentTrades = db.queryAll('SELECT * FROM trades ORDER BY openedAt DESC LIMIT 15');
      const stats = {
        onlineUsers: getOnlineUsersCount(),
        totalUsers: (db.queryOne('SELECT COUNT(*) as c FROM users') || {}).c || 0,
        pendingPaymentsCount: pendingPayments.length,
        openTicketsCount: openTickets.length
      };

      res.write(`event: admin_snapshot\ndata: ${JSON.stringify({ stats, pendingPayments, openTickets, recentTrades })}\n\n`);
    } catch (err) {
      console.warn('[RealtimeStream] Error sending admin snapshot:', err.message);
    }

    req.on('close', () => {
      adminConnections.delete(res);
    });
  });

  return router;
}
