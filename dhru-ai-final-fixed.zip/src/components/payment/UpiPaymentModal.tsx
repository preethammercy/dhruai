import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, QrCode, Copy, Check, Clock, ShieldCheck, Sparkles, 
  ArrowRight, ExternalLink, AlertCircle, CheckCircle2, 
  Zap, Lock, Wallet, CreditCard, History, RefreshCw, XCircle, Gift
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { useAuth } from '../../context/AuthContext';
import { dispatchTradeNotification } from '../common/TradeNotificationToast';
import {
  PaymentRecord,
  submitPaymentRecord,
  subscribeToUserPayments,
  validateUtrFormat
} from '../../services/paymentService';

const TARGET_UPI_VPA = 'preethamrishu@axl';
const PAYEE_NAME = 'DHRU AI Quantitative Markets';

interface CreditPack {
  credits: number;
  price: number;
  label: string;
  badge?: string;
  popular?: boolean;
  unlocksPremium?: boolean;
}

const CREDIT_PACKS: CreditPack[] = [
  {
    credits: 200,
    price: 99,
    label: 'Starter Pack',
    badge: 'Beginner Essential'
  },
  {
    credits: 500,
    price: 199,
    label: 'Trader Pack',
    badge: 'Most Popular',
    popular: true
  },
  {
    credits: 1200,
    price: 499,
    label: 'Pro Trader Pack',
    badge: 'UNLOCKED PREMIUM INDICATORS ✨',
    unlocksPremium: true
  },
  {
    credits: 2000,
    price: 899,
    label: 'Institutional Pack',
    badge: 'VIP Auto-Trade + All Indicators',
    unlocksPremium: true
  }
];

const FUND_AMOUNTS = [100, 500, 1000, 2500, 5000, 10000];

// Memoized 10-Minute Countdown Component - keeps ticking isolated from the main payment form
const PaymentWindowTimer: React.FC = React.memo(() => {
  const [seconds, setSeconds] = useState(600);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds(prev => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const isUrgent = seconds < 120;

  return (
    <div className={`flex items-center justify-between px-3.5 py-2 rounded-xl border font-mono text-xs ${
      isUrgent
        ? 'border-rose-500/40 bg-rose-500/10 text-rose-400' 
        : 'border-amber-500/40 bg-amber-500/10 text-amber-500 dark:text-amber-300'
    }`}>
      <div className="flex items-center gap-1.5">
        <Clock className="w-3.5 h-3.5 animate-spin" />
        <span className="font-bold text-[11px]">10-Min Payment Window:</span>
      </div>
      <span className="font-mono font-black text-xs">
        {Math.floor(seconds / 60)}:{(seconds % 60).toString().padStart(2, '0')}
      </span>
    </div>
  );
});

export const UpiPaymentModal: React.FC = () => {
  const { isUpiModalOpen, closeDepositModal, upiModalTab, updateWalletDirectly, wallet, refreshWallet } = useWallet();
  const { user } = useAuth();
  
  // Modal Mode: 'deposit' | 'history' | 'redeem'
  const [modalMode, setModalMode] = useState<'deposit' | 'history' | 'redeem'>('deposit');
  const [activeTab, setActiveTab] = useState<'credits' | 'funds'>('credits');
  
  // Selection
  const [selectedPack, setSelectedPack] = useState<CreditPack>(CREDIT_PACKS[1]);
  const [fundAmount, setFundAmount] = useState<number>(100);
  const [customAmount, setCustomAmount] = useState<string>('');

  // Step: 'select' | 'pay' | 'submitted' | 'success'
  const [step, setStep] = useState<'select' | 'pay' | 'submitted' | 'success'>('select');
  const [submittedUtr, setSubmittedUtr] = useState<string>('');
  
  // UPI Order Details
  const [orderId, setOrderId] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [verifying, setVerifying] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Redeem Promo State
  const [redeemInput, setRedeemInput] = useState<string>('');
  const [redeemBusy, setRedeemBusy] = useState<boolean>(false);
  const [redeemError, setRedeemError] = useState<string | null>(null);
  const [redeemSuccess, setRedeemSuccess] = useState<string | null>(null);

  const handleClaimPromoInModal = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = redeemInput.trim().toUpperCase();
    if (!cleanCode) {
      setRedeemError('Please enter a redeem code.');
      return;
    }
    setRedeemBusy(true);
    setRedeemError(null);
    setRedeemSuccess(null);

    try {
      const res = await fetch('/api/promos/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: user?.uid || 'active-trader',
          code: cleanCode
        })
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok && (data.ok || data.success)) {
        const creditsAdded = data.creditsGiven || data.credits || 0;
        setRedeemSuccess(`Code ${cleanCode} claimed! +${creditsAdded} AI Credits added to your account.`);
        setRedeemInput('');
        await refreshWallet();
        dispatchTradeNotification({
          type: 'PROFIT',
          title: 'AI Credits Claimed!',
          symbol: 'PROMO',
          status: 'CLAIMED',
          reason: `Code ${cleanCode} credited +${creditsAdded} AI Credits to your account.`
        });
      } else {
        setRedeemError(data.error || 'Failed to claim code. Please check and try again.');
      }
    } catch (err: any) {
      setRedeemError(err.message || 'Connection error claiming code.');
    } finally {
      setRedeemBusy(false);
    }
  };

  // User Payment History State
  const [userPayments, setUserPayments] = useState<PaymentRecord[]>([]);

  useEffect(() => {
    setActiveTab(upiModalTab);
    setStep('select');
    setErrorMsg(null);
  }, [upiModalTab, isUpiModalOpen]);

  // Subscribe to User Payments with identity deduplication
  useEffect(() => {
    if (user?.uid) {
      const unsubscribe = subscribeToUserPayments(user.uid, (payments) => {
        setUserPayments(prev => {
          const oldD = prev.map(p => `${p.id}:${p.status}`).join(',');
          const newD = payments.map(p => `${p.id}:${p.status}`).join(',');
          return oldD === newD ? prev : payments;
        });
      });
      return () => unsubscribe();
    }
  }, [user?.uid]);

  const currentPayAmount = activeTab === 'credits' 
    ? selectedPack.price 
    : (customAmount ? Number(customAmount) : fundAmount);

  // Generate UPI QR Code URL (memoized to prevent re-requesting or re-rendering on typing)
  const txnNote = useMemo(() => {
    return activeTab === 'credits' 
      ? `DHRU AI ${selectedPack.credits} Credits (${orderId})` 
      : `DHRU Trading Fund Deposit (${orderId})`;
  }, [activeTab, selectedPack.credits, orderId]);

  const qrCodeUrl = useMemo(() => {
    const upiIntentUri = `upi://pay?pa=${encodeURIComponent(TARGET_UPI_VPA)}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${currentPayAmount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiIntentUri)}`;
  }, [currentPayAmount, txnNote]);

  if (!isUpiModalOpen) return null;

  const handleCopyVpa = () => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(TARGET_UPI_VPA);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleProceedToPayment = () => {
    if (activeTab === 'funds' && currentPayAmount < 100) {
      setErrorMsg('Minimum deposit amount is ₹100.');
      return;
    }
    const newOrderId = `DHRU-UPI-${Date.now().toString(36).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderId(newOrderId);
    setUtrNumber('');
    setErrorMsg(null);
    setStep('pay');
  };

  const handleUtrSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const { valid, cleanUtr, error: formatErr } = validateUtrFormat(utrNumber);
    if (!valid) {
      setErrorMsg(formatErr || 'Please enter a valid 12-digit UPI UTR or Transaction Reference number.');
      return;
    }

    setVerifying(true);
    try {
      // Submit via Centralized Payment Service (writes to Firestore 'payments' & checks duplicates)
      const record = await submitPaymentRecord({
        uid: user?.uid || 'trader',
        userEmail: user?.email || '',
        userName: user?.displayName || 'Trader',
        userPhone: user?.phone || '',
        amount: currentPayAmount,
        utr: cleanUtr,
        type: activeTab,
        credits: activeTab === 'credits' ? selectedPack.credits : 0,
        orderId
      });

      // Dispatch visual notification
      dispatchTradeNotification({
        type: 'OPEN',
        title: 'Payment Submitted for Verification',
        symbol: activeTab === 'credits' ? 'CREDITS' : 'FUNDS',
        status: 'PENDING',
        reason: `₹${currentPayAmount.toLocaleString('en-IN')} (UTR: ${cleanUtr}) submitted. Awaiting Admin verification.`
      });

      setSubmittedUtr(cleanUtr);
      setStep('submitted');
    } catch (err: any) {
      setErrorMsg(err.message || 'Payment submission failed. Please check connection and try again.');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl border border-line bg-surface shadow-2xl overflow-hidden my-auto"
        style={{ background: 'var(--surface-solid)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-tint text-brand">
              <Zap className="h-4.5 w-4.5 text-amber-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-ink">
                {modalMode === 'history' ? 'My Payment History' : (step === 'success' ? 'Payment Verified!' : 'DHRU Official UPI Gateway')}
              </h2>
              <p className="text-[11px] text-ink-2">
                {modalMode === 'history' ? 'Real-time approval status from Admin Desk' : 'Direct UPI Payment to Verified Merchant'}
              </p>
            </div>
          </div>
          <button
            onClick={closeDepositModal}
            className="rounded-full p-1.5 text-ink-2 hover:bg-surface-2 hover:text-ink cursor-pointer transition-all"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Top Navigation Mode: Deposit vs Redeem Code vs Payment History */}
        <div className="px-5 pt-3 shrink-0">
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-surface-2 border border-line text-xs font-bold font-mono">
            <button
              onClick={() => setModalMode('deposit')}
              className={`py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                modalMode === 'deposit'
                  ? 'bg-brand-fill text-on-brand shadow-sm'
                  : 'text-ink-2 hover:text-ink'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Deposit</span>
            </button>

            <button
              onClick={() => setModalMode('redeem')}
              className={`py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                modalMode === 'redeem'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-ink-2 hover:text-ink'
              }`}
            >
              <Gift className="w-3.5 h-3.5 text-amber-400" />
              <span>Redeem Code</span>
            </button>

            <button
              onClick={() => setModalMode('history')}
              className={`py-1.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                modalMode === 'history'
                  ? 'bg-brand-fill text-on-brand shadow-sm'
                  : 'text-ink-2 hover:text-ink'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>History ({userPayments.length})</span>
            </button>
          </div>
        </div>

        {/* Scrollable Modal Body */}
        <div className="flex-1 overflow-y-auto px-5 py-3.5 space-y-3.5">
        {/* ======================================================== */}
        {/* VIEW 1: PAYMENT HISTORY WITH LIVE STATUS                */}
        {/* ======================================================== */}
        {modalMode === 'history' ? (
          <div className="space-y-4">
            <div className="text-xs text-ink-3 font-mono flex items-center justify-between">
              <span>Showing submissions for UID: <strong className="text-purple-400">{user?.uid || 'Guest'}</strong></span>
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Sync Active
              </span>
            </div>

            {userPayments.length === 0 ? (
              <div className="p-8 text-center space-y-2 rounded-2xl border border-line bg-surface-2">
                <Clock className="w-8 h-8 text-ink-3 mx-auto" />
                <div className="text-sm font-bold text-ink">No Payment Submissions Yet</div>
                <p className="text-xs text-ink-3">
                  When you make a payment and submit your UTR, it will appear here with live updates.
                </p>
                <button
                  onClick={() => setModalMode('deposit')}
                  className="mt-2 px-4 py-1.5 rounded-xl bg-purple-600 text-white font-mono text-xs font-bold cursor-pointer"
                >
                  Make a Deposit
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                {userPayments.map(p => {
                  const status = (p.status || '').toLowerCase();
                  const isPending = status === 'pending';
                  const isApproved = status === 'approved' || (p as any).status === 'VERIFIED';
                  const isRejected = status === 'rejected' || (p as any).status === 'REJECTED';

                  return (
                    <div
                      key={p.id}
                      className="p-3.5 rounded-2xl border border-line bg-surface-2 space-y-2 text-xs font-mono"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-ink text-sm">
                          ₹{Number(p.amount).toLocaleString('en-IN')}
                          <span className="text-[11px] text-ink-3 font-normal ml-2">
                            ({p.type === 'credits' ? `${p.credits || p.amount} Credits` : 'Trading Funds'})
                          </span>
                        </div>

                        {/* Status Badge */}
                        {isPending && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-500 border border-amber-500/30 flex items-center gap-1">
                            <Clock className="w-3 h-3 animate-spin" />
                            Pending Admin Review
                          </span>
                        )}
                        {isApproved && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            Approved & Credited
                          </span>
                        )}
                        {isRejected && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                            <XCircle className="w-3 h-3" />
                            Rejected
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-ink-3">
                        <span>UTR: <strong className="text-ink">{p.utr}</strong></span>
                        <span>{p.createdAt ? new Date(p.createdAt).toLocaleDateString() : 'Recent'}</span>
                      </div>

                      {p.adminNote && (
                        <div className={`p-2 rounded-xl text-[11px] border ${
                          isRejected
                            ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                            : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        }`}>
                          <strong>Admin Note:</strong> {p.adminNote}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : modalMode === 'redeem' ? (
          /* ======================================================== */
          /* VIEW 2: REDEEM PROMO / GIFT CODE                         */
          /* ======================================================== */
          <div className="space-y-4 py-2">
            <div className="p-6 rounded-3xl border border-purple-500/30 bg-purple-500/10 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mx-auto">
                <Gift className="w-7 h-7 text-amber-400" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-ink">Redeem Unique AI Credits Code</h3>
                <p className="text-xs text-ink-2 max-w-sm mx-auto">
                  Enter your unique code generated by Admin to instantly receive AI Quantitative Credits into your account.
                </p>
              </div>

              <form onSubmit={handleClaimPromoInModal} className="space-y-3 max-w-md mx-auto pt-2">
                <input
                  type="text"
                  value={redeemInput}
                  onChange={e => {
                    setRedeemInput(e.target.value.toUpperCase());
                    setRedeemError(null);
                  }}
                  placeholder="Enter code (e.g. DHRU-XXXXXX)"
                  className="w-full px-4 py-3 rounded-xl border border-line bg-surface text-ink text-sm font-mono font-bold uppercase tracking-wider text-center outline-none focus:border-purple-500"
                />

                {redeemError && (
                  <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400 text-xs font-mono">
                    {redeemError}
                  </div>
                )}

                {redeemSuccess && (
                  <div className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-mono flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{redeemSuccess}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={redeemBusy || !redeemInput.trim()}
                  className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase tracking-wider shadow-md active:scale-98 transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Gift className="w-4 h-4" />
                  <span>{redeemBusy ? 'Claiming Credits...' : 'Claim AI Credits'}</span>
                </button>
              </form>
            </div>

            <div className="p-4 rounded-2xl border border-line bg-surface-2 text-xs text-ink-3 space-y-1.5 font-mono">
              <div className="font-bold text-ink flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>How Redeem Codes Work</span>
              </div>
              <p>• Promotional codes are generated by Admin for community rewards & special giveaways.</p>
              <p>• Each code credits free AI Intelligence credits instantly upon redemption.</p>
              <p>• Current account balance: <strong className="text-amber-400">{wallet.credits} Credits</strong></p>
            </div>
          </div>
        ) : (
          /* ======================================================== */
          /* VIEW 3: DEPOSIT & PAYMENT SUBMISSION FLOW               */
          /* ======================================================== */
          <>
            {/* STEP 1: SELECT CREDITS OR FUNDS */}
            {step === 'select' && (
              <div className="space-y-5">
                {/* Tab Switcher */}
                <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-surface-2 border border-line text-xs font-bold font-mono">
                  <button
                    onClick={() => setActiveTab('credits')}
                    className={`py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      activeTab === 'credits'
                        ? 'bg-brand-fill text-on-brand shadow-sm'
                        : 'text-ink-2 hover:text-ink'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Buy AI Credits</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('funds')}
                    className={`py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      activeTab === 'funds'
                        ? 'bg-brand-fill text-on-brand shadow-sm'
                        : 'text-ink-2 hover:text-ink'
                    }`}
                  >
                    <Wallet className="w-3.5 h-3.5" />
                    <span>Add Real Trading Funds</span>
                  </button>
                </div>

                {/* Current Balance Ribbon */}
                <div className="flex items-center justify-between px-4 py-2.5 rounded-xl bg-surface-2 border border-line text-xs">
                  <span className="text-ink-2">Current Active Balances:</span>
                  <div className="flex items-center gap-3 font-mono font-bold">
                    <span className="text-amber-400">⚡ {wallet.credits} Credits</span>
                    <span className="text-emerald-400">₹{wallet.tradingBalance.toLocaleString('en-IN')} Cash</span>
                  </div>
                </div>

                {/* Credits Option List */}
                {activeTab === 'credits' && (
                  <div className="space-y-3">
                    <p className="text-xs text-ink-2">
                      Credits power DHRU AI market reports (5 credits) and automated trading execution (10 credits).
                    </p>
                    <div className="space-y-2.5">
                      {CREDIT_PACKS.map(pack => (
                        <div
                          key={pack.credits}
                          onClick={() => setSelectedPack(pack)}
                          className={`relative flex items-center justify-between p-3.5 rounded-2xl border cursor-pointer transition-all ${
                            selectedPack.credits === pack.credits
                              ? 'border-brand bg-brand-tint/20 ring-2 ring-brand/30 shadow-md'
                              : 'border-line bg-surface hover:bg-surface-2'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-ink">{pack.credits} Credits</span>
                              {pack.badge && (
                                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                                  pack.popular ? 'bg-amber-400/20 text-amber-500 border border-amber-400/30' : 'bg-surface-2 text-ink-2'
                                }`}>
                                  {pack.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-ink-2">{pack.label}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-base font-black text-ink font-mono">₹{pack.price}</span>
                            <span className="block text-[10px] text-ink-2">incl. GST</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Real Funds Option */}
                {activeTab === 'funds' && (
                  <div className="space-y-4">
                    <p className="text-xs text-ink-2">
                      Deposit Indian Rupee trading capital directly into your wallet. Minimum deposit is ₹100.
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      {FUND_AMOUNTS.map(amt => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => { setFundAmount(amt); setCustomAmount(''); }}
                          className={`py-2.5 rounded-xl border text-xs font-mono font-bold cursor-pointer transition-all ${
                            fundAmount === amt && !customAmount
                              ? 'border-brand bg-brand-tint text-brand ring-2 ring-brand/20'
                              : 'border-line bg-surface hover:bg-surface-2 text-ink'
                          }`}
                        >
                          ₹{amt.toLocaleString('en-IN')}
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-semibold text-ink-2 mb-1">
                        Or Enter Custom Amount (₹)
                      </label>
                      <input
                        type="number"
                        min="100"
                        step="10"
                        placeholder="e.g. 5000 (Min ₹100)"
                        value={customAmount}
                        onChange={e => setCustomAmount(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface text-ink text-xs font-mono outline-none focus:border-brand"
                      />
                    </div>
                  </div>
                )}

                {errorMsg && (
                  <div role="alert" className="p-3 rounded-xl border border-rose-500/40 bg-rose-500/10 text-xs text-rose-400 font-mono flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <button
                  onClick={handleProceedToPayment}
                  className="w-full py-3.5 rounded-2xl bg-brand-fill hover:opacity-90 text-on-brand font-bold text-xs uppercase font-mono tracking-wider shadow-md active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Pay ₹{currentPayAmount.toLocaleString('en-IN')} via UPI</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* STEP 2: SCAN & PAY VIA UPI QR (Compact Responsive 2-Col Grid) */}
            {step === 'pay' && (
              <div className="space-y-3">
                {/* 10-Minute Countdown Banner (Isolated to prevent re-render jitter) */}
                <PaymentWindowTimer />

                {/* Side-by-Side on Desktop/PC, Stacked on Mobile */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 items-start">
                  {/* LEFT: QR Code + Pay Amount + VPA Copy */}
                  <div className="flex flex-col items-center justify-center p-3 rounded-2xl border border-line bg-surface-2 space-y-2">
                    <div className="bg-white p-2 rounded-xl shadow-xs border border-neutral-200">
                      <img 
                        src={qrCodeUrl} 
                        alt="UPI Payment QR Code" 
                        className="w-28 h-28 sm:w-32 sm:h-32 object-contain rounded-md"
                      />
                    </div>
                    <div className="text-center w-full">
                      <span className="text-[10px] font-mono text-ink-3 block">Scan with GPay, PhonePe, Paytm, BHIM</span>
                      <div className="text-sm sm:text-base font-black text-ink font-mono">
                        Pay: ₹{currentPayAmount.toLocaleString('en-IN')}
                      </div>
                    </div>

                    {/* Compact Merchant UPI ID Copy Block */}
                    <div className="w-full flex items-center justify-between bg-surface px-2.5 py-1.5 rounded-xl border border-line text-[11px] font-mono">
                      <span className="font-bold text-ink truncate select-all">{TARGET_UPI_VPA}</span>
                      <button
                        type="button"
                        onClick={handleCopyVpa}
                        className="text-brand hover:underline font-bold flex items-center gap-1 ml-1 cursor-pointer shrink-0"
                      >
                        {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span className="text-[10px]">{copied ? 'Copied' : 'Copy VPA'}</span>
                      </button>
                    </div>
                  </div>

                  {/* RIGHT: UTR Input Form & Instant Submit Action */}
                  <form onSubmit={handleUtrSubmit} className="space-y-3 p-3.5 rounded-2xl border border-line bg-surface flex flex-col justify-between h-full">
                    <div className="space-y-2.5">
                      <div>
                        <label className="block text-xs font-mono font-bold text-ink mb-1 flex items-center justify-between">
                          <span>UPI UTR / Reference No. *</span>
                          <span className="text-[10px] text-amber-500 font-normal">12 Digits</span>
                        </label>
                        <input
                          type="text"
                          maxLength={30}
                          value={utrNumber}
                          onChange={e => setUtrNumber(e.target.value.replace(/[^a-zA-Z0-9]/g, ''))}
                          placeholder="e.g. 512345678901 (from UPI receipt)"
                          required
                          autoFocus
                          className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs font-mono outline-none focus:border-brand font-bold"
                        />
                      </div>

                      <div className="p-2 rounded-xl bg-surface-2 border border-line text-[10px] text-ink-3 font-mono space-y-0.5">
                        <div className="flex items-center gap-1 text-emerald-400 font-bold">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Direct Admin Verification</span>
                        </div>
                        <p>After paying, enter your receipt UTR and submit for instant verification.</p>
                      </div>

                      {errorMsg && (
                        <div role="alert" className="p-2.5 rounded-xl border border-rose-500/40 bg-rose-500/10 text-[11px] text-rose-400 font-mono flex items-center gap-2">
                          <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                          <span>{errorMsg}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setStep('select')}
                        className="py-2.5 px-3 rounded-xl border border-line text-ink-2 hover:text-ink text-xs font-mono font-bold cursor-pointer transition-all"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        disabled={verifying}
                        className="flex-1 py-2.5 px-3 rounded-xl bg-brand-fill hover:opacity-90 text-on-brand font-bold text-xs uppercase font-mono tracking-wider shadow-md active:scale-98 transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{verifying ? 'Submitting...' : 'Submit UTR to Admin'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* STEP 3: SUBMITTED - WAITING FOR ADMIN APPROVAL */}
            {step === 'submitted' && (
              <div className="space-y-5 text-center py-4">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/30">
                  <Clock className="h-7 w-7 animate-spin text-amber-500" />
                </div>

                <div className="space-y-1.5">
                  <h3 className="text-base font-bold text-ink">UTR Sent to Admin Desk</h3>
                  <p className="text-xs text-ink-2 max-w-sm mx-auto">
                    Your payment of <strong>₹{currentPayAmount.toLocaleString('en-IN')}</strong> with UTR reference <strong>{submittedUtr}</strong> is queued in the Admin Operations Desk.
                  </p>
                </div>

                <div className="p-4 rounded-2xl border border-line bg-surface-2 text-xs font-mono space-y-2 text-left">
                  <div className="flex justify-between text-ink-2">
                    <span>Order Reference:</span>
                    <span className="font-bold text-ink">{orderId}</span>
                  </div>
                  <div className="flex justify-between text-ink-2">
                    <span>User UID:</span>
                    <span className="font-bold text-purple-400">{user?.uid || 'Guest'}</span>
                  </div>
                  <div className="flex justify-between text-ink-2">
                    <span>Submitted At:</span>
                    <span className="font-bold text-ink">{new Date().toLocaleTimeString()}</span>
                  </div>
                  <div className="flex justify-between text-ink-2">
                    <span>Status:</span>
                    <span className="font-bold text-amber-500 flex items-center gap-1">
                      <Clock className="w-3 h-3 animate-spin" />
                      Awaiting Admin Approval
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setModalMode('history')}
                    className="flex-1 py-3 rounded-xl border border-line bg-surface-2 hover:bg-surface text-ink text-xs font-mono font-bold cursor-pointer"
                  >
                    View in Payment History
                  </button>
                  <button
                    onClick={closeDepositModal}
                    className="flex-1 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </>
        )}
        </div>
      </motion.div>
    </div>
  );
};
