// DHRU.AI - Animated Quick Guide & Onboarding Tour Modal
// Full motioned walkthrough for first-time registered users with interactive slides,
// feature showcases, and a one-click skip option.

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Zap,
  Wallet,
  Coins,
  Bot,
  ArrowRight,
  ArrowLeft,
  X,
  CheckCircle2,
  Lock,
  Layers,
  Smartphone,
  MessageSquare,
  Gift,
  Activity,
  Check
} from 'lucide-react';
import { DhruLogo } from './DhruLogo';

interface QuickGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  uid?: string;
  userName?: string;
}

interface TourStep {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  gradient: string;
  accentColor: string;
  content: React.ReactNode;
}

export const QuickGuideModal: React.FC<QuickGuideModalProps> = ({
  isOpen,
  onClose,
  uid,
  userName = 'Trader'
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(1);

  // Keyboard navigation (Escape to skip, Left/Right arrows to navigate)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleSkip();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentStep]);

  const handleSkip = () => {
    if (uid) {
      try {
        localStorage.setItem(`dhru_onboarding_completed_${uid}`, 'true');
        fetch('/api/user/complete-onboarding', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uid })
        }).catch(() => {});
      } catch {}
    }
    onClose();
  };

  const handleFinish = () => {
    handleSkip();
  };

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setDirection(1);
      setCurrentStep(prev => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setDirection(-1);
      setCurrentStep(prev => prev - 1);
    }
  };

  const tourSteps: TourStep[] = [
    {
      id: 'welcome',
      badge: 'Welcome to DHRU.AI',
      title: `Welcome, ${userName}!`,
      subtitle: 'Your institutional AI intelligence platform for Indian (NSE/BSE) & Global Crypto Markets.',
      icon: Sparkles,
      gradient: 'from-blue-600 to-indigo-600',
      accentColor: 'text-blue-500',
      content: (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-ink space-y-2">
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-sm">
              <Activity className="w-4 h-4 animate-pulse" />
              <span>Zero Synthetic or Mock Data</span>
            </div>
            <p className="text-xs text-ink-2 leading-relaxed">
              Every quote, order book depth, and technical calculation is powered by verified live market feeds and smart money quantitative engines.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-2xl bg-surface-2 border border-line text-left">
              <div className="text-[11px] font-mono font-bold text-ink-2 uppercase">Coverage</div>
              <div className="text-sm font-bold text-ink mt-0.5">NSE, BSE & Crypto</div>
              <div className="text-[11px] text-ink-2 mt-1">NIFTY 50, BANKNIFTY, Top 500 Equities & BTC</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-surface-2 border border-line text-left">
              <div className="text-[11px] font-mono font-bold text-ink-2 uppercase">Execution</div>
              <div className="text-sm font-bold text-ink mt-0.5">Sub-Second Latency</div>
              <div className="text-[11px] text-ink-2 mt-1">Real-time SSE event streaming directly to your screen</div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'wallets',
      badge: 'Paper vs Live Capital',
      title: 'Demo & Real Accounts',
      subtitle: 'Segregated accounts ensure you test strategies safely before trading with real funds.',
      icon: Wallet,
      gradient: 'from-amber-500 to-orange-600',
      accentColor: 'text-amber-500',
      content: (
        <div className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            {/* Demo Card */}
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-left relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-amber-500 text-white">
                  DEMO (Free)
                </span>
                <Coins className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-lg font-black text-ink mt-2">100 Credits</div>
              <p className="text-[11px] text-ink-2 mt-1 leading-snug">
                Starter pack credited upon registration. Reset back to 100 anytime via header.
              </p>
            </div>

            {/* Real Card */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-left relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-600 text-white">
                  REAL ACCOUNT
                </span>
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-lg font-black text-ink mt-2">₹0.00 Balance</div>
              <p className="text-[11px] text-ink-2 mt-1 leading-snug">
                Funded via instant UPI deposit approvals or verified promo vouchers.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-surface-2 border border-line text-xs text-ink-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
            <span>Switch effortlessly between Demo and Real accounts in the top navigation bar.</span>
          </div>
        </div>
      )
    },
    {
      id: 'intelligence',
      badge: 'Quantitative Engine',
      title: 'Institutional Intelligence & SMC',
      subtitle: 'Mathematical precision with Smart Money Concepts (BOS, Order Blocks, and Fair Value Gaps).',
      icon: TrendingUp,
      gradient: 'from-emerald-500 to-teal-600',
      accentColor: 'text-emerald-500',
      content: (
        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-surface-2 border border-line space-y-2 text-left">
            <div className="text-xs font-bold text-ink flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Multi-Timeframe Confluence (5m, 15m, 1h, Daily)</span>
            </div>
            <p className="text-[11px] text-ink-2">
              Evaluates EMA 9/21/50, RSI 14, MACD, Volume Profile, and Floor Pivot Points (R1–R3, S1–S3) to generate high-probability trade setups.
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-surface-2 border border-line space-y-2 text-left">
            <div className="text-xs font-bold text-ink flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Smart Money Concepts (SMC)</span>
            </div>
            <p className="text-[11px] text-ink-2">
              Automatically flags institutional accumulation zones (Order Blocks), structural breaks (BOS), and liquidity imbalances (FVG).
            </p>
          </div>
        </div>
      )
    },
    {
      id: 'autotrade',
      badge: 'Hands-Free Execution',
      title: 'Autonomous Auto-Trade Bots',
      subtitle: 'Set-and-forget algorithmic execution with institutional risk management.',
      icon: Bot,
      gradient: 'from-purple-600 to-pink-600',
      accentColor: 'text-purple-500',
      content: (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 rounded-xl bg-surface-2 border border-line">
              <div className="text-[10px] font-mono text-ink-2 uppercase">Target 1</div>
              <div className="text-xs font-black text-ink mt-1">TP1 & Break-Even</div>
              <div className="text-[10px] text-emerald-500 mt-0.5">Locks 0 Risk</div>
            </div>
            <div className="p-3 rounded-xl bg-surface-2 border border-line">
              <div className="text-[10px] font-mono text-ink-2 uppercase">Target 2</div>
              <div className="text-xs font-black text-ink mt-1">TP2 Profit Lock</div>
              <div className="text-[10px] text-blue-500 mt-0.5">Ratchets Stop</div>
            </div>
            <div className="p-3 rounded-xl bg-surface-2 border border-line">
              <div className="text-[10px] font-mono text-ink-2 uppercase">Runner</div>
              <div className="text-xs font-black text-ink mt-1">TP3 Runner</div>
              <div className="text-[10px] text-purple-500 mt-0.5">Trails Trend</div>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-surface-2 border border-line text-left text-xs text-ink-2 space-y-1">
            <div className="font-bold text-ink flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              <span>Offline Server Execution</span>
            </div>
            <p className="text-[11px]">
              Armed auto-trade bots run continuously on the server backend even when your device is asleep or browser is closed.
            </p>
          </div>
        </div>
      )
    },
    {
      id: 'payments',
      badge: 'Instant Deposits',
      title: 'UPI Deposits & Live UTR Approvals',
      subtitle: 'Deposit seamlessly via Google Pay, PhonePe, Paytm, or BHIM with atomic verification.',
      icon: Smartphone,
      gradient: 'from-cyan-600 to-blue-600',
      accentColor: 'text-cyan-500',
      content: (
        <div className="space-y-3.5">
          <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-left space-y-2">
            <div className="flex items-center gap-2 text-cyan-600 dark:text-cyan-400 font-bold text-sm">
              <Zap className="w-4 h-4" />
              <span>How Deposits Work</span>
            </div>
            <ol className="text-xs text-ink-2 space-y-1.5 list-decimal list-inside leading-relaxed">
              <li>Scan the UPI QR code or copy the target VPA in the Deposit Modal.</li>
              <li>Complete the payment in your banking or UPI app.</li>
              <li>Paste your 12-digit UPI UTR / Transaction Reference number.</li>
              <li>Admin verifies the UTR and atomically credits your Real balance.</li>
            </ol>
          </div>

          <div className="p-3 rounded-xl bg-surface-2 border border-line text-[11px] text-ink-2 flex items-center justify-between">
            <span className="flex items-center gap-2 font-mono">
              <Lock className="w-3.5 h-3.5 text-emerald-500" />
              <span>Strict UTR Uniqueness & Audit Trail</span>
            </span>
            <span className="text-emerald-500 font-bold">100% Secure</span>
          </div>
        </div>
      )
    },
    {
      id: 'support_promos',
      badge: 'Ready to Launch',
      title: 'Support Desk & Promo Vouchers',
      subtitle: 'You are all set! Have questions or need assistance? Our team is always here.',
      icon: Gift,
      gradient: 'from-rose-500 to-pink-600',
      accentColor: 'text-rose-500',
      content: (
        <div className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-surface-2 border border-line text-left">
              <div className="flex items-center gap-2 text-rose-500 font-bold text-xs">
                <Gift className="w-4 h-4" />
                <span>Promo Codes</span>
              </div>
              <p className="text-[11px] text-ink-2 mt-1">
                Got a promotional voucher? Redeem it in your Profile to claim instant REAL trading credits.
              </p>
            </div>
            <div className="p-3.5 rounded-2xl bg-surface-2 border border-line text-left">
              <div className="flex items-center gap-2 text-blue-500 font-bold text-xs">
                <MessageSquare className="w-4 h-4" />
                <span>Live Chat Support</span>
              </div>
              <p className="text-[11px] text-ink-2 mt-1">
                Access 24/7 dedicated support directly from your Profile page or the bottom help icon.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center">
            <div className="text-sm font-black text-emerald-600 dark:text-emerald-400">
              🎉 100 Demo Credits Ready in Your Wallet!
            </div>
            <div className="text-xs text-ink-2 mt-1">
              Explore live charts, run walk-forward backtests, and start paper trading today.
            </div>
          </div>
        </div>
      )
    }
  ];

  const current = tourSteps[currentStep];
  const StepIcon = current.icon;
  const isLast = currentStep === tourSteps.length - 1;

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleSkip}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-lg bg-surface border border-line shadow-2xl rounded-3xl overflow-hidden z-10 flex flex-col max-h-[92vh]"
        >
          {/* Top Header Strip with Skip button */}
          <div className="px-6 pt-5 pb-3 flex items-center justify-between border-b border-line/60">
            <div className="flex items-center gap-2.5">
              <DhruLogo size={28} />
              <span className="font-mono text-xs font-bold tracking-wider text-ink-2 uppercase">
                Quick Guide • Step {currentStep + 1} of {tourSteps.length}
              </span>
            </div>

            <button
              type="button"
              onClick={handleSkip}
              className="text-xs font-mono font-bold text-ink-2 hover:text-ink px-2.5 py-1 rounded-lg hover:bg-surface-2 transition-all flex items-center gap-1 cursor-pointer"
              title="Skip this guide"
            >
              <span>Skip</span>
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Animated Step Content with Directional Slide */}
          <div className="p-6 overflow-y-auto flex-1">
            <AnimatePresence custom={direction} mode="wait">
              <motion.div
                key={current.id}
                custom={direction}
                initial={{ opacity: 0, x: direction * 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: direction * -40 }}
                transition={{ duration: 0.25, ease: 'easeInOut' }}
                className="space-y-4 text-center"
              >
                {/* Floating Icon with Gradient Glow */}
                <div className="relative mx-auto w-16 h-16 flex items-center justify-center">
                  <div className={`absolute inset-0 rounded-2xl bg-gradient-to-tr ${current.gradient} opacity-20 blur-xl animate-pulse`} />
                  <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-tr ${current.gradient} flex items-center justify-center shadow-lg text-white`}>
                    <StepIcon className="w-8 h-8" />
                  </div>
                </div>

                {/* Badge & Headings */}
                <div className="space-y-1.5">
                  <span className={`inline-block px-3 py-1 rounded-full text-[11px] font-mono font-black uppercase tracking-wider bg-surface-2 border border-line ${current.accentColor}`}>
                    {current.badge}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-ink tracking-tight">
                    {current.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-ink-2 max-w-md mx-auto leading-relaxed">
                    {current.subtitle}
                  </p>
                </div>

                {/* Custom Step Content */}
                <div className="pt-2">
                  {current.content}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Bottom Controls & Progress Dots */}
          <div className="px-6 py-4 bg-surface-2/60 border-t border-line/60 flex items-center justify-between gap-3">
            {/* Step Indicators */}
            <div className="flex items-center gap-1.5">
              {tourSteps.map((step, idx) => (
                <button
                  key={step.id}
                  type="button"
                  onClick={() => {
                    setDirection(idx > currentStep ? 1 : -1);
                    setCurrentStep(idx);
                  }}
                  className={`h-2 rounded-full transition-all cursor-pointer ${
                    idx === currentStep
                      ? 'w-6 bg-blue-600'
                      : 'w-2 bg-line hover:bg-ink-2/40'
                  }`}
                  title={`Go to step ${idx + 1}`}
                />
              ))}
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center gap-2">
              {currentStep > 0 && (
                <button
                  type="button"
                  onClick={handlePrev}
                  className="px-3.5 py-2 rounded-xl border border-line bg-surface hover:bg-surface-2 text-xs font-bold text-ink transition-all flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleNext}
                className={`px-5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md ${
                  isLast
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-500/20'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                }`}
              >
                <span>{isLast ? 'Start Trading Now' : 'Next'}</span>
                {isLast ? <Check className="w-4 h-4" /> : <ArrowRight className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
