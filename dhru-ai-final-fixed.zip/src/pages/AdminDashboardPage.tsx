// DHRU.AI - Dhruti Super Admin Operations & Control Center (/dhruti)
// Strictly: Platform Analytics, Payment Approvals (UTR Desk), and User Management with UID isolation.
// Secure JWT authentication with rate-limited backend verification.

import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Wallet,
  Zap,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Search,
  AlertTriangle,
  User,
  Copy,
  Mail,
  Lock,
  LogOut,
  Ban,
  Check,
  Phone,
  Eye,
  Sliders,
  X,
  CreditCard,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  UserCheck,
  Gift,
  Plus,
  Trash2,
  Tag,
  Radio,
  Megaphone,
  Image as ImageIcon,
  Send
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useWallet } from '../context/WalletContext';
import { dispatchTradeNotification } from '../components/common/TradeNotificationToast';
import {
  PaymentRecord,
  subscribeToAllPayments,
  approvePaymentOrder,
  rejectPaymentOrder
} from '../services/paymentService';

interface AdminAnalytics {
  totalUsers: number;
  totalTradingFunds: number;
  totalCreditsOutstanding: number;
  totalRevenueInr: number;
  pendingRevenueInr?: number;
  totalOrdersCount: number;
  verifiedOrdersCount: number;
  pendingOrdersCount: number;
  rejectedOrdersCount?: number;
  targetVpa: string;
  payeeName: string;
  systemStatus: string;
}

interface RegisteredUser {
  userId?: string;
  uid?: string;
  displayName?: string;
  email?: string;
  phone?: string;
  tradingBalance?: number;
  credits?: number;
  suspended?: boolean;
  isBanned?: boolean;
  canTrade?: boolean;
  joinedAt?: string;
  lastActive?: string;
  role?: string;
  history?: any[];
}

export const AdminDashboardPage: React.FC<{ onNavigate?: (page: string) => void }> = ({ onNavigate }) => {
  const { user, isAdmin, signInWithEmail, signOut } = useAuth();
  const { refreshWallet } = useWallet();

  // JWT Token from session storage
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('dhru_admin_jwt_token');
    }
    return null;
  });

  // Admin access requires a server-issued JWT (obtained from the gate login below).
  const isSuperAdmin = Boolean(adminToken);

  // Secret Gate Login State (password and email are never hardcoded or pre-filled)
  const [gateEmail, setGateEmail] = useState('');
  const [gatePass, setGatePass] = useState('');
  const [gateError, setGateError] = useState<string | null>(null);
  const [gateBusy, setGateBusy] = useState(false);

  // Admin Desk Tabs: Analytics, Payment Approvals, User Management, Redeem Codes Desk, and Broadcasts
  const [deskTab, setDeskTab] = useState<'analytics' | 'approvals' | 'users' | 'promos' | 'broadcasts'>('approvals');

  // Data State
  const [analytics, setAnalytics] = useState<AdminAnalytics | null>(null);
  const [paymentsList, setPaymentsList] = useState<PaymentRecord[]>([]);
  const [usersList, setUsersList] = useState<RegisteredUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [approvalFilter, setApprovalFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('PENDING');
  const [searchQuery, setSearchQuery] = useState('');
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string>(() => new Date().toLocaleTimeString());

  // Broadcasts & Posters Desk State
  interface AdminBroadcastItem {
    id: string | number;
    type?: string;
    title: string;
    body?: string;
    message?: string;
    imageUrl?: string;
    target?: string;
    createdAt?: string;
    seenCount?: number;
  }
  const [broadcastsList, setBroadcastsList] = useState<AdminBroadcastItem[]>([]);
  const [broadcastsLoading, setBroadcastsLoading] = useState(false);
  const [bcTitle, setBcTitle] = useState('');
  const [bcType, setBcType] = useState<'poster' | 'message' | 'alert' | 'promo'>('poster');
  const [bcMessage, setBcMessage] = useState('');
  const [bcImageUrl, setBcImageUrl] = useState('');
  const [bcTarget, setBcTarget] = useState<'all' | 'real' | 'demo'>('all');
  const [bcBusy, setBcBusy] = useState(false);
  const [bcSuccess, setBcSuccess] = useState<string | null>(null);
  const [bcError, setBcError] = useState<string | null>(null);

  // Promo Codes Desk State
  interface PromoCodeItem {
    id: string;
    code: string;
    credits: number;
    maxUses: number;
    usedCount: number;
    perUserLimit: number;
    expiresAt: string | null;
    active: number;
    createdBy: string;
    createdAt: string;
    note: string;
    totalRedemptions?: number;
    totalCreditsDistributed?: number;
  }
  const [promosList, setPromosList] = useState<PromoCodeItem[]>([]);
  const [promosLoading, setPromosLoading] = useState(false);
  const [promoModalOpen, setPromoModalOpen] = useState(false);
  const [newCodeName, setNewCodeName] = useState('');
  const [newCodeCredits, setNewCodeCredits] = useState<number>(250);
  const [newCodeMaxUses, setNewCodeMaxUses] = useState<number>(10);
  const [newCodeNote, setNewCodeNote] = useState('');
  const [newCodeBusy, setNewCodeBusy] = useState(false);
  const [newCodeError, setNewCodeError] = useState<string | null>(null);
  const [newCodeSuccess, setNewCodeSuccess] = useState<string | null>(null);

  const generateUniqueCode = () => {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let rand = '';
    for (let i = 0; i < 6; i++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewCodeName(`DHRU-${rand}`);
  };

  // User Details Modal State
  const [selectedUser, setSelectedUser] = useState<RegisteredUser | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(500);
  const [adjustType, setAdjustType] = useState<'funds' | 'credits'>('funds');
  const [adjustNote, setAdjustNote] = useState('Manual credit adjustment by Admin');
  const [adjustBusy, setAdjustBusy] = useState(false);

  const copyToClipboard = (text: string, id: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const getAuthHeaders = useCallback((): Record<string, string> => {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (adminToken) {
      headers['Authorization'] = `Bearer ${adminToken}`;
    }
    return headers;
  }, [adminToken]);

  // Token rejected by the server (expired / wrong secret) -> send the admin back to the gate
  const forceReLogin = useCallback(() => {
    sessionStorage.removeItem('dhru_admin_jwt_token');
    setAdminToken(null);
  }, []);

  // Fetch Promo Codes
  const fetchPromos = useCallback(async () => {
    if (!isSuperAdmin) return;
    try {
      setPromosLoading(true);
      const res = await fetch('/api/admin/promos', { headers: getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.promos)) {
          setPromosList(data.promos);
        } else if (Array.isArray(data.codes)) {
          setPromosList(data.codes);
        }
      }
    } catch (err) {
      console.warn('[Admin] Error loading promos:', err);
    } finally {
      setPromosLoading(false);
    }
  }, [isSuperAdmin, getAuthHeaders]);

  // Fetch Broadcasts & Posters
  const fetchBroadcasts = useCallback(async () => {
    if (!isSuperAdmin) return;
    try {
      setBroadcastsLoading(true);
      const res = await fetch('/api/broadcasts/admin/list', { headers: getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        if (data.ok && Array.isArray(data.broadcasts)) {
          setBroadcastsList(data.broadcasts);
        }
      }
    } catch (err) {
      console.warn('[Admin] Error loading broadcasts:', err);
    } finally {
      setBroadcastsLoading(false);
    }
  }, [isSuperAdmin, getAuthHeaders]);

  // Fetch Users, Payments, and Analytics
  const fetchAdminData = useCallback(async () => {
    if (!isSuperAdmin) return;
    try {
      setLoading(true);
      const headers = getAuthHeaders();

      const [analyticsRes, usersRes, paymentsRes] = await Promise.all([
        fetch('/api/admin/analytics', { headers }).then(r => r.json()).catch(() => null),
        fetch('/api/admin/users', { headers }).then(r => r.json()).catch(() => null),
        fetch('/api/admin/payments', { headers }).then(r => r.json()).catch(() => null)
      ]);

      if ([analyticsRes, usersRes, paymentsRes].some(r => typeof r?.error === 'string' && r.error.startsWith('Unauthorized'))) {
        forceReLogin();
        return;
      }

      // Payments List from DB
      if (paymentsRes?.ok && Array.isArray(paymentsRes.payments)) {
        setPaymentsList(paymentsRes.payments);
      }

      // Users List from DB with Normalized Real Fields
      let combinedUsers: RegisteredUser[] = [];
      const userListSource = usersRes?.users || (Array.isArray(usersRes) ? usersRes : []);
      if (Array.isArray(userListSource)) {
        combinedUsers = userListSource.map((u: any) => ({
          userId: u.uid || u.userId,
          uid: u.uid || u.userId,
          displayName: u.displayName || u.name || (u.email ? u.email.split('@')[0] : u.uid),
          email: u.email || 'No email registered',
          phone: u.phone || '',
          tradingBalance: Number(u.tradingBalance ?? 0),
          credits: Number(u.realCredits ?? u.credits ?? 0),
          realCredits: Number(u.realCredits ?? u.credits ?? 0),
          demoCredits: Number(u.demoCredits ?? 100),
          suspended: Boolean(u.suspended || u.status === 'suspended'),
          joinedAt: u.joinedAt || u.createdAt || new Date().toISOString(),
          lastActive: u.lastActive || u.lastLoginAt || new Date().toISOString()
        }));
      }

      // Add current admin user to users list if not already listed
      if (user?.uid && !combinedUsers.some(u => u.userId === user.uid || u.uid === user.uid)) {
        combinedUsers.unshift({
          userId: user.uid,
          uid: user.uid,
          displayName: user.displayName || 'Super Admin',
          email: user.email || 'dhruti@preetham.com',
          phone: user.phone || '',
          credits: 0,
          realCredits: 0,
          demoCredits: 100,
          tradingBalance: 0,
          role: 'SUPER_ADMIN',
          joinedAt: new Date().toISOString()
        });
      }

      setUsersList(combinedUsers);

      // Current payments list
      const activePayments = (paymentsRes?.ok && Array.isArray(paymentsRes.payments))
        ? paymentsRes.payments
        : [];

      // Compute analytics
      const approved = activePayments.filter(p => p.status === 'approved' || (p as any).status === 'VERIFIED');
      const pending = activePayments.filter(p => p.status === 'pending' || (p as any).status === 'PENDING');
      const rejected = activePayments.filter(p => p.status === 'rejected' || (p as any).status === 'REJECTED');

      const aData = analyticsRes?.analytics || analyticsRes?.metrics;
      if (aData) {
        setAnalytics({
          ...aData,
          totalUsers: Math.max(combinedUsers.length, aData.totalUsers || 1),
          totalOrdersCount: activePayments.length || aData.totalOrdersCount || 0,
          pendingOrdersCount: pending.length,
          verifiedOrdersCount: approved.length,
          rejectedOrdersCount: rejected.length,
          pendingRevenueInr: pending.reduce((sum, o) => sum + (Number(o.amount) || 0), 0)
        });
      } else {
        setAnalytics({
          totalUsers: Math.max(combinedUsers.length, 1),
          totalTradingFunds: combinedUsers.reduce((s, u) => s + (Number(u.tradingBalance) || 0), 0),
          totalCreditsOutstanding: combinedUsers.reduce((s, u) => s + (Number(u.credits) || 0), 0),
          totalRevenueInr: approved.reduce((s, o) => s + (Number(o.amount) || 0), 0),
          pendingRevenueInr: pending.reduce((s, o) => s + (Number(o.amount) || 0), 0),
          totalOrdersCount: activePayments.length,
          verifiedOrdersCount: approved.length,
          pendingOrdersCount: pending.length,
          rejectedOrdersCount: rejected.length,
          targetVpa: 'preethamrishu@axl',
          payeeName: 'DHRU AI Quantitative Markets',
          systemStatus: 'OPERATIONAL'
        });
      }
      setLastRefreshedAt(new Date().toLocaleTimeString());
      void fetchPromos();
      void fetchBroadcasts();
    } catch (err) {
      console.warn('[Admin] Error loading data:', err);
    } finally {
      setLoading(false);
    }
  }, [isSuperAdmin, getAuthHeaders, forceReLogin, user?.uid, user?.displayName, user?.email, fetchPromos, fetchBroadcasts]);

  // Initial load
  useEffect(() => {
    if (isSuperAdmin) {
      void fetchAdminData();
      void fetchPromos();
      void fetchBroadcasts();
    }
  }, [isSuperAdmin, fetchAdminData, fetchPromos, fetchBroadcasts]);

  // Polling fallback: new UTR requests appear within 5s even if the live stream is blocked
  useEffect(() => {
    if (!isSuperAdmin) return;
    const tick = async () => {
      try {
        const res = await fetch('/api/admin/payments', { headers: getAuthHeaders() });
        if (res.status === 401) { forceReLogin(); return; }
        const data = await res.json().catch(() => null);
        if (data?.ok && Array.isArray(data.payments)) {
          setPaymentsList(data.payments);
          setLastRefreshedAt(new Date().toLocaleTimeString());
        }
      } catch { /* offline: try again next tick */ }
    };
    const id = setInterval(tick, 5000);
    return () => clearInterval(id);
  }, [isSuperAdmin, getAuthHeaders, forceReLogin]);

  // Real-time EventSource connection for instant payment & user arrival
  useEffect(() => {
    if (!isSuperAdmin) return;
    const sseUrl = `/api/stream/admin?token=${encodeURIComponent(adminToken || '')}`;
    let es: EventSource | null = null;
    try {
      es = new EventSource(sseUrl);
      es.addEventListener('new_payment', (e: any) => {
        try {
          const item = JSON.parse(e.data);
          setPaymentsList(prev => {
            if (prev.some(p => p.id === item.id || (item.utr && p.utr === item.utr))) return prev;
            return [item, ...prev];
          });
          setLastRefreshedAt(new Date().toLocaleTimeString());
        } catch {}
      });
      es.addEventListener('payment_updated', (e: any) => {
        try {
          const item = JSON.parse(e.data);
          setPaymentsList(prev => prev.map(p => p.id === item.paymentId ? { ...p, status: item.status, amount: item.amount || p.amount } : p));
          setLastRefreshedAt(new Date().toLocaleTimeString());
        } catch {}
      });
      es.addEventListener('new_signup', (e: any) => {
        try {
          const u = JSON.parse(e.data);
          setUsersList(prev => {
            if (prev.some(x => x.uid === u.uid)) return prev;
            return [{
              userId: u.uid,
              uid: u.uid,
              displayName: u.name,
              email: u.email,
              phone: u.phone,
              credits: 100,
              tradingBalance: 0,
              joinedAt: new Date().toISOString()
            }, ...prev];
          });
          setLastRefreshedAt(new Date().toLocaleTimeString());
        } catch {}
      });
      es.addEventListener('promo_redeemed', () => {
        void fetchPromos();
      });
    } catch {}

    return () => {
      es?.close();
    };
  }, [isSuperAdmin, adminToken, fetchPromos]);

  // Promo Code Action Handlers
  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = newCodeName.trim().toUpperCase();
    if (!cleanCode) {
      setNewCodeError('Please enter or generate a code string.');
      return;
    }
    const numCredits = Number(newCodeCredits);
    if (!Number.isFinite(numCredits) || numCredits <= 0) {
      setNewCodeError('AI Credits amount must be greater than 0.');
      return;
    }

    setNewCodeBusy(true);
    setNewCodeError(null);
    setNewCodeSuccess(null);

    try {
      const payload = {
        code: cleanCode,
        credits: numCredits,
        maxUses: Number(newCodeMaxUses) || 10,
        perUserLimit: 1,
        note: newCodeNote.trim() || 'Admin generated AI credits'
      };

      let res = await fetch('/api/admin/promos/create', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(payload)
      });

      let data = await res.json().catch(() => ({}));

      if (!res.ok || !data.ok) {
        try {
          const fallbackRes = await fetch('/api/promos/admin/create', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(payload)
          });
          const fallbackData = await fallbackRes.json().catch(() => ({}));
          if (fallbackRes.ok && (fallbackData.ok || fallbackData.success)) {
            res = fallbackRes;
            data = { ok: true, ...fallbackData };
          }
        } catch {}
      }

      if (res.ok && (data.ok || data.success)) {
        setNewCodeSuccess(`Redeem Code "${cleanCode}" created with ${numCredits} AI Credits!`);
        setNewCodeName('');
        setNewCodeNote('');
        void fetchPromos();
        setTimeout(() => {
          setPromoModalOpen(false);
          setNewCodeSuccess(null);
        }, 1200);
      } else {
        setNewCodeError(data.error || 'Failed to generate code.');
      }
    } catch (err: any) {
      setNewCodeError(err.message || 'Connection error creating code.');
    } finally {
      setNewCodeBusy(false);
    }
  };

  const handleTogglePromo = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promos/${encodeURIComponent(id)}/toggle`, {
        method: 'POST',
        headers: getAuthHeaders()
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setPromosList(prev => prev.map(p => p.id === id ? { ...p, active: data.active } : p));
      } else {
        alert(data.error || 'Failed to toggle promo code');
      }
    } catch (err: any) {
      alert(`Error toggling promo: ${err.message}`);
    }
  };

  const handleDeletePromo = async (id: string, code: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete code ${code}?`)) return;
    try {
      const res = await fetch(`/api/admin/promos/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setPromosList(prev => prev.filter(p => p.id !== id));
      } else {
        alert(data.error || 'Failed to delete promo code');
      }
    } catch (err: any) {
      alert(`Error deleting promo: ${err.message}`);
    }
  };

  // Handle Gate Login with backend JWT verification
  const handleGateLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setGateBusy(true);
    setGateError(null);

    try {
      // 1. Authenticate with server JWT endpoint
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: gateEmail, password: gatePass })
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        if (res.status === 429) {
          setGateError(data.error || 'Too many failed attempts. Locked out for 15 minutes.');
        } else {
          setGateError(data.error || 'Access Denied: Invalid Security Credentials');
        }
        return;
      }

      if (data.ok && data.token) {
        sessionStorage.setItem('dhru_admin_jwt_token', data.token);
        setAdminToken(data.token);
        // Also authenticate in local context
        await signInWithEmail(gateEmail, gatePass).catch(() => {});
        setGatePass('');
      } else {
        setGateError('Authentication failed: No token received');
      }
    } catch (err: any) {
      setGateError(err.message || 'Authentication connection error');
    } finally {
      setGateBusy(false);
    }
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('dhru_admin_jwt_token');
    setAdminToken(null);
    setGatePass('');
    void signOut();
  };

  // Payment Approval Execution
  const handleApproveOrder = async (order: PaymentRecord) => {
    const isCredits = order.type === 'credits';
    const defaultCredits = order.credits || (order.amount === 99 ? 200 : order.amount === 199 ? 500 : order.amount === 499 ? 1200 : order.amount === 899 ? 2000 : order.amount);

    const customAmt = window.prompt(
      isCredits
        ? `Approve & Credit ${defaultCredits} AI Credits (₹${order.amount}) to UID: ${order.uid}?\nEnter credits to credit (or press OK to approve as-is):`
        : `Approve & Credit ₹${order.amount} Trading Funds to UID: ${order.uid}?\nEnter amount to credit (or press OK to approve as-is):`,
      isCredits ? String(defaultCredits) : String(order.amount)
    );
    if (customAmt === null) return;

    const parsedCredits = isCredits ? (Number(customAmt) || defaultCredits) : undefined;
    const parsedAmt = !isCredits ? (Number(customAmt) || order.amount) : order.amount;
    setActionBusyId(order.id);

    try {
      const result = await approvePaymentOrder({
        paymentId: order.id,
        adminEmail: user?.email || 'dhruti@preetham.com',
        adminToken: adminToken || undefined,
        adminNote: `Verified and credited by Admin`,
        customAmount: parsedAmt,
        customCredits: parsedCredits
      });

      if (!result.ok) {
        alert(result.message || 'Approval failed');
        return;
      }

      // Update order in paymentsList immediately
      setPaymentsList(prev =>
        prev.map(p =>
          p.id === order.id
            ? { ...p, status: 'approved', amount: parsedAmt, credits: parsedCredits }
            : p
        )
      );

      // Update user wallet locally in usersList
      setUsersList(prev =>
        prev.map(u => {
          if (u.userId === order.uid || u.uid === order.uid) {
            return {
              ...u,
              tradingBalance: !isCredits ? (u.tradingBalance || 0) + parsedAmt : u.tradingBalance,
              credits: isCredits ? (u.credits || 0) + (parsedCredits || defaultCredits) : u.credits,
              realCredits: isCredits ? (u.realCredits || 0) + (parsedCredits || defaultCredits) : u.realCredits
            };
          }
          return u;
        })
      );

      dispatchTradeNotification({
        type: 'PROFIT',
        title: 'Payment Order Approved',
        symbol: 'UTR',
        status: 'VERIFIED',
        reason: isCredits
          ? `Credited ${parsedCredits || defaultCredits} AI Credits to UID: ${order.uid}`
          : `Credited ₹${parsedAmt} Trading Funds to UID: ${order.uid} (UTR: ${order.utr})`
      });

      await fetchAdminData();
      await refreshWallet();
    } catch (err: any) {
      alert(`Error approving order: ${err.message}`);
    } finally {
      setActionBusyId(null);
    }
  };

  // Payment Rejection Execution
  const handleRejectOrder = async (orderId: string) => {
    const reason = window.prompt(
      'Enter reason for rejecting this payment order (shown directly to the user):',
      'UTR verification failed / invalid reference number'
    );
    if (!reason || !reason.trim()) {
      alert('A rejection reason is strictly required so the user knows why the payment was rejected.');
      return;
    }

    setActionBusyId(orderId);
    try {
      const result = await rejectPaymentOrder({
        paymentId: orderId,
        adminEmail: user?.email || 'dhruti@preetham.com',
        adminToken: adminToken || undefined,
        reason: reason.trim()
      });

      if (!result.ok) {
        alert(result.message || 'Rejection failed');
        return;
      }

      setPaymentsList(prev =>
        prev.map(p =>
          p.id === orderId
            ? { ...p, status: 'rejected', adminNote: reason.trim() }
            : p
        )
      );

      dispatchTradeNotification({
        type: 'REJECTED',
        title: 'Payment Order Rejected',
        symbol: 'UTR',
        status: 'REJECTED',
        reason: `Order ${orderId} rejected: ${reason}`
      });

      await fetchAdminData();
    } catch (err: any) {
      alert(`Error rejecting order: ${err.message}`);
    } finally {
      setActionBusyId(null);
    }
  };

  // Broadcast & Poster Creation Handler
  const handleCreateBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bcTitle.trim()) {
      setBcError('Title is required for broadcasting.');
      return;
    }
    setBcBusy(true);
    setBcError(null);
    setBcSuccess(null);

    try {
      const res = await fetch('/api/broadcasts/admin/create', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          title: bcTitle.trim(),
          type: bcType,
          message: bcMessage.trim(),
          body: bcMessage.trim(),
          imageUrl: bcImageUrl.trim(),
          target: bcTarget
        })
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok && (data.ok || data.success)) {
        setBcSuccess('Broadcast & Poster successfully published to all active users!');
        setBcTitle('');
        setBcMessage('');
        setBcImageUrl('');
        void fetchBroadcasts();
        setTimeout(() => setBcSuccess(null), 3500);
      } else {
        setBcError(data.error || 'Failed to dispatch broadcast.');
      }
    } catch (err: any) {
      setBcError(err.message || 'Network error dispatching broadcast.');
    } finally {
      setBcBusy(false);
    }
  };

  const handleDeleteBroadcast = async (id: string | number) => {
    if (!window.confirm('Are you sure you want to delete this broadcast? It will be removed from all users.')) return;
    try {
      const res = await fetch(`/api/broadcasts/admin/${encodeURIComponent(String(id))}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      if (res.ok) {
        setBroadcastsList(prev => prev.filter(b => b.id !== id));
      }
    } catch (err: any) {
      alert(`Error deleting broadcast: ${err.message}`);
    }
  };

  // Adjust Balance Execution for a specific user
  const handleAdjustBalance = async () => {
    if (!selectedUser) return;
    const uid = selectedUser.uid || selectedUser.userId;
    setAdjustBusy(true);

    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(uid || '')}/adjust-balance`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          deltaAmount: adjustType === 'funds' ? adjustAmount : 0,
          deltaCredits: adjustType === 'credits' ? adjustAmount : 0,
          note: adjustNote
        })
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        alert(`Successfully adjusted ${adjustType === 'funds' ? '₹' + adjustAmount : adjustAmount + ' credits'} for UID: ${uid}`);
        await fetchAdminData();
        await refreshWallet();

        if (selectedUser) {
          setSelectedUser(prev => prev ? {
            ...prev,
            tradingBalance: adjustType === 'funds' ? (prev.tradingBalance || 0) + adjustAmount : prev.tradingBalance,
            credits: adjustType === 'credits' ? (prev.credits || 0) + adjustAmount : prev.credits
          } : null);
        }
      } else {
        alert(data.error || 'Failed to adjust balance');
      }
    } catch (err: any) {
      alert(`Error adjusting balance: ${err.message}`);
    } finally {
      setAdjustBusy(false);
    }
  };

  // Suspend / Unsuspend User
  const handleToggleSuspendUser = async (targetUser: RegisteredUser) => {
    const uid = targetUser.uid || targetUser.userId;
    const newStatus = !targetUser.suspended;

    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(uid || '')}/status`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ suspended: newStatus })
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setUsersList(prev =>
          prev.map(u => (u.userId === uid || u.uid === uid ? { ...u, suspended: newStatus } : u))
        );
        if (selectedUser && (selectedUser.uid === uid || selectedUser.userId === uid)) {
          setSelectedUser(prev => prev ? { ...prev, suspended: newStatus } : null);
        }
        alert(`User ${uid} has been ${newStatus ? 'suspended' : 'reactivated'}.`);
      } else {
        alert(data.error || 'Failed to update user status');
      }
    } catch (err: any) {
      alert(`Error updating user status: ${err.message}`);
    }
  };

  // Filtered Payments
  const filteredPayments = paymentsList.filter(o => {
    const status = (o.status || '').toLowerCase();
    if (approvalFilter === 'PENDING' && status !== 'pending') return false;
    if (approvalFilter === 'APPROVED' && status !== 'approved' && status !== 'verified') return false;
    if (approvalFilter === 'REJECTED' && status !== 'rejected') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchId = (o.id || '').toLowerCase().includes(q);
      const matchUtr = (o.utr || '').toLowerCase().includes(q);
      const matchUid = (o.uid || '').toLowerCase().includes(q);
      const matchEmail = (o.userEmail || '').toLowerCase().includes(q);
      const matchName = (o.userName || '').toLowerCase().includes(q);
      return matchId || matchUtr || matchUid || matchEmail || matchName;
    }
    return true;
  });

  // Filtered Users
  const filteredUsers = usersList.filter(u => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchUid = (u.uid || u.userId || '').toLowerCase().includes(q);
      const matchEmail = (u.email || '').toLowerCase().includes(q);
      const matchName = (u.displayName || '').toLowerCase().includes(q);
      return matchUid || matchEmail || matchName;
    }
    return true;
  });

  // ==========================================
  // 1. GATE LOGIN PORTAL (if unauthorized)
  // ==========================================
  if (!isSuperAdmin) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center p-4">
        <div className="max-w-md w-full p-6 sm:p-8 rounded-3xl border border-line bg-surface shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/30">
              <ShieldCheck className="h-7 w-7 text-purple-400" />
            </div>
            <h2 className="text-xl font-black text-ink">Master Admin Operations Desk</h2>
            <p className="text-xs text-ink-3">Authorized access only for /dhruti operations.</p>
          </div>

          <form onSubmit={handleGateLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-mono font-semibold text-ink-2 mb-1">Admin Email</label>
              <input
                type="email"
                value={gateEmail}
                onChange={e => setGateEmail(e.target.value)}
                placeholder="xyz@gmail.com"
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs font-mono outline-none focus:border-purple-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-semibold text-ink-2 mb-1">Secret Key / Password</label>
              <input
                type="password"
                value={gatePass}
                onChange={e => setGatePass(e.target.value)}
                placeholder="Enter admin password"
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs font-mono outline-none focus:border-purple-500 font-bold"
              />
            </div>

            {gateError && (
              <div role="alert" className="p-3 rounded-xl border border-rose-500/40 bg-rose-500/10 text-xs text-rose-400 font-mono">
                {gateError}
              </div>
            )}

            <button
              type="submit"
              disabled={gateBusy}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase font-mono tracking-wider shadow-md active:scale-98 transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{gateBusy ? 'Authenticating with JWT...' : 'Unlock Admin Desk'}</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ==========================================
  // 2. MASTER COMMAND CENTER
  // ==========================================
  return (
    <div className="space-y-6 animate-fade-in pb-28">
      {/* 1. Header Banner */}
      <div className="rounded-3xl border border-line bg-surface p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-purple-500/15 text-purple-600 dark:text-purple-300 border border-purple-500/30 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-500" />
                Master Admin Operations Desk
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Firestore Live Sync Active
              </span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-mono bg-surface-2 text-ink-3 border border-line">
                Route: /dhruti
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-ink">
              Command & Payment Control Center
            </h1>
            <p className="text-xs text-ink-3 mt-1">
              Live financial overview, instant UTR payment approvals with User UID connection, and complete user controls.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[11px] font-mono text-ink-3 hidden sm:inline">
              Updated: {lastRefreshedAt}
            </span>

            <button
              onClick={() => { void fetchAdminData(); void fetchPromos(); }}
              disabled={loading}
              className="px-3.5 py-2 rounded-xl border border-line bg-surface-2 hover:bg-surface text-ink text-xs font-mono font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-purple-400' : ''}`} />
              <span>Refresh Data</span>
            </button>

            <button
              onClick={handleAdminLogout}
              className="px-3.5 py-2 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              title="Lock Admin Desk"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Lock Desk</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Navigation Tabs (Approvals, Analytics, Users, and Redeem Codes) */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl border border-line bg-surface w-fit max-w-full overflow-x-auto">
        <button
          onClick={() => { setDeskTab('approvals'); setSearchQuery(''); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            deskTab === 'approvals'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-ink-2 hover:text-ink hover:bg-surface-2'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Payment Approvals (UTR Desk)</span>
          {analytics?.pendingOrdersCount ? (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-bold animate-pulse">
              {analytics.pendingOrdersCount}
            </span>
          ) : null}
        </button>

        <button
          onClick={() => { setDeskTab('analytics'); setSearchQuery(''); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            deskTab === 'analytics'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-ink-2 hover:text-ink hover:bg-surface-2'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Platform Analytics</span>
        </button>

        <button
          onClick={() => { setDeskTab('users'); setSearchQuery(''); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            deskTab === 'users'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-ink-2 hover:text-ink hover:bg-surface-2'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>User Management ({usersList.length})</span>
        </button>

        <button
          onClick={() => { setDeskTab('promos'); setSearchQuery(''); void fetchPromos(); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            deskTab === 'promos'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-ink-2 hover:text-ink hover:bg-surface-2'
          }`}
        >
          <Gift className="w-3.5 h-3.5 text-amber-400" />
          <span>Redeem Codes Desk ({promosList.length})</span>
        </button>

        <button
          onClick={() => { setDeskTab('broadcasts'); setSearchQuery(''); void fetchBroadcasts(); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            deskTab === 'broadcasts'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-ink-2 hover:text-ink hover:bg-surface-2'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5 text-pink-400" />
          <span>Broadcast & Posters ({broadcastsList.length})</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: PAYMENT APPROVALS (UTR DESK)                      */}
      {/* ======================================================== */}
      {deskTab === 'approvals' && (
        <div className="space-y-4">
          {/* Controls Strip: Filters & Search */}
          <div className="rounded-2xl border border-line bg-surface p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              {(['PENDING', 'APPROVED', 'REJECTED', 'ALL'] as const).map(filter => (
                <button
                  key={filter}
                  onClick={() => setApprovalFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer whitespace-nowrap ${
                    approvalFilter === filter
                      ? 'bg-purple-600 text-white'
                      : 'bg-surface-2 text-ink-2 hover:text-ink'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search UTR, UID, Email, ID..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-line bg-surface-2 text-ink text-xs font-mono outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Orders List / Table */}
          <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
            {filteredPayments.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-500/40 mx-auto" />
                <div className="text-sm font-bold text-ink">No payment records found</div>
                <p className="text-xs text-ink-3">
                  {approvalFilter === 'PENDING'
                    ? 'All pending UTRs have been reviewed. Good job!'
                    : 'No orders match your filter criteria.'}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-line bg-surface-2 text-ink-2 font-mono uppercase text-[10px] tracking-wider">
                      <th className="py-3 px-4">Order / Time</th>
                      <th className="py-3 px-4">User UID & Profile</th>
                      <th className="py-3 px-4">UTR Reference</th>
                      <th className="py-3 px-4">Amount / Type</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line font-mono">
                    {filteredPayments.map(order => {
                      const isPending = (order.status || '').toLowerCase() === 'pending';
                      const isApproved = (order.status || '').toLowerCase() === 'approved' || (order.status as any) === 'VERIFIED';
                      const isRejected = (order.status || '').toLowerCase() === 'rejected' || (order.status as any) === 'REJECTED';
                      const isBusy = actionBusyId === order.id;

                      return (
                        <tr key={order.id} className="hover:bg-surface-2/60 transition-colors">
                          {/* Order ID & Time */}
                          <td className="py-3.5 px-4 align-top">
                            <div className="font-bold text-ink">{order.id}</div>
                            <div className="text-[11px] text-ink-3 mt-0.5">
                              {order.createdAt ? new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Recent'}
                            </div>
                          </td>

                          {/* User UID & Contact */}
                          <td className="py-3.5 px-4 align-top">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded text-[11px]">
                                {order.uid}
                              </span>
                              <button
                                onClick={() => copyToClipboard(order.uid, `uid-${order.id}`)}
                                className="text-ink-3 hover:text-ink transition-colors p-0.5 cursor-pointer"
                                title="Copy User UID"
                              >
                                {copiedId === `uid-${order.id}` ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                            <div className="text-ink font-semibold mt-1">{order.userName || 'Trader'}</div>
                            <div className="text-[11px] text-ink-3 flex items-center gap-1">
                              <Mail className="w-3 h-3 text-ink-3" />
                              <span>{order.userEmail || 'No email'}</span>
                            </div>
                          </td>

                          {/* UTR Reference */}
                          <td className="py-3.5 px-4 align-top">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-ink text-sm bg-surface-2 px-2 py-1 rounded-lg border border-line">
                                {order.utr}
                              </span>
                              <button
                                onClick={() => copyToClipboard(order.utr, `utr-${order.id}`)}
                                className="text-ink-3 hover:text-ink transition-colors p-1 cursor-pointer"
                                title="Copy UTR"
                              >
                                {copiedId === `utr-${order.id}` ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                            {order.adminNote && (
                              <div className="text-[11px] text-amber-500 dark:text-amber-400 mt-1 max-w-xs break-words">
                                Note: {order.adminNote}
                              </div>
                            )}
                          </td>

                          {/* Amount */}
                          <td className="py-3.5 px-4 align-top">
                            <div className="text-sm font-black text-ink">
                              ₹{Number(order.amount).toLocaleString('en-IN')}
                            </div>
                            <div className="text-[10px] uppercase font-bold text-ink-3 mt-0.5">
                              {order.type === 'credits' ? `${order.credits || order.amount} Credits` : 'Trading Funds'}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3.5 px-4 align-top">
                            {isPending && (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-500 border border-amber-500/30 flex items-center gap-1 w-fit">
                                <Clock className="w-3 h-3 animate-spin" />
                                PENDING APPROVAL
                              </span>
                            )}
                            {isApproved && (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 flex items-center gap-1 w-fit">
                                <CheckCircle2 className="w-3 h-3" />
                                APPROVED & CREDITED
                              </span>
                            )}
                            {isRejected && (
                              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-500 border border-rose-500/30 flex items-center gap-1 w-fit">
                                <XCircle className="w-3 h-3" />
                                REJECTED
                              </span>
                            )}
                          </td>

                          {/* Actions */}
                          <td className="py-3.5 px-4 align-top text-right space-y-1.5">
                            {isPending ? (
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => handleApproveOrder(order)}
                                  disabled={isBusy}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm active:scale-95 transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Approve & Credit</span>
                                </button>

                                <button
                                  onClick={() => handleRejectOrder(order.id)}
                                  disabled={isBusy}
                                  className="px-2.5 py-1.5 rounded-lg border border-rose-500/30 hover:bg-rose-500/10 text-rose-400 font-bold text-xs transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1"
                                >
                                  <X className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </div>
                            ) : (
                              <span className="text-[11px] text-ink-3 font-mono">
                                Reviewed by {order.reviewedBy || 'Admin'}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PLATFORM ANALYTICS                                */}
      {/* ======================================================== */}
      {deskTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Users */}
            <div className="p-5 rounded-2xl border border-line bg-surface space-y-2">
              <div className="flex items-center justify-between text-ink-3 text-xs font-mono">
                <span>TOTAL REGISTERED USERS</span>
                <User className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-ink font-mono">
                {analytics?.totalUsers ?? usersList.length}
              </div>
              <p className="text-[11px] text-ink-3">Live users synchronized with UID</p>
            </div>

            {/* Total Revenue */}
            <div className="p-5 rounded-2xl border border-line bg-surface space-y-2">
              <div className="flex items-center justify-between text-ink-3 text-xs font-mono">
                <span>VERIFIED REVENUE (INR)</span>
                <Wallet className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-500 font-mono">
                ₹{(analytics?.totalRevenueInr || 0).toLocaleString('en-IN')}
              </div>
              <p className="text-[11px] text-ink-3">{analytics?.verifiedOrdersCount || 0} verified transactions</p>
            </div>

            {/* Pending Approvals */}
            <div className="p-5 rounded-2xl border border-line bg-surface space-y-2">
              <div className="flex items-center justify-between text-ink-3 text-xs font-mono">
                <span>PENDING UTR APPROVALS</span>
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-amber-500 font-mono">
                {analytics?.pendingOrdersCount || 0}
              </div>
              <p className="text-[11px] text-ink-3">
                ₹{(analytics?.pendingRevenueInr || 0).toLocaleString('en-IN')} awaiting verification
              </p>
            </div>

            {/* Total User Capital Deployed */}
            <div className="p-5 rounded-2xl border border-line bg-surface space-y-2">
              <div className="flex items-center justify-between text-ink-3 text-xs font-mono">
                <span>TOTAL CAPITAL DEPLOYED</span>
                <Zap className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-indigo-400 font-mono">
                ₹{(analytics?.totalTradingFunds || 0).toLocaleString('en-IN')}
              </div>
              <p className="text-[11px] text-ink-3">Trading balances across user accounts</p>
            </div>
          </div>

          {/* Secondary Stats */}
          <div className="p-6 rounded-3xl border border-line bg-surface space-y-4">
            <h3 className="text-sm font-black text-ink uppercase tracking-wider font-mono">
              Gateway Configuration & Credits Audit
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div className="p-3.5 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-ink-3 text-[11px]">Primary Merchant VPA</span>
                <div className="font-bold text-ink text-sm">{analytics?.targetVpa || 'preethamrishu@axl'}</div>
              </div>
              <div className="p-3.5 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-ink-3 text-[11px]">Payee Business Name</span>
                <div className="font-bold text-ink text-sm">{analytics?.payeeName || 'DHRU AI Quantitative Markets'}</div>
              </div>
              <div className="p-3.5 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-ink-3 text-[11px]">Active Outstanding Credits</span>
                <div className="font-bold text-purple-400 text-sm">
                  {analytics?.totalCreditsOutstanding || 0} Credits
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: USER MANAGEMENT WITH UID & DETAILS VIEW           */}
      {/* ======================================================== */}
      {deskTab === 'users' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-line bg-surface p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs font-mono text-ink-3">
              Showing {filteredUsers.length} of {usersList.length} users
            </div>
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by UID, Email, or Name..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-line bg-surface-2 text-ink text-xs font-mono outline-none focus:border-purple-500"
              />
            </div>
          </div>

          <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-line bg-surface-2 text-ink-2 font-mono uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">User UID</th>
                    <th className="py-3 px-4">User Details</th>
                    <th className="py-3 px-4">Trading Funds</th>
                    <th className="py-3 px-4">Credits</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line font-mono">
                  {filteredUsers.map(userItem => {
                    const uid = userItem.uid || userItem.userId || 'unknown-uid';
                    const isSuspended = Boolean(userItem.suspended || userItem.isBanned);

                    return (
                      <tr key={uid} className="hover:bg-surface-2/60 transition-colors">
                        {/* User UID with Copy Button */}
                        <td className="py-3.5 px-4 align-top">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded text-xs">
                              {uid}
                            </span>
                            <button
                              onClick={() => copyToClipboard(uid, `uid-table-${uid}`)}
                              className="text-ink-3 hover:text-ink transition-colors p-0.5 cursor-pointer"
                              title="Copy UID"
                            >
                              {copiedId === `uid-table-${uid}` ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </td>

                        {/* User Details */}
                        <td className="py-3.5 px-4 align-top">
                          <div className="font-bold text-ink">{userItem.displayName || 'Trader'}</div>
                          <div className="text-[11px] text-ink-3">{userItem.email || 'No email registered'}</div>
                          {userItem.phone && (
                            <div className="text-[10px] text-ink-3 flex items-center gap-1 mt-0.5">
                              <Phone className="w-2.5 h-2.5" />
                              <span>+91 {userItem.phone}</span>
                            </div>
                          )}
                        </td>

                        {/* Trading Funds */}
                        <td className="py-3.5 px-4 align-top">
                          <div className="font-black text-ink text-sm">
                            ₹{(userItem.tradingBalance || 0).toLocaleString('en-IN')}
                          </div>
                        </td>

                        {/* Credits */}
                        <td className="py-3.5 px-4 align-top">
                          <div className="flex items-center gap-1.5">
                            <span className="font-black text-purple-400 text-sm">
                              {userItem.credits || 0}
                            </span>
                            <span className="text-[10px] text-ink-3 uppercase font-semibold">Real</span>
                          </div>
                          <div className="text-[10px] text-ink-3 mt-0.5">
                            Demo: <span className="font-semibold text-ink-2">{userItem.demoCredits ?? 100}</span>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4 align-top">
                          {isSuspended ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-500 border border-rose-500/30">
                              SUSPENDED
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-500 border border-emerald-500/30">
                              ACTIVE
                            </span>
                          )}
                        </td>

                        {/* Action buttons */}
                        <td className="py-3.5 px-4 align-top text-right space-x-2">
                          <button
                            onClick={() => setSelectedUser(userItem)}
                            className="px-3 py-1.5 rounded-lg border border-line bg-surface-2 hover:bg-surface text-ink text-xs font-semibold cursor-pointer transition-all"
                          >
                            <Eye className="w-3 h-3 inline mr-1" />
                            View Details
                          </button>
                          <button
                            onClick={() => handleToggleSuspendUser(userItem)}
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                              isSuspended
                                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
                                : 'border-rose-500/30 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20'
                            }`}
                          >
                            {isSuspended ? 'Unsuspend' : 'Suspend'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 4: REDEEM CODES DESK                                 */}
      {/* ======================================================== */}
      {deskTab === 'promos' && (
        <div className="space-y-6">
          {/* Top Header & Actions Strip */}
          <div className="rounded-2xl border border-line bg-surface p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-ink flex items-center gap-2">
                    <span>Redeem Codes & AI Credits Engine</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-purple-500/10 text-purple-400 font-bold border border-purple-500/20">
                      {promosList.length} Total Codes
                    </span>
                  </h3>
                  <p className="text-xs text-ink-3">
                    Generate unique redeemable promotional codes to grant free AI intelligence credits to traders.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => {
                  generateUniqueCode();
                  setNewCodeError(null);
                  setNewCodeSuccess(null);
                  setPromoModalOpen(true);
                }}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono text-xs font-bold cursor-pointer transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Generate Unique Code</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl border border-line bg-surface space-y-1">
              <span className="text-[10px] font-mono uppercase text-ink-3">Active Promotional Codes</span>
              <div className="text-2xl font-black font-mono text-purple-400">
                {promosList.filter(p => p.active === 1 || Boolean(p.active)).length}
              </div>
              <p className="text-[11px] text-ink-3">Currently redeemable by users</p>
            </div>

            <div className="p-4 rounded-2xl border border-line bg-surface space-y-1">
              <span className="text-[10px] font-mono uppercase text-ink-3">Total Redemptions Claimed</span>
              <div className="text-2xl font-black font-mono text-emerald-400">
                {promosList.reduce((sum, p) => sum + (Number(p.usedCount) || Number(p.totalRedemptions) || 0), 0)}
              </div>
              <p className="text-[11px] text-ink-3">Total codes claimed across all traders</p>
            </div>

            <div className="p-4 rounded-2xl border border-line bg-surface space-y-1">
              <span className="text-[10px] font-mono uppercase text-ink-3">Total AI Credits Issued</span>
              <div className="text-2xl font-black font-mono text-amber-400">
                {promosList.reduce((sum, p) => sum + ((Number(p.credits) || 0) * (Number(p.usedCount) || Number(p.totalRedemptions) || 0)), 0).toLocaleString()}
              </div>
              <p className="text-[11px] text-ink-3">Calculated credits granted</p>
            </div>
          </div>

          {/* Search bar */}
          <div className="rounded-2xl border border-line bg-surface p-3 flex items-center gap-3">
            <Search className="w-4 h-4 text-ink-3 ml-2 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by code name (e.g. DHRU-...) or campaign note..."
              className="w-full bg-transparent text-xs font-mono text-ink outline-none"
            />
          </div>

          {/* Promo Codes Table */}
          <div className="rounded-2xl border border-line bg-surface overflow-hidden shadow-sm">
            {promosLoading ? (
              <div className="p-12 text-center text-xs font-mono text-ink-3">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-purple-400" />
                Loading redeem codes...
              </div>
            ) : promosList.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <Gift className="w-10 h-10 text-purple-400/40 mx-auto" />
                <div className="text-sm font-bold text-ink">No Redeem Codes Generated Yet</div>
                <p className="text-xs text-ink-3 max-w-sm mx-auto">
                  Click "Generate Unique Code" above to create an AI credits code that users can redeem in their panel.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-line bg-surface-2 text-ink-2 font-mono uppercase text-[10px] tracking-wider">
                      <th className="py-3 px-4">Code / ID</th>
                      <th className="py-3 px-4">AI Credits</th>
                      <th className="py-3 px-4">Claimed / Max</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Campaign Note</th>
                      <th className="py-3 px-4">Created Date</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line font-mono">
                    {promosList
                      .filter(p => {
                        if (!searchQuery.trim()) return true;
                        const q = searchQuery.toLowerCase();
                        return (p.code || '').toLowerCase().includes(q) || (p.note || '').toLowerCase().includes(q);
                      })
                      .map(promo => {
                        const isActive = promo.active === 1 || Boolean(promo.active);
                        const isExpired = promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now();
                        const used = Number(promo.usedCount || promo.totalRedemptions || 0);
                        const max = Number(promo.maxUses || 0);

                        return (
                          <tr key={promo.id} className="hover:bg-surface-2/60 transition-colors">
                            {/* Code String */}
                            <td className="py-3.5 px-4 font-bold text-ink">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-purple-400 tracking-wider text-sm bg-purple-500/10 px-2 py-0.5 rounded-lg border border-purple-500/20">
                                  {promo.code}
                                </span>
                                <button
                                  onClick={() => copyToClipboard(promo.code, `promo-${promo.id}`)}
                                  className="p-1 rounded text-ink-3 hover:text-ink cursor-pointer transition-colors"
                                  title="Copy Code"
                                >
                                  {copiedId === `promo-${promo.id}` ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            </td>

                            {/* Credits */}
                            <td className="py-3.5 px-4 font-bold text-amber-500">
                              <div className="flex items-center gap-1.5">
                                <Zap className="w-3.5 h-3.5 fill-current" />
                                <span>+{promo.credits} AI Credits</span>
                              </div>
                            </td>

                            {/* Usage Progress */}
                            <td className="py-3.5 px-4">
                              <span className="font-mono text-ink">
                                {used} / {max > 0 ? max : '∞'} claimed
                              </span>
                              {max > 0 && (
                                <div className="w-24 h-1.5 bg-surface-2 rounded-full overflow-hidden mt-1 border border-line">
                                  <div
                                    className={`h-full ${used >= max ? 'bg-rose-500' : 'bg-purple-500'}`}
                                    style={{ width: `${Math.min(100, (used / max) * 100)}%` }}
                                  />
                                </div>
                              )}
                            </td>

                            {/* Status */}
                            <td className="py-3.5 px-4">
                              {isExpired ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
                                  Expired
                                </span>
                              ) : isActive ? (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                  Active
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-500/10 text-slate-400 border border-slate-500/30">
                                  Deactivated
                                </span>
                              )}
                            </td>

                            {/* Campaign Note */}
                            <td className="py-3.5 px-4 text-ink-2 max-w-xs truncate">
                              {promo.note || 'Admin generated'}
                            </td>

                            {/* Created Date */}
                            <td className="py-3.5 px-4 text-ink-3 text-[11px]">
                              {promo.createdAt ? new Date(promo.createdAt).toLocaleDateString() : 'N/A'}
                            </td>

                            {/* Actions */}
                            <td className="py-3.5 px-4 text-right space-x-2">
                              <button
                                onClick={() => handleTogglePromo(promo.id)}
                                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-all border ${
                                  isActive
                                    ? 'border-amber-500/30 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                                    : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
                                }`}
                              >
                                {isActive ? 'Deactivate' : 'Activate'}
                              </button>

                              <button
                                onClick={() => handleDeletePromo(promo.id, promo.code)}
                                className="px-2 py-1 rounded-lg border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold cursor-pointer transition-all"
                                title="Delete Code"
                              >
                                <Trash2 className="w-3.5 h-3.5 inline" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Modal: Generate Unique Redeem Code */}
          {promoModalOpen && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
              <div className="w-full max-w-md rounded-3xl border border-line bg-surface p-6 shadow-2xl space-y-4 animate-scale-up my-8">
                <div className="flex items-center justify-between border-b border-line pb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-purple-500/10 text-purple-400">
                      <Gift className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-ink">Generate Unique Redeem Code</h4>
                      <p className="text-[11px] text-ink-3">Creates an instant AI credits voucher for users</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setPromoModalOpen(false)}
                    className="p-1 rounded-lg text-ink-3 hover:text-ink cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleCreatePromo} className="space-y-3.5 text-xs font-mono">
                  {/* Code String */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-ink">Unique Code String</label>
                      <button
                        type="button"
                        onClick={generateUniqueCode}
                        className="text-[11px] text-purple-400 hover:underline cursor-pointer flex items-center gap-1 font-bold"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Randomize</span>
                      </button>
                    </div>
                    <input
                      type="text"
                      value={newCodeName}
                      onChange={e => setNewCodeName(e.target.value.toUpperCase())}
                      placeholder="e.g. DHRU-8X2K9"
                      required
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-sm font-bold tracking-wider outline-none focus:border-purple-500 uppercase"
                    />
                  </div>

                  {/* Credits Amount */}
                  <div>
                    <label className="block font-bold text-ink mb-1">AI Credits Given to User</label>
                    <div className="flex items-center gap-2 mb-1.5">
                      {[100, 250, 500, 1000].map(amt => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setNewCodeCredits(amt)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer border ${
                            newCodeCredits === amt
                              ? 'bg-purple-600 text-white border-purple-600'
                              : 'bg-surface-2 text-ink-2 border-line hover:text-ink'
                          }`}
                        >
                          {amt} Cr
                        </button>
                      ))}
                    </div>
                    <input
                      type="number"
                      min={1}
                      max={100000}
                      value={newCodeCredits}
                      onChange={e => setNewCodeCredits(Number(e.target.value))}
                      required
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-sm font-bold outline-none focus:border-purple-500"
                    />
                  </div>

                  {/* Maximum Global Uses */}
                  <div>
                    <label className="block font-bold text-ink mb-1">Maximum Global Redemptions</label>
                    <input
                      type="number"
                      min={1}
                      max={100000}
                      value={newCodeMaxUses}
                      onChange={e => setNewCodeMaxUses(Number(e.target.value))}
                      required
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-sm font-bold outline-none focus:border-purple-500"
                    />
                    <p className="text-[10px] text-ink-3 mt-0.5">How many different users can claim this code (1 per user limit enforced).</p>
                  </div>

                  {/* Campaign Note */}
                  <div>
                    <label className="block font-bold text-ink mb-1">Description / Campaign Note</label>
                    <input
                      type="text"
                      value={newCodeNote}
                      onChange={e => setNewCodeNote(e.target.value)}
                      placeholder="e.g. VIP Trader Giveaway"
                      className="w-full px-3 py-2 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-purple-500"
                    />
                  </div>

                  {newCodeError && (
                    <div className="p-2.5 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400 text-xs">
                      {newCodeError}
                    </div>
                  )}

                  {newCodeSuccess && (
                    <div className="p-2.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{newCodeSuccess}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setPromoModalOpen(false)}
                      className="flex-1 py-2.5 rounded-xl border border-line text-ink-2 hover:text-ink font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={newCodeBusy}
                      className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                    >
                      {newCodeBusy ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Generating...</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Create Code</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 5: BROADCAST & POSTERS DESK                          */}
      {/* ======================================================== */}
      {deskTab === 'broadcasts' && (
        <div className="space-y-6">
          {/* Top Banner */}
          <div className="rounded-2xl border border-line bg-surface p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-pink-500/10 text-pink-400 border border-pink-500/20">
                <Megaphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-ink flex items-center gap-2">
                  <span>Platform Announcements & Visual Poster Broadcasts</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-pink-500/10 text-pink-400 font-bold border border-pink-500/20">
                    {broadcastsList.length} Active
                  </span>
                </h3>
                <p className="text-xs text-ink-3">
                  Broadcast live alerts, notifications, or visual graphic posters. These appear as an interactive pop-up when traders enter the website, with an instant close button.
                </p>
              </div>
            </div>

            <button
              onClick={() => void fetchBroadcasts()}
              disabled={broadcastsLoading}
              className="px-3.5 py-2 rounded-xl border border-line bg-surface-2 hover:bg-surface text-ink text-xs font-mono font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${broadcastsLoading ? 'animate-spin text-pink-400' : ''}`} />
              <span>Refresh Broadcasts</span>
            </button>
          </div>

          {/* Broadcast Composer & Live Preview Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Compose Form */}
            <div className="lg:col-span-7 rounded-2xl border border-line bg-surface p-5 space-y-4 shadow-sm">
              <div className="flex items-center gap-2 pb-3 border-b border-line">
                <Radio className="w-4 h-4 text-pink-500 animate-pulse" />
                <h4 className="text-sm font-bold text-ink font-mono">
                  Dispatch New Announcement / Poster
                </h4>
              </div>

              <form onSubmit={handleCreateBroadcast} className="space-y-4 font-mono text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-ink-2 mb-1.5 uppercase">
                    Broadcast Title / Headline <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={bcTitle}
                    onChange={e => setBcTitle(e.target.value)}
                    placeholder="e.g. 🚀 Special Weekend Deposit Bonus & AI Signals Upgrade!"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-pink-500 font-sans"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-ink-2 mb-1.5 uppercase">
                      Broadcast Category
                    </label>
                    <select
                      value={bcType}
                      onChange={e => setBcType(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-pink-500 cursor-pointer"
                    >
                      <option value="poster">🖼️ Visual Poster / Banner</option>
                      <option value="message">📢 General Announcement</option>
                      <option value="promo">🎁 Promo & Offers</option>
                      <option value="alert">⚠️ Critical Platform Alert</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-ink-2 mb-1.5 uppercase">
                      Target Audience
                    </label>
                    <select
                      value={bcTarget}
                      onChange={e => setBcTarget(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-pink-500 cursor-pointer"
                    >
                      <option value="all">🌐 All Platform Traders</option>
                      <option value="real">💎 Real Account Traders Only</option>
                      <option value="demo">🧪 Demo Account Traders Only</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-ink-2 mb-1.5 uppercase">
                    Poster Image URL (Optional)
                  </label>
                  <div className="relative">
                    <ImageIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
                    <input
                      type="url"
                      value={bcImageUrl}
                      onChange={e => setBcImageUrl(e.target.value)}
                      placeholder="https://example.com/banner-poster.png"
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-pink-500 font-sans"
                    />
                  </div>
                  <p className="text-[10px] text-ink-3 mt-1">
                    Provide a public HTTPS link to an image/poster. It will be showcased prominently at the top of the user popup.
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-ink-2 mb-1.5 uppercase">
                    Message / Announcement Body
                  </label>
                  <textarea
                    rows={4}
                    value={bcMessage}
                    onChange={e => setBcMessage(e.target.value)}
                    placeholder="Enter announcement details, instructions, or promotional guidelines..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-line bg-surface-2 text-ink text-xs outline-none focus:border-pink-500 font-sans resize-y"
                  />
                </div>

                {bcError && (
                  <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>{bcError}</span>
                  </div>
                )}

                {bcSuccess && (
                  <div className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                    <span>{bcSuccess}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={bcBusy}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white font-bold text-xs uppercase font-mono tracking-wider shadow-md active:scale-98 transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                >
                  {bcBusy ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Broadcasting System-Wide...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Publish & Broadcast to All Users</span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Right: Live User Pop-up Preview */}
            <div className="lg:col-span-5 rounded-2xl border border-line bg-surface p-5 space-y-4 shadow-sm flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-line">
                <span className="text-xs font-mono font-bold text-ink flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-purple-400" />
                  Live Trader Screen Preview
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-surface-2 text-ink-3">
                  Audience: {bcTarget.toUpperCase()}
                </span>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center p-3 rounded-xl border border-line/60 bg-surface-2/40">
                <div className="w-full max-w-sm rounded-2xl border border-line bg-surface shadow-xl overflow-hidden pointer-events-none">
                  {/* Modal Header */}
                  <div className="p-3.5 border-b border-line flex items-center justify-between bg-surface-2/50">
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider bg-pink-500/10 text-pink-400 border border-pink-500/20">
                        {bcType}
                      </span>
                      <span className="text-[10px] text-ink-3 font-mono">DHRU Broadcast</span>
                    </div>
                    <div className="p-1 rounded-md bg-surface-2 text-ink-3 border border-line">
                      <X className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* Poster Image Preview if provided */}
                  {bcImageUrl ? (
                    <div className="relative max-h-48 overflow-hidden bg-black/40">
                      <img
                        src={bcImageUrl}
                        alt="Poster Preview"
                        className="w-full h-auto object-cover"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>
                  ) : (
                    <div className="h-24 bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-indigo-500/10 border-b border-line flex items-center justify-center text-ink-3 text-xs font-mono">
                      <ImageIcon className="w-6 h-6 text-pink-400/50 mr-2" />
                      <span>Poster Graphic Area</span>
                    </div>
                  )}

                  {/* Body Preview */}
                  <div className="p-4 space-y-2">
                    <h5 className="font-bold text-ink text-sm leading-snug">
                      {bcTitle || 'Your Broadcast Headline Here'}
                    </h5>
                    <p className="text-xs text-ink-2 leading-relaxed whitespace-pre-wrap">
                      {bcMessage || 'Your announcement or promotional message will be displayed here for the users when they open the platform.'}
                    </p>
                    <div className="pt-2">
                      <button className="w-full py-2 rounded-xl bg-purple-600 text-white font-mono font-bold text-[11px]">
                        Close & Continue
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Active & Historical Broadcasts Feed */}
          <div className="rounded-2xl border border-line bg-surface p-5 space-y-4 shadow-sm">
            <h4 className="text-sm font-bold text-ink font-mono flex items-center justify-between">
              <span>Active Broadcasts ({broadcastsList.length})</span>
              <span className="text-xs text-ink-3 font-normal font-sans">
                Active announcements are delivered to traders on platform launch
              </span>
            </h4>

            {broadcastsList.length === 0 ? (
              <div className="p-8 text-center rounded-xl border border-dashed border-line text-ink-3 font-mono text-xs space-y-2">
                <Megaphone className="w-8 h-8 mx-auto text-pink-400/40" />
                <p>No active broadcasts or posters currently running.</p>
                <p className="text-[11px] text-ink-3">Use the composer above to publish your first platform broadcast.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {broadcastsList.map((item: any) => (
                  <div
                    key={item.id}
                    className="rounded-2xl border border-line bg-surface-2 p-4 flex flex-col justify-between space-y-3"
                  >
                    <div>
                      {item.imageUrl && (
                        <div className="w-full h-36 rounded-xl overflow-hidden mb-3 border border-line bg-black/40">
                          <img
                            src={item.imageUrl}
                            alt={item.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-pink-500/15 text-pink-400 border border-pink-500/30">
                          {item.type || 'POSTER'}
                        </span>
                        <span className="text-[10px] font-mono text-ink-3">
                          Target: {item.target || 'all'}
                        </span>
                      </div>

                      <h5 className="font-bold text-ink text-sm mb-1 line-clamp-2">
                        {item.title}
                      </h5>

                      <p className="text-xs text-ink-2 line-clamp-3 leading-relaxed whitespace-pre-wrap">
                        {item.message || item.body}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-line flex items-center justify-between text-xs font-mono">
                      <span className="text-[10px] text-ink-3">
                        {item.createdAt ? new Date(item.createdAt).toLocaleDateString() : 'Active'}
                      </span>
                      <button
                        onClick={() => handleDeleteBroadcast(item.id)}
                        className="px-2.5 py-1 rounded-lg border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold cursor-pointer transition-all flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 4. USER DETAILS MODAL                                    */}
      {/* ======================================================== */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-3xl border border-line bg-surface p-6 shadow-2xl space-y-5 animate-scale-up my-8">
            <div className="flex items-center justify-between border-b border-line pb-4">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-purple-400 font-bold">
                  User Intelligence Profile
                </span>
                <h3 className="text-lg font-black text-ink">{selectedUser.displayName || 'Trader'}</h3>
              </div>
              <button
                onClick={() => setSelectedUser(null)}
                className="p-1.5 rounded-xl border border-line text-ink-3 hover:text-ink hover:bg-surface-2 transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Profile Matrix */}
            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1 col-span-2">
                <span className="text-[10px] text-ink-3 uppercase">Unique User UID</span>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-400 text-sm">
                    {selectedUser.uid || selectedUser.userId}
                  </span>
                  <button
                    onClick={() => copyToClipboard(selectedUser.uid || selectedUser.userId || '', 'modal-uid')}
                    className="p-1 text-ink-3 hover:text-ink cursor-pointer"
                  >
                    {copiedId === 'modal-uid' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">Email Address</span>
                <div className="font-bold text-ink truncate">{selectedUser.email || 'N/A'}</div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">Contact Phone</span>
                <div className="font-bold text-ink">{selectedUser.phone ? `+91 ${selectedUser.phone}` : 'N/A'}</div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">AI Credits Balance</span>
                <div className="font-bold text-amber-500 text-sm">
                  {selectedUser.credits ?? 100} Credits
                </div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">Real Trading Funds</span>
                <div className="font-bold text-emerald-500 text-sm">
                  ₹{(selectedUser.tradingBalance ?? 0).toLocaleString('en-IN')}
                </div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">Account Status</span>
                <div className="font-bold">
                  {selectedUser.suspended ? (
                    <span className="text-rose-400">Suspended</span>
                  ) : (
                    <span className="text-emerald-400">Active</span>
                  )}
                </div>
              </div>

              <div className="p-3 rounded-xl border border-line bg-surface-2 space-y-1">
                <span className="text-[10px] text-ink-3 uppercase">Joined Timestamp</span>
                <div className="font-bold text-ink-2 truncate">
                  {selectedUser.joinedAt ? new Date(selectedUser.joinedAt).toLocaleString() : 'Recent'}
                </div>
              </div>
            </div>

            {/* Direct Balance Adjustment Desk */}
            <div className="p-4 rounded-2xl border border-line bg-surface-2 space-y-3">
              <span className="text-xs font-bold text-ink flex items-center gap-1.5 font-mono">
                <Sliders className="w-3.5 h-3.5 text-purple-400" />
                <span>Direct Admin Balance Adjustment</span>
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <label className="block text-[10px] text-ink-3 uppercase mb-1">Target Account</label>
                  <select
                    value={adjustType}
                    onChange={e => setAdjustType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-line bg-surface text-ink outline-none"
                  >
                    <option value="funds">Real Trading Funds (₹ INR)</option>
                    <option value="credits">AI Intelligence Credits</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-ink-3 uppercase mb-1">Delta Amount (e.g. +500 or -200)</label>
                  <input
                    type="number"
                    value={adjustAmount}
                    onChange={e => setAdjustAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-line bg-surface text-ink outline-none font-bold"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] text-ink-3 uppercase mb-1">Admin Reason / Audit Note</label>
                  <input
                    type="text"
                    value={adjustNote}
                    onChange={e => setAdjustNote(e.target.value)}
                    placeholder="Reason for manual adjustment..."
                    className="w-full px-3 py-2 rounded-xl border border-line bg-surface text-ink outline-none"
                  />
                </div>
              </div>

              <button
                onClick={handleAdjustUserBalance}
                disabled={adjustBusy || adjustAmount === 0}
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-mono font-bold text-xs uppercase cursor-pointer transition-all shadow-md active:scale-98 disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{adjustBusy ? 'Applying Adjustment...' : `Execute ${adjustAmount >= 0 ? '+' : ''}${adjustAmount} ${adjustType === 'funds' ? 'INR' : 'Credits'} Adjustment`}</span>
              </button>
            </div>

            {/* Quick Actions Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-line">
              <button
                onClick={() => handleToggleSuspendUser(selectedUser)}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold cursor-pointer transition-all border ${
                  selectedUser.suspended
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
                    : 'border-rose-500/30 bg-rose-500/10 text-rose-400 hover:bg-rose-500/20'
                }`}
              >
                {selectedUser.suspended ? 'Reactivate Account' : 'Suspend Account'}
              </button>

              <button
                onClick={() => setSelectedUser(null)}
                className="px-5 py-2 rounded-xl bg-surface-2 hover:bg-surface border border-line text-ink text-xs font-mono font-bold cursor-pointer transition-all"
              >
                Close Dossier
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
