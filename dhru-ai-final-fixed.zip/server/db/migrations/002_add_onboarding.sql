-- DHRU.AI Master Schema Migration 002
-- Adds onboardingCompleted flag to users table for animated first-time user tour

ALTER TABLE users ADD COLUMN onboardingCompleted INTEGER NOT NULL DEFAULT 0;
