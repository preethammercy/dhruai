// DHRU.AI - Admin Authentication & Security Unit Tests
// Tests cryptographic password hashing, constant-time verification, JWT signing, and rate limiting.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  hashPassword,
  verifyPassword,
  signJwt,
  verifyJwt
} from '../server/utils/cryptoAuth.js';

test('hashPassword creates valid PBKDF2 hash format', () => {
  const hash = hashPassword('MySecretAdminPass@2026', 'fixed_salt_123');
  assert.ok(hash.startsWith('pbkdf2$100000$fixed_salt_123$'), 'Hash should match pbkdf2 format');
  assert.equal(typeof hash, 'string');
});

test('verifyPassword validates correct password and rejects incorrect password', () => {
  const password = 'DhrutiSecureKey#2026';
  const hashed = hashPassword(password);

  const isValid = verifyPassword(password, hashed);
  assert.equal(isValid, true, 'Correct password must verify to true');

  const isInvalid = verifyPassword('WrongPassword', hashed);
  assert.equal(isInvalid, false, 'Incorrect password must verify to false');
});

test('signJwt and verifyJwt produce and validate valid HMAC-SHA256 tokens', () => {
  const secret = 'super_secret_test_key_1234567890';
  const payload = {
    sub: 'dhruti@preetham.com',
    role: 'SUPER_ADMIN',
    exp: Math.floor(Date.now() / 1000) + 3600
  };

  const token = signJwt(payload, secret);
  assert.equal(typeof token, 'string');
  assert.equal(token.split('.').length, 3, 'JWT must contain header, payload, and signature');

  const decoded = verifyJwt(token, secret);
  assert.ok(decoded !== null, 'Valid token must be decoded successfully');
  assert.equal(decoded.sub, 'dhruti@preetham.com');
  assert.equal(decoded.role, 'SUPER_ADMIN');
});

test('verifyJwt rejects tokens signed with wrong secret or tampered payload', () => {
  const secretA = 'correct_secret_key';
  const secretB = 'attacker_wrong_key';
  const token = signJwt({ sub: 'dhruti@preetham.com', role: 'SUPER_ADMIN' }, secretA);

  const decoded = verifyJwt(token, secretB);
  assert.equal(decoded, null, 'Token verified with wrong secret must return null');

  // Tamper payload
  const parts = token.split('.');
  const tamperedPayload = Buffer.from(JSON.stringify({ sub: 'attacker@evil.com', role: 'SUPER_ADMIN' })).toString('base64url');
  const tamperedToken = `${parts[0]}.${tamperedPayload}.${parts[2]}`;

  const tamperedDecoded = verifyJwt(tamperedToken, secretA);
  assert.equal(tamperedDecoded, null, 'Tampered token must fail signature verification');
});

test('verifyJwt rejects expired tokens', () => {
  const secret = 'test_secret';
  const expiredPayload = {
    sub: 'dhruti@preetham.com',
    role: 'SUPER_ADMIN',
    exp: Math.floor(Date.now() / 1000) - 100 // Expired 100 seconds ago
  };

  const expiredToken = signJwt(expiredPayload, secret);
  const result = verifyJwt(expiredToken, secret);
  assert.equal(result, null, 'Expired token must return null');
});
